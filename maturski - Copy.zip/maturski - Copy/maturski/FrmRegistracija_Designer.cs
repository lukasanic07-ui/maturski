namespace WindowsFormsApplication1
{
    partial class FrmRegistracija
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.pnlLijevo       = new System.Windows.Forms.Panel();
            this.lblLogo         = new System.Windows.Forms.Label();
            this.lblTagline      = new System.Windows.Forms.Label();
            this.lblBulletsTitle = new System.Windows.Forms.Label();
            this.lblBullet1      = new System.Windows.Forms.Label();
            this.lblBullet2      = new System.Windows.Forms.Label();
            this.lblBullet3      = new System.Windows.Forms.Label();
            this.pnlDesno        = new System.Windows.Forms.Panel();
            this.lblNaslov       = new System.Windows.Forms.Label();
            this.lblPodnaslov    = new System.Windows.Forms.Label();
            this.lblUsername     = new System.Windows.Forms.Label();
            this.txtUsername     = new System.Windows.Forms.TextBox();
            this.lblLozinka      = new System.Windows.Forms.Label();
            this.txtLozinka      = new System.Windows.Forms.TextBox();
            this.lblPotvrda      = new System.Windows.Forms.Label();
            this.txtPotvrda      = new System.Windows.Forms.TextBox();
            this.chkPokaziLozinku = new System.Windows.Forms.CheckBox();
            this.pnlImePrezime   = new System.Windows.Forms.Panel();
            this.lblIme          = new System.Windows.Forms.Label();
            this.txtIme          = new System.Windows.Forms.TextBox();
            this.lblPrezime      = new System.Windows.Forms.Label();
            this.txtPrezime      = new System.Windows.Forms.TextBox();
            this.lblStatus       = new System.Windows.Forms.Label();
            this.btnRegistruj    = new System.Windows.Forms.Button();
            this.pnlLinija       = new System.Windows.Forms.Panel();
            this.lblVecPostojiAcc = new System.Windows.Forms.Label();
            this.btnNazad        = new System.Windows.Forms.Button();
            this.pnlLijevo.SuspendLayout();
            this.pnlDesno.SuspendLayout();
            this.pnlImePrezime.SuspendLayout();
            this.SuspendLayout();

            // ── pnlLijevo (branding) ─────────────────────────────────────
            this.pnlLijevo.BackColor = System.Drawing.Color.FromArgb(30, 58, 95);
            this.pnlLijevo.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlLijevo.Width = 240;
            this.pnlLijevo.Name = "pnlLijevo";
            this.pnlLijevo.TabIndex = 0;
            this.pnlLijevo.Controls.Add(this.lblLogo);
            this.pnlLijevo.Controls.Add(this.lblTagline);
            this.pnlLijevo.Controls.Add(this.lblBulletsTitle);
            this.pnlLijevo.Controls.Add(this.lblBullet1);
            this.pnlLijevo.Controls.Add(this.lblBullet2);
            this.pnlLijevo.Controls.Add(this.lblBullet3);

            this.lblLogo.AutoSize = false;
            this.lblLogo.Font = new System.Drawing.Font("Segoe UI", 36F, System.Drawing.FontStyle.Bold);
            this.lblLogo.ForeColor = System.Drawing.Color.White;
            this.lblLogo.Location = new System.Drawing.Point(0, 60);
            this.lblLogo.Name = "lblLogo";
            this.lblLogo.Size = new System.Drawing.Size(240, 70);
            this.lblLogo.Text = "FitApp";
            this.lblLogo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            this.lblTagline.AutoSize = false;
            this.lblTagline.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblTagline.ForeColor = System.Drawing.Color.FromArgb(160, 190, 220);
            this.lblTagline.Location = new System.Drawing.Point(20, 130);
            this.lblTagline.Name = "lblTagline";
            this.lblTagline.Size = new System.Drawing.Size(200, 40);
            this.lblTagline.Text = "Tvoj personalni trening asistent";
            this.lblTagline.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            this.lblBulletsTitle.AutoSize = false;
            this.lblBulletsTitle.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblBulletsTitle.ForeColor = System.Drawing.Color.FromArgb(130, 175, 220);
            this.lblBulletsTitle.Location = new System.Drawing.Point(25, 200);
            this.lblBulletsTitle.Name = "lblBulletsTitle";
            this.lblBulletsTitle.Size = new System.Drawing.Size(190, 20);
            this.lblBulletsTitle.Text = "STA DOBIJES:";

            foreach (var info in new[] {
                new { lbl = this.lblBullet1, txt = "  Pracenje treninga", y = 230 },
                new { lbl = this.lblBullet2, txt = "  Vlastiti planovi vjezbi", y = 265 },
                new { lbl = this.lblBullet3, txt = "  Detaljan profil i napredak", y = 300 }
            })
            {
                info.lbl.AutoSize = false;
                info.lbl.Font = new System.Drawing.Font("Segoe UI", 9F);
                info.lbl.ForeColor = System.Drawing.Color.FromArgb(200, 220, 245);
                info.lbl.Location = new System.Drawing.Point(20, info.y);
                info.lbl.Size = new System.Drawing.Size(200, 24);
                info.lbl.Text = info.txt;
                info.lbl.TabIndex = 0;
            }

            // ── pnlDesno (form) ──────────────────────────────────────────
            this.pnlDesno.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlDesno.BackColor = System.Drawing.Color.White;
            this.pnlDesno.Padding = new System.Windows.Forms.Padding(40, 30, 40, 30);
            this.pnlDesno.Name = "pnlDesno";
            this.pnlDesno.TabIndex = 1;
            this.pnlDesno.Controls.Add(this.lblNaslov);
            this.pnlDesno.Controls.Add(this.lblPodnaslov);
            this.pnlDesno.Controls.Add(this.lblUsername);
            this.pnlDesno.Controls.Add(this.txtUsername);
            this.pnlDesno.Controls.Add(this.lblLozinka);
            this.pnlDesno.Controls.Add(this.txtLozinka);
            this.pnlDesno.Controls.Add(this.lblPotvrda);
            this.pnlDesno.Controls.Add(this.txtPotvrda);
            this.pnlDesno.Controls.Add(this.chkPokaziLozinku);
            this.pnlDesno.Controls.Add(this.pnlImePrezime);
            this.pnlDesno.Controls.Add(this.lblStatus);
            this.pnlDesno.Controls.Add(this.btnRegistruj);
            this.pnlDesno.Controls.Add(this.pnlLinija);
            this.pnlDesno.Controls.Add(this.lblVecPostojiAcc);
            this.pnlDesno.Controls.Add(this.btnNazad);

            int rx = 40, rw = 300;

            this.lblNaslov.AutoSize = true;
            this.lblNaslov.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblNaslov.ForeColor = System.Drawing.Color.FromArgb(30, 58, 95);
            this.lblNaslov.Location = new System.Drawing.Point(rx, 30);
            this.lblNaslov.Name = "lblNaslov";
            this.lblNaslov.Text = "Kreiraj nalog";

            this.lblPodnaslov.AutoSize = true;
            this.lblPodnaslov.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblPodnaslov.ForeColor = System.Drawing.Color.FromArgb(130, 140, 160);
            this.lblPodnaslov.Location = new System.Drawing.Point(rx, 62);
            this.lblPodnaslov.Name = "lblPodnaslov";
            this.lblPodnaslov.Text = "Popuni podatke ispod da se registrujes";

            // Username
            this.lblUsername.AutoSize = true;
            this.lblUsername.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblUsername.ForeColor = System.Drawing.Color.FromArgb(70, 80, 100);
            this.lblUsername.Location = new System.Drawing.Point(rx, 100);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Text = "Username *";

            this.txtUsername.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUsername.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.txtUsername.Location = new System.Drawing.Point(rx, 118);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(rw, 28);
            this.txtUsername.TabIndex = 0;
            this.txtUsername.TextChanged += new System.EventHandler(this.txt_TextChanged);

            // Lozinka
            this.lblLozinka.AutoSize = true;
            this.lblLozinka.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblLozinka.ForeColor = System.Drawing.Color.FromArgb(70, 80, 100);
            this.lblLozinka.Location = new System.Drawing.Point(rx, 156);
            this.lblLozinka.Name = "lblLozinka";
            this.lblLozinka.Text = "Lozinka * (min. 6 znakova)";

            this.txtLozinka.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtLozinka.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.txtLozinka.Location = new System.Drawing.Point(rx, 174);
            this.txtLozinka.Name = "txtLozinka";
            this.txtLozinka.Size = new System.Drawing.Size(rw, 28);
            this.txtLozinka.UseSystemPasswordChar = true;
            this.txtLozinka.TabIndex = 1;
            this.txtLozinka.TextChanged += new System.EventHandler(this.txt_TextChanged);

            // Potvrda lozinke
            this.lblPotvrda.AutoSize = true;
            this.lblPotvrda.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblPotvrda.ForeColor = System.Drawing.Color.FromArgb(70, 80, 100);
            this.lblPotvrda.Location = new System.Drawing.Point(rx, 212);
            this.lblPotvrda.Name = "lblPotvrda";
            this.lblPotvrda.Text = "Potvrdi lozinku *";

            this.txtPotvrda.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPotvrda.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.txtPotvrda.Location = new System.Drawing.Point(rx, 230);
            this.txtPotvrda.Name = "txtPotvrda";
            this.txtPotvrda.Size = new System.Drawing.Size(rw, 28);
            this.txtPotvrda.UseSystemPasswordChar = true;
            this.txtPotvrda.TabIndex = 2;
            this.txtPotvrda.TextChanged += new System.EventHandler(this.txt_TextChanged);

            // Checkbox "Pokazi lozinku"
            this.chkPokaziLozinku.AutoSize = true;
            this.chkPokaziLozinku.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.chkPokaziLozinku.ForeColor = System.Drawing.Color.FromArgb(120, 130, 150);
            this.chkPokaziLozinku.Location = new System.Drawing.Point(rx, 266);
            this.chkPokaziLozinku.Name = "chkPokaziLozinku";
            this.chkPokaziLozinku.Text = "Pokazi lozinku";
            this.chkPokaziLozinku.TabIndex = 3;
            this.chkPokaziLozinku.CheckedChanged += new System.EventHandler(this.chkPokaziLozinku_CheckedChanged);

            // Ime + Prezime (side by side panel)
            this.pnlImePrezime.BackColor = System.Drawing.Color.White;
            this.pnlImePrezime.Location = new System.Drawing.Point(rx, 295);
            this.pnlImePrezime.Name = "pnlImePrezime";
            this.pnlImePrezime.Size = new System.Drawing.Size(rw, 70);
            this.pnlImePrezime.TabIndex = 4;
            this.pnlImePrezime.Controls.Add(this.lblIme);
            this.pnlImePrezime.Controls.Add(this.txtIme);
            this.pnlImePrezime.Controls.Add(this.lblPrezime);
            this.pnlImePrezime.Controls.Add(this.txtPrezime);

            this.lblIme.AutoSize = true;
            this.lblIme.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblIme.ForeColor = System.Drawing.Color.FromArgb(70, 80, 100);
            this.lblIme.Location = new System.Drawing.Point(0, 0);
            this.lblIme.Name = "lblIme";
            this.lblIme.Text = "Ime (opciono)";

            this.txtIme.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtIme.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtIme.Location = new System.Drawing.Point(0, 18);
            this.txtIme.Name = "txtIme";
            this.txtIme.Size = new System.Drawing.Size(142, 26);
            this.txtIme.TabIndex = 0;

            this.lblPrezime.AutoSize = true;
            this.lblPrezime.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblPrezime.ForeColor = System.Drawing.Color.FromArgb(70, 80, 100);
            this.lblPrezime.Location = new System.Drawing.Point(155, 0);
            this.lblPrezime.Name = "lblPrezime";
            this.lblPrezime.Text = "Prezime (opciono)";

            this.txtPrezime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPrezime.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtPrezime.Location = new System.Drawing.Point(155, 18);
            this.txtPrezime.Name = "txtPrezime";
            this.txtPrezime.Size = new System.Drawing.Size(142, 26);
            this.txtPrezime.TabIndex = 1;

            // lblStatus (greske / potvrde)
            this.lblStatus.AutoSize = false;
            this.lblStatus.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblStatus.ForeColor = System.Drawing.Color.FromArgb(220, 53, 69);
            this.lblStatus.Location = new System.Drawing.Point(rx, 375);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(rw, 18);
            this.lblStatus.Text = "";

            // btnRegistruj
            this.btnRegistruj.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegistruj.FlatAppearance.BorderSize = 0;
            this.btnRegistruj.BackColor = System.Drawing.Color.FromArgb(30, 58, 95);
            this.btnRegistruj.ForeColor = System.Drawing.Color.White;
            this.btnRegistruj.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRegistruj.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnRegistruj.Location = new System.Drawing.Point(rx, 400);
            this.btnRegistruj.Name = "btnRegistruj";
            this.btnRegistruj.Size = new System.Drawing.Size(rw, 42);
            this.btnRegistruj.TabIndex = 5;
            this.btnRegistruj.Text = "Kreiraj nalog";
            this.btnRegistruj.Click += new System.EventHandler(this.btnRegistruj_Click);

            // Divider
            this.pnlLinija.BackColor = System.Drawing.Color.FromArgb(225, 228, 235);
            this.pnlLinija.Location = new System.Drawing.Point(rx, 452);
            this.pnlLinija.Name = "pnlLinija";
            this.pnlLinija.Size = new System.Drawing.Size(rw, 1);

            // "Vec imas nalog?"
            this.lblVecPostojiAcc.AutoSize = true;
            this.lblVecPostojiAcc.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblVecPostojiAcc.ForeColor = System.Drawing.Color.FromArgb(130, 140, 160);
            this.lblVecPostojiAcc.Location = new System.Drawing.Point(rx, 462);
            this.lblVecPostojiAcc.Name = "lblVecPostojiAcc";
            this.lblVecPostojiAcc.Text = "Vec imas nalog?";

            // btnNazad (link-style)
            this.btnNazad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNazad.FlatAppearance.BorderSize = 0;
            this.btnNazad.BackColor = System.Drawing.Color.White;
            this.btnNazad.ForeColor = System.Drawing.Color.FromArgb(30, 58, 95);
            this.btnNazad.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNazad.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline);
            this.btnNazad.Location = new System.Drawing.Point(rx + 130, 458);
            this.btnNazad.Name = "btnNazad";
            this.btnNazad.Size = new System.Drawing.Size(110, 24);
            this.btnNazad.TabIndex = 6;
            this.btnNazad.Text = "Nazad na login";
            this.btnNazad.Click += new System.EventHandler(this.btnNazad_Click);

            // ── FrmRegistracija ──────────────────────────────────────────
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(630, 510);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "FrmRegistracija";
            this.Text = "Registracija";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;

            // Fill first, Left last
            this.Controls.Add(this.pnlDesno);
            this.Controls.Add(this.pnlLijevo);

            this.pnlLijevo.ResumeLayout(false);
            this.pnlDesno.ResumeLayout(false);
            this.pnlDesno.PerformLayout();
            this.pnlImePrezime.ResumeLayout(false);
            this.pnlImePrezime.PerformLayout();
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Panel       pnlLijevo;
        private System.Windows.Forms.Label       lblLogo;
        private System.Windows.Forms.Label       lblTagline;
        private System.Windows.Forms.Label       lblBulletsTitle;
        private System.Windows.Forms.Label       lblBullet1;
        private System.Windows.Forms.Label       lblBullet2;
        private System.Windows.Forms.Label       lblBullet3;
        private System.Windows.Forms.Panel       pnlDesno;
        private System.Windows.Forms.Label       lblNaslov;
        private System.Windows.Forms.Label       lblPodnaslov;
        private System.Windows.Forms.Label       lblUsername;
        private System.Windows.Forms.TextBox     txtUsername;
        private System.Windows.Forms.Label       lblLozinka;
        private System.Windows.Forms.TextBox     txtLozinka;
        private System.Windows.Forms.Label       lblPotvrda;
        private System.Windows.Forms.TextBox     txtPotvrda;
        private System.Windows.Forms.CheckBox    chkPokaziLozinku;
        private System.Windows.Forms.Panel       pnlImePrezime;
        private System.Windows.Forms.Label       lblIme;
        private System.Windows.Forms.TextBox     txtIme;
        private System.Windows.Forms.Label       lblPrezime;
        private System.Windows.Forms.TextBox     txtPrezime;
        private System.Windows.Forms.Label       lblStatus;
        private System.Windows.Forms.Button      btnRegistruj;
        private System.Windows.Forms.Panel       pnlLinija;
        private System.Windows.Forms.Label       lblVecPostojiAcc;
        private System.Windows.Forms.Button      btnNazad;
    }
}
