using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApplication1
{
    public partial class FrmVjezbe : Form
    {
        private List<Vjezba> listaVjezb         = new List<Vjezba>();
        private List<Vjezba> sveVjezbe          = new List<Vjezba>();
        private string       trenutniSortKolona = "";
        private bool         sortAsc            = true;
        private string       filterTip          = "";
        private string       filterGrupa        = "";
        bool darkMode   = false;
        int  hoveredRow = -1;
        public Vjezba OdabranaVjezba { get; set; }

        private static string TipIkona(string tip)
        {
            if (tip == null) return "❓";
            switch (tip.Trim())
            {
                case "Snaga":        return "🏋️ Snaga";
                case "Kardio":       return "🏃 Kardio";
                case "Mobilnost":    return "🧘 Mobilnost";
                case "Izdrzljivost": return "💪 Izdržljivost";
                default:             return "🏅 " + tip;
            }
        }

        private static Color TipBoja(string tip)
        {
            if (tip == null) return Color.LightGray;
            switch (tip.Trim())
            {
                case "Snaga":        return Color.FromArgb(255, 230, 220); // narandzasto-crvena
                case "Kardio":       return Color.FromArgb(215, 245, 215); // zelena
                case "Mobilnost":    return Color.FromArgb(215, 235, 255); // plava
                case "Izdrzljivost": return Color.FromArgb(235, 220, 255); // ljubicasta
                default:             return Color.FromArgb(240, 240, 240);
            }
        }

        private static Color TipBojaTamna(string tip)
        {
            if (tip == null) return Color.Gray;
            switch (tip.Trim())
            {
                case "Snaga":        return Color.FromArgb(200, 70,  20);
                case "Kardio":       return Color.FromArgb(30,  140, 60);
                case "Mobilnost":    return Color.FromArgb(30,  100, 200);
                case "Izdrzljivost": return Color.FromArgb(120, 40,  200);
                default:             return Color.FromArgb(80, 80, 80);
            }
        }

        private static string GrupaIkona(string grupa)
        {
            if (grupa == null) return "";
            switch (grupa.Trim())
            {
                case "Prsa":          return "💪 Prsa";
                case "Ledja":         return "🔙 Leđa";
                case "Noge":          return "🦵 Noge";
                case "Ruke":          return "🤜 Ruke";
                case "Ramena":        return "🏔️ Ramena";
                case "Cijelo tijelo": return "⚡ Cijelo tijelo";
                default:              return grupa;
            }
        }

        public FrmVjezbe()
        {
            InitializeComponent();
        }
        private void UcitajIzBaze()
        {
            sveVjezbe.Clear();
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                {
                    string sql = "SELECT VjezbaID, Naziv, Opis, Tip, MisicnaGrupa FROM vjezba";
                    using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                    using (MySqlDataReader r = cmd.ExecuteReader())
                        while (r.Read())
                            sveVjezbe.Add(new Vjezba
                            {
                                VjezbaID     = r.GetInt32(0),
                                Naziv        = r.GetString(1),
                                Opis         = r.IsDBNull(2) ? "" : r.GetString(2),
                                Tip          = r.GetString(3),
                                MisicnaGrupa = r.GetString(4)
                            });
                }
            }
            catch (Exception ex) { MessageBox.Show("Greška pri učitavanju vježbi: " + ex.Message); }
            listaVjezb = new List<Vjezba>(sveVjezbe);
            UcitajListu();
        }

        private void UcitajListu()
        {
            dgvVjezbe.Rows.Clear();
            foreach (Vjezba v in listaVjezb)
            {
                int idx = dgvVjezbe.Rows.Add(
                    TipIkona(v.Tip),
                    v.VjezbaID,
                    v.Naziv,
                    v.Opis,
                    GrupaIkona(v.MisicnaGrupa)
                );
                Color c = TipBoja(v.Tip);
                dgvVjezbe.Rows[idx].DefaultCellStyle.BackColor = c;
                dgvVjezbe.Rows[idx].Cells["cIkona"].Style.ForeColor = TipBojaTamna(v.Tip);
                dgvVjezbe.Rows[idx].Cells["cIkona"].Style.Font =
                    new Font("Segoe UI", 9f, FontStyle.Bold);
            }
        }

        private void OcistiPolja()
        {
            txtNaziv.Clear();
            txtOpis.Clear();
            cmbTip.SelectedIndex   = 0;
            cmbGrupa.SelectedIndex = 0;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (txtNaziv.Text.Trim() == "")
            { MessageBox.Show("Upisite naziv vježbe!"); return; }
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                {
                    string sql = "INSERT INTO vjezba (Naziv, Opis, Tip, MisicnaGrupa) " +
                                 "VALUES (@n, @o, @t, @g)";
                    using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@n", txtNaziv.Text.Trim());
                        cmd.Parameters.AddWithValue("@o", txtOpis.Text.Trim());
                        cmd.Parameters.AddWithValue("@t", cmbTip.SelectedItem.ToString());
                        cmd.Parameters.AddWithValue("@g", cmbGrupa.SelectedItem.ToString());
                        cmd.ExecuteNonQuery();
                    }
                }
                MessageBox.Show("Vježba dodana!");
                OcistiPolja();
                UcitajIzBaze();
            }
            catch (Exception ex) { MessageBox.Show("Greška pri dodavanju: " + ex.Message); }
        }

        private void btnAzuriraj_Click(object sender, EventArgs e)
        {
            if (dgvVjezbe.CurrentRow == null) return;
            int id = Convert.ToInt32(dgvVjezbe.CurrentRow.Cells["VjezbaID"].Value);
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                {
                    string sql = "UPDATE vjezba SET Naziv=@n, Opis=@o, Tip=@t, MisicnaGrupa=@g " +
                                 "WHERE VjezbaID=@id";
                    using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@n",  txtNaziv.Text.Trim());
                        cmd.Parameters.AddWithValue("@o",  txtOpis.Text.Trim());
                        cmd.Parameters.AddWithValue("@t",  cmbTip.SelectedItem.ToString());
                        cmd.Parameters.AddWithValue("@g",  cmbGrupa.SelectedItem.ToString());
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.ExecuteNonQuery();
                    }
                }
                MessageBox.Show("Ažurirano!");
                UcitajIzBaze();
            }
            catch (Exception ex) { MessageBox.Show("Greška pri ažuriranju: " + ex.Message); }
        }

        private void btnObrisi_Click(object sender, EventArgs e)
        {
            if (dgvVjezbe.CurrentRow == null) return;
            if (MessageBox.Show("Sigurno obrisati?", "Potvrda",
                MessageBoxButtons.YesNo) != DialogResult.Yes) return;
            int id = Convert.ToInt32(dgvVjezbe.CurrentRow.Cells["VjezbaID"].Value);
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                using (MySqlCommand cmd = new MySqlCommand(
                    "DELETE FROM vjezba WHERE VjezbaID=@id", conn))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.ExecuteNonQuery();
                }
                MessageBox.Show("Obrisano!");
                OcistiPolja();
                UcitajIzBaze();
            }
            catch (Exception ex) { MessageBox.Show("Greška pri brisanju: " + ex.Message); }
        }

        private void FrmVjezbe_Load(object sender, EventArgs e)
        {
            UrediGrid();
            dgvVjezbe.AutoGenerateColumns = false;
            dgvVjezbe.Columns.Clear();

            var colIkona = new DataGridViewTextBoxColumn();
            colIkona.HeaderText = "Tip";
            colIkona.Name       = "cIkona";
            colIkona.Width      = 130;
            dgvVjezbe.Columns.Add(colIkona);

            dgvVjezbe.Columns.Add(new DataGridViewTextBoxColumn
                { HeaderText = "ID",    Name = "VjezbaID",    Width = 40  });
            dgvVjezbe.Columns.Add(new DataGridViewTextBoxColumn
                { HeaderText = "Naziv", Name = "Naziv",        Width = 140 });
            dgvVjezbe.Columns.Add(new DataGridViewTextBoxColumn
                { HeaderText = "Opis",  Name = "Opis",          Width = 310 });
            dgvVjezbe.Columns.Add(new DataGridViewTextBoxColumn
                { HeaderText = "Mišićna grupa", Name = "MisicnaGrupa", Width = 130 });

            dgvVjezbe.Columns["VjezbaID"].Visible = false;

            cmbTip.Items.Clear();
            cmbTip.Items.AddRange(new object[]
                { "Snaga", "Kardio", "Mobilnost", "Izdrzljivost" });
            cmbTip.SelectedIndex = 0;

            cmbGrupa.Items.Clear();
            cmbGrupa.Items.AddRange(new object[]
                { "Prsa", "Ledja", "Noge", "Ruke", "Ramena", "Cijelo tijelo" });
            cmbGrupa.SelectedIndex = 0;

            cmbFilterTip.Items.AddRange(new string[]
                { "Svi", "Snaga", "Kardio", "Mobilnost", "Izdrzljivost" });
            cmbFilterTip.SelectedIndex = 0;
            cmbFilterGrupa.Items.AddRange(new string[]
                { "Sve", "Prsa", "Ledja", "Noge", "Ruke", "Ramena", "Cijelo tijelo" });
            cmbFilterGrupa.SelectedIndex = 0;

            cmbFilterTip.SelectedIndexChanged  += cmbFilterTip_SelectedIndexChanged;
            cmbFilterGrupa.SelectedIndexChanged += cmbFilterGrupa_SelectedIndexChanged;
            dgvVjezbe.ColumnHeaderMouseClick   += dgvVjezbe_ColumnHeaderMouseClick;

            UcitajIzBaze();
        }

        private void btnNovo_Click(object sender, EventArgs e)      { OcistiPolja(); }
        private void btnUcitajSve_Click(object sender, EventArgs e) { UcitajIzBaze(); }
        private void dgvVjezbe_SelectionChanged(object sender, EventArgs e) { }
        private void label2_Click(object sender, EventArgs e) { }
        private void label3_Click(object sender, EventArgs e) { }
        private void label1_Click(object sender, EventArgs e) { }
        private void txtTip_TextChanged(object sender, EventArgs e) { }
        private void label4_Click(object sender, EventArgs e) { }
        private void txtMisicnaGrupa_TextChanged(object sender, EventArgs e) { }
        private void txtNaziv_TextChanged(object sender, EventArgs e) { }
        private void dgvVjezbe_CellContentClick(object sender, DataGridViewCellEventArgs e) { }

        private void UrediGrid()
        {
            dgvVjezbe.BorderStyle           = BorderStyle.None;
            dgvVjezbe.CellBorderStyle       = DataGridViewCellBorderStyle.SingleHorizontal;
            dgvVjezbe.GridColor             = Color.FromArgb(220, 220, 225);
            dgvVjezbe.RowHeadersVisible     = false;
            dgvVjezbe.EnableHeadersVisualStyles = false;
            dgvVjezbe.AutoSizeColumnsMode   = DataGridViewAutoSizeColumnsMode.None;
            dgvVjezbe.SelectionMode         = DataGridViewSelectionMode.FullRowSelect;
            dgvVjezbe.AllowUserToAddRows    = false;
            dgvVjezbe.ReadOnly              = false;

            dgvVjezbe.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(30, 30, 40);
            dgvVjezbe.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgvVjezbe.ColumnHeadersDefaultCellStyle.Font      =
                new Font("Segoe UI", 10, FontStyle.Bold);
            dgvVjezbe.ColumnHeadersHeight  = 42;
            dgvVjezbe.DefaultCellStyle.Font = new Font("Segoe UI", 9.5f);
            dgvVjezbe.DefaultCellStyle.Padding = new Padding(6, 4, 6, 4);
            dgvVjezbe.DefaultCellStyle.SelectionBackColor =
                Color.FromArgb(80, 60, 180);
            dgvVjezbe.DefaultCellStyle.SelectionForeColor = Color.White;
            dgvVjezbe.RowTemplate.Height = 36;

            dgvVjezbe.RowPrePaint    += dgvVjezbe_RowPrePaint;
            dgvVjezbe.CellMouseEnter += dgvVjezbe_CellMouseEnter;
            dgvVjezbe.CellMouseLeave += dgvVjezbe_CellMouseLeave;
            dgvVjezbe.MouseUp        += dgvVjezbe_MouseUp;
        }

        private void dgvVjezbe_CellMouseEnter(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            hoveredRow = e.RowIndex;
            dgvVjezbe.InvalidateRow(e.RowIndex);
        }

        private void dgvVjezbe_CellMouseLeave(object sender, DataGridViewCellEventArgs e)
        {
            int prev = hoveredRow;
            hoveredRow = -1;
            if (prev >= 0 && prev < dgvVjezbe.Rows.Count)
                dgvVjezbe.InvalidateRow(prev);
        }

        private void dgvVjezbe_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            if (e.RowIndex < 0 || e.RowIndex >= listaVjezb.Count) return;

            string tip = listaVjezb[e.RowIndex].Tip;
            Color  baseColor;

            if (darkMode)
                baseColor = (e.RowIndex % 2 == 0)
                    ? Color.FromArgb(45, 45, 45) : Color.FromArgb(55, 55, 55);
            else
                baseColor = TipBoja(tip);

            if (e.RowIndex == hoveredRow)
            {
                baseColor = darkMode
                    ? Color.FromArgb(70, 70, 70)
                    : ControlPaint.Dark(TipBoja(tip), 0.08f);
            }

            dgvVjezbe.Rows[e.RowIndex].DefaultCellStyle.BackColor = baseColor;

            if (dgvVjezbe.Rows[e.RowIndex].Cells.Count > 0)
            {
                dgvVjezbe.Rows[e.RowIndex].Cells["cIkona"].Style.ForeColor =
                    darkMode ? Color.White : TipBojaTamna(tip);
                dgvVjezbe.Rows[e.RowIndex].Cells["cIkona"].Style.Font =
                    new Font("Segoe UI", 9.5f, FontStyle.Bold);
            }
        }

        private void btnTheme_Click(object sender, EventArgs e)
        {
            darkMode = !darkMode;
            if (darkMode)
            {
                BackColor = Color.FromArgb(25, 25, 35);
                dgvVjezbe.BackgroundColor = Color.FromArgb(35, 35, 45);
                dgvVjezbe.DefaultCellStyle.ForeColor = Color.White;
                dgvVjezbe.ColumnHeadersDefaultCellStyle.BackColor =
                    Color.FromArgb(15, 15, 25);
                dgvVjezbe.GridColor = Color.FromArgb(60, 60, 70);
                label1.ForeColor = Color.White; label2.ForeColor = Color.White;
                label3.ForeColor = Color.White; label4.ForeColor = Color.White;
                btnTheme.Text = "🌞 Light Mode";
                btnTheme.BackColor = Color.FromArgb(50, 50, 70);
                btnTheme.ForeColor = Color.White;
            }
            else
            {
                BackColor = Color.FromArgb(245, 247, 250);
                dgvVjezbe.BackgroundColor = Color.White;
                dgvVjezbe.DefaultCellStyle.ForeColor = Color.Black;
                dgvVjezbe.ColumnHeadersDefaultCellStyle.BackColor =
                    Color.FromArgb(30, 30, 40);
                dgvVjezbe.GridColor = Color.FromArgb(220, 220, 225);
                label1.ForeColor = Color.FromArgb(50, 50, 70);
                label2.ForeColor = Color.FromArgb(50, 50, 70);
                label3.ForeColor = Color.FromArgb(50, 50, 70);
                label4.ForeColor = Color.FromArgb(50, 50, 70);
                btnTheme.Text = "🌙 Dark Mode";
                btnTheme.BackColor = Color.FromArgb(245, 247, 250);
                btnTheme.ForeColor = Color.FromArgb(30, 30, 40);
            }
            dgvVjezbe.Refresh();
        }

        private void FrmVjezbe_Click(object sender, EventArgs e) { }
        private void dgvVjezbe_Click(object sender, EventArgs e) { }

        private void dgvVjezbe_MouseUp(object sender, MouseEventArgs e)
        {
            var hit = dgvVjezbe.HitTest(e.X, e.Y);
            if (hit.Type == DataGridViewHitTestType.None)
            {
                dgvVjezbe.ClearSelection();
                dgvVjezbe.CurrentCell = null;
                OcistiPolja();
                dgvVjezbe.Refresh();
            }
        }

        private void PrimijeniFilterISort()
        {
            var podaci = sveVjezbe.AsQueryable();
            if (!string.IsNullOrEmpty(filterTip))
                podaci = podaci.Where(v => v.Tip == filterTip);
            if (!string.IsNullOrEmpty(filterGrupa))
                podaci = podaci.Where(v => v.MisicnaGrupa == filterGrupa);
            if (trenutniSortKolona == "Tip")
                podaci = sortAsc
                    ? podaci.OrderBy(v => v.Tip)
                    : podaci.OrderByDescending(v => v.Tip);
            else if (trenutniSortKolona == "MisicnaGrupa")
                podaci = sortAsc
                    ? podaci.OrderBy(v => v.MisicnaGrupa)
                    : podaci.OrderByDescending(v => v.MisicnaGrupa);
            listaVjezb = podaci.ToList();
            UcitajListu();
        }

        private void cmbFilterTip_SelectedIndexChanged(object sender, EventArgs e)
        {
            filterTip = cmbFilterTip.SelectedItem.ToString();
            if (filterTip == "Svi") filterTip = "";
            PrimijeniFilterISort();
        }

        private void cmbFilterGrupa_SelectedIndexChanged(object sender, EventArgs e)
        {
            filterGrupa = cmbFilterGrupa.SelectedItem.ToString();
            if (filterGrupa == "Sve") filterGrupa = "";
            PrimijeniFilterISort();
        }

        private void dgvVjezbe_ColumnHeaderMouseClick(object sender,
            DataGridViewCellMouseEventArgs e)
        {
            string kolona = dgvVjezbe.Columns[e.ColumnIndex].Name;
            if (kolona != "cIkona" && kolona != "MisicnaGrupa") return;
            if (trenutniSortKolona == kolona) sortAsc = !sortAsc;
            else { sortAsc = true; trenutniSortKolona = kolona; }
            PrimijeniFilterISort();
        }

        private void dgvVjezbe_DoubleClick(object sender, EventArgs e)
        {
            if (dgvVjezbe.CurrentRow == null) return;
            int id = Convert.ToInt32(dgvVjezbe.CurrentRow.Cells["VjezbaID"].Value);
            OdabranaVjezba = listaVjezb.FirstOrDefault(x => x.VjezbaID == id);
            if (OdabranaVjezba != null) { DialogResult = DialogResult.OK; Close(); }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dgvVjezbe.CurrentRow == null)
            { MessageBox.Show("Odaberi vježbu iz liste!"); return; }
            int id = Convert.ToInt32(dgvVjezbe.CurrentRow.Cells["VjezbaID"].Value);
            OdabranaVjezba = listaVjezb.FirstOrDefault(x => x.VjezbaID == id);
            if (OdabranaVjezba != null) { DialogResult = DialogResult.OK; Close(); }
            else MessageBox.Show("Vježba nije pronađena!");
        }

        private void label7_Click(object sender, EventArgs e) { }

        public class Vjezba
        {
            public int    VjezbaID         { get; set; }
            public string Naziv            { get; set; }
            public string Opis             { get; set; }
            public string Tip              { get; set; }
            public string MisicnaGrupa     { get; set; }
            public int    PlaniraniSetovi  { get; set; }
            public int    UradjeniSetovi   { get; set; }
            public bool   Uradjeno         { get; set; }
        }
    }
}
