using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApplication1
{
    public partial class FrmEvidencija : Form
    {
        private Panel        pnlLijevo;
        private Panel        pnlLijevoHeader;
        private Label        lblLogo;
        private Label        lblFilterLbl;
        private ComboBox     cmbVjezbe;
        private Label        lblChartTipLbl;
        private ComboBox     cmbChartTip;
        private Label        lblTreninziLbl;
        private ListBox      lstTreninzi;
        private Label        lblUkupno;
        private Panel        pnlDesno;
        private Panel        pnlChart;
        private Label        lblChartNaslov;
        private Label        lblDetaljiNaslov;
        private DataGridView dgvDetalji;

        private List<ProgressTacka> chartTacke       = new List<ProgressTacka>();
        private int                 odabraniTreningID = -1;

        private class ProgressTacka
        {
            public DateTime Datum;
            public double   MaxKg;
            public int      Setovi;
            public int      Ponavljanja;
            public double Volumen
            {
                get { return Setovi * Ponavljanja * MaxKg; }
            }
        }

        private class TreningItem
        {
            public int      TreningID;
            public DateTime Datum;
            public string   PlanNaziv;
            public override string ToString()
            {
                return Datum.ToString("dd.MM.yyyy") + "  —  " + PlanNaziv;
            }
        }

        private class VjezbaItem
        {
            public int    VjezbaID;
            public string Naziv;
            public override string ToString() { return Naziv; }
        }

        private class DetaljiRed
        {
            public int    VjezbaID;
            public string Naziv;
            public int    Setovi;
            public int    Ponavljanja;
            public double MaxKg;
            public bool   Gotovo;
        }

        public FrmEvidencija()
        {
            InitializeComponent();
            GradiForme();
            PrimijeniStil();
            UcitajVjezbe();
            UcitajTreningHistoriju();
        }

        private void GradiForme()
        {
            this.SuspendLayout();
            this.Text          = "Evidencija i Napredak";
            this.ClientSize    = new Size(1160, 720);
            this.MinimumSize   = new Size(1160, 720);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Font          = new Font("Segoe UI", 9f);

            pnlLijevo = new Panel { Dock = DockStyle.Left, Size = new Size(258, 720) };

            pnlLijevoHeader = new Panel { Dock = DockStyle.Top, Height = 78 };
            lblLogo = new Label
            {
                Text     = "Evidencija",
                Location = new Point(14, 22),
                AutoSize = true
            };
            pnlLijevoHeader.Controls.Add(lblLogo);
            pnlLijevo.Controls.Add(pnlLijevoHeader);

            lblFilterLbl = new Label
            { Text = "Napredak po vjezbi:", Location = new Point(12, 90), AutoSize = true };

            cmbVjezbe = new ComboBox
            {
                Location      = new Point(12, 110),
                Size          = new Size(230, 24),
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            cmbVjezbe.SelectedIndexChanged += cmbVjezbe_SelectedIndexChanged;

            lblChartTipLbl = new Label
            { Text = "Prikaz charta:", Location = new Point(12, 144), AutoSize = true };

            cmbChartTip = new ComboBox
            {
                Location      = new Point(12, 162),
                Size          = new Size(230, 24),
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            cmbChartTip.Items.AddRange(new object[]
                { "Max kilaza (kg)", "Volumen (serije x pon x kg)" });
            cmbChartTip.SelectedIndex            = 0;
            cmbChartTip.SelectedIndexChanged    += (s, ev) => pnlChart.Invalidate();

            lblTreninziLbl = new Label
            { Text = "Historija treninga:", Location = new Point(12, 196), AutoSize = true };

            lstTreninzi = new ListBox
            {
                Location    = new Point(12, 216),
                Size        = new Size(230, 430),
                BorderStyle = BorderStyle.None,
                DrawMode    = DrawMode.OwnerDrawFixed,
                ItemHeight  = 36
            };
            lstTreninzi.DrawItem             += lstTreninzi_DrawItem;
            lstTreninzi.SelectedIndexChanged += lstTreninzi_SelectedIndexChanged;

            lblUkupno = new Label
            { Text = "", Location = new Point(12, 656), AutoSize = true };

            pnlLijevo.Controls.AddRange(new Control[] {
                lblFilterLbl, cmbVjezbe,
                lblChartTipLbl, cmbChartTip,
                lblTreninziLbl, lstTreninzi, lblUkupno
            });

            pnlDesno = new Panel { Dock = DockStyle.Fill, Padding = new Padding(16) };

            pnlChart = new Panel
            {
                Location    = new Point(16, 16),
                Size        = new Size(860, 240),
                BorderStyle = BorderStyle.None
            };
            lblChartNaslov = new Label
            { Text = "Odaberi vjezbu da vidis napredak", Location = new Point(8, 6), AutoSize = true };
            pnlChart.Controls.Add(lblChartNaslov);
            pnlChart.Paint += pnlChart_Paint;

            lblDetaljiNaslov = new Label
            { Text = "Klikni na trening sa lijeve strane:", Location = new Point(16, 272), AutoSize = true };

            dgvDetalji = new DataGridView
            {
                Location              = new Point(16, 296),
                Size                  = new Size(860, 400),
                ReadOnly              = true,
                AllowUserToAddRows    = false,
                SelectionMode         = DataGridViewSelectionMode.FullRowSelect,
                AutoGenerateColumns   = false,
                ColumnHeadersHeightSizeMode =
                    DataGridViewColumnHeadersHeightSizeMode.DisableResizing,
                ColumnHeadersHeight   = 40
            };
            dgvDetalji.Columns.Add(new DataGridViewTextBoxColumn
                { HeaderText = "Vjezba",         Name = "dNaziv",  Width = 200 });
            dgvDetalji.Columns.Add(new DataGridViewTextBoxColumn
                { HeaderText = "Serije",          Name = "dSetovi", Width = 75  });
            dgvDetalji.Columns.Add(new DataGridViewTextBoxColumn
                { HeaderText = "Ponavljanja",      Name = "dPon",    Width = 100 });
            dgvDetalji.Columns.Add(new DataGridViewTextBoxColumn
                { HeaderText = "Max kilaza",       Name = "dKg",     Width = 110 });
            dgvDetalji.Columns.Add(new DataGridViewTextBoxColumn
                { HeaderText = "Volumen",          Name = "dVol",    Width = 100 });
            dgvDetalji.Columns.Add(new DataGridViewTextBoxColumn
                { HeaderText = "Uradjeno",         Name = "dGot",    Width = 75  });
            dgvDetalji.Columns.Add(new DataGridViewTextBoxColumn
                { HeaderText = "Preth. volumen",   Name = "dPrVol",  Width = 130 });
            dgvDetalji.Columns.Add(new DataGridViewTextBoxColumn
                { HeaderText = "Delta",            Name = "dDelta",  Width = 90  });

            pnlDesno.Controls.AddRange(new Control[] { pnlChart, lblDetaljiNaslov, dgvDetalji });

            this.Controls.Add(pnlDesno);
            this.Controls.Add(pnlLijevo);
            this.ResumeLayout(false);
        }

        private void PrimijeniStil()
        {
            this.BackColor            = Color.FromArgb(245, 247, 250);
            pnlLijevo.BackColor       = Color.FromArgb(28, 28, 38);
            pnlLijevoHeader.BackColor = Color.FromArgb(20, 20, 30);
            lblLogo.ForeColor         = Color.White;
            lblLogo.Font              = new Font("Segoe UI", 14f, FontStyle.Bold);
            lblFilterLbl.ForeColor    = Color.FromArgb(160, 160, 200);
            lblFilterLbl.Font         = new Font("Segoe UI", 9f, FontStyle.Bold);
            lblChartTipLbl.ForeColor  = Color.FromArgb(160, 160, 200);
            lblChartTipLbl.Font       = new Font("Segoe UI", 9f, FontStyle.Bold);
            lblTreninziLbl.ForeColor  = Color.FromArgb(160, 160, 200);
            lblTreninziLbl.Font       = new Font("Segoe UI", 9f, FontStyle.Bold);
            lstTreninzi.BackColor     = Color.FromArgb(28, 28, 38);
            lstTreninzi.ForeColor     = Color.White;
            lblUkupno.ForeColor       = Color.FromArgb(110, 110, 150);
            lblUkupno.Font            = new Font("Segoe UI", 9f);

            pnlDesno.BackColor         = Color.FromArgb(245, 247, 250);
            pnlChart.BackColor         = Color.White;
            lblChartNaslov.Font        = new Font("Segoe UI", 10f, FontStyle.Bold);
            lblChartNaslov.ForeColor   = Color.FromArgb(28, 28, 38);
            lblDetaljiNaslov.Font      = new Font("Segoe UI", 10f, FontStyle.Bold);
            lblDetaljiNaslov.ForeColor = Color.FromArgb(28, 28, 38);

            dgvDetalji.BackgroundColor = Color.White;
            dgvDetalji.BorderStyle     = BorderStyle.None;
            dgvDetalji.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgvDetalji.GridColor       = Color.FromArgb(220, 220, 228);
            dgvDetalji.RowHeadersVisible          = false;
            dgvDetalji.EnableHeadersVisualStyles   = false;
            dgvDetalji.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(28, 28, 38);
            dgvDetalji.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgvDetalji.ColumnHeadersDefaultCellStyle.Font =
                new Font("Segoe UI", 9f, FontStyle.Bold);
            dgvDetalji.DefaultCellStyle.Font    = new Font("Segoe UI", 9f);
            dgvDetalji.DefaultCellStyle.Padding = new Padding(6, 3, 6, 3);
            dgvDetalji.DefaultCellStyle.SelectionBackColor = Color.FromArgb(88, 86, 214);
            dgvDetalji.DefaultCellStyle.SelectionForeColor = Color.White;
            dgvDetalji.RowTemplate.Height = 32;
        }

        private void lstTreninzi_DrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0) return;
            bool sel = (e.State & DrawItemState.Selected) != 0;
            Color bg = sel
                ? Color.FromArgb(88, 86, 214)
                : (e.Index % 2 == 0
                    ? Color.FromArgb(34, 34, 46)
                    : Color.FromArgb(28, 28, 38));
            e.Graphics.FillRectangle(new SolidBrush(bg), e.Bounds);
            e.Graphics.DrawString(
                lstTreninzi.Items[e.Index].ToString(),
                new Font("Segoe UI", 8.5f, sel ? FontStyle.Bold : FontStyle.Regular),
                new SolidBrush(Color.White),
                new PointF(e.Bounds.X + 8, e.Bounds.Y + 9));
        }

        private void UcitajVjezbe()
        {
            cmbVjezbe.Items.Clear();
            cmbVjezbe.Items.Add(new VjezbaItem { VjezbaID = -1, Naziv = "-- Odaberi vjezbu --" });
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                using (MySqlCommand cmd = new MySqlCommand(
                    "SELECT DISTINCT v.VjezbaID, v.Naziv " +
                    "FROM treningvjezba tv " +
                    "JOIN vjezba v ON v.VjezbaID=tv.VjezbaID " +
                    "JOIN trening t ON t.TreningID=tv.TreningID " +
                    "WHERE t.KorisnikID=@kid ORDER BY v.Naziv", conn))
                {
                    cmd.Parameters.AddWithValue("@kid", KorisnikManager.TrenutniKorisnikID);
                    using (MySqlDataReader r = cmd.ExecuteReader())
                        while (r.Read())
                            cmbVjezbe.Items.Add(new VjezbaItem
                                { VjezbaID = r.GetInt32(0), Naziv = r.GetString(1) });
                }
            }
            catch { }
            cmbVjezbe.SelectedIndex = 0;
        }

        private void UcitajTreningHistoriju()
        {
            lstTreninzi.Items.Clear();
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                using (MySqlCommand cmd = new MySqlCommand(
                    "SELECT t.TreningID, t.Datum, COALESCE(tp.Naziv,'Bez plana') " +
                    "FROM trening t " +
                    "LEFT JOIN treningplan tp ON tp.PlanID=t.PlanID " +
                    "WHERE t.KorisnikID=@kid ORDER BY t.Datum DESC", conn))
                {
                    cmd.Parameters.AddWithValue("@kid", KorisnikManager.TrenutniKorisnikID);
                    using (MySqlDataReader r = cmd.ExecuteReader())
                        while (r.Read())
                            lstTreninzi.Items.Add(new TreningItem
                            {
                                TreningID = r.GetInt32(0),
                                Datum     = r.GetDateTime(1),
                                PlanNaziv = r.GetString(2)
                            });
                }
            }
            catch (Exception ex) { MessageBox.Show("Greska: " + ex.Message); }
            lblUkupno.Text = "Ukupno treninga: " + lstTreninzi.Items.Count;
        }

        private void lstTreninzi_SelectedIndexChanged(object sender, EventArgs e)
        {
            var item = lstTreninzi.SelectedItem as TreningItem;
            if (item == null) return;
            odabraniTreningID = item.TreningID;
            UcitajDetalje(item.TreningID, item.Datum);
        }

        private void UcitajDetalje(int treningID, DateTime datum)
        {
            dgvDetalji.Rows.Clear();
            lblDetaljiNaslov.Text = "Trening od " + datum.ToString("dd.MM.yyyy") + ":";

            var redovi = new List<DetaljiRed>();
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                using (MySqlCommand cmd = new MySqlCommand(
                    "SELECT tv.VjezbaID, v.Naziv, tv.OdradjeniSetovi, " +
                    "tv.OdradjenaPonavlajnja, tv.MaxTezina, tv.Uradjeno " +
                    "FROM treningvjezba tv " +
                    "JOIN vjezba v ON v.VjezbaID=tv.VjezbaID " +
                    "WHERE tv.TreningID=@tid ORDER BY v.Naziv", conn))
                {
                    cmd.Parameters.AddWithValue("@tid", treningID);
                    using (MySqlDataReader r = cmd.ExecuteReader())
                        while (r.Read())
                            redovi.Add(new DetaljiRed
                            {
                                VjezbaID    = r.GetInt32(0),
                                Naziv       = r.GetString(1),
                                Setovi      = r.IsDBNull(2) ? 0 : r.GetInt32(2),
                                Ponavljanja = r.IsDBNull(3) ? 0 : r.GetInt32(3),
                                MaxKg       = r.IsDBNull(4) ? 0 : r.GetDouble(4),
                                Gotovo      = !r.IsDBNull(5) && r.GetInt32(5) == 1
                            });
                }
            }
            catch (Exception ex) { MessageBox.Show("Greska ucitavanja: " + ex.Message); return; }

            foreach (DetaljiRed d in redovi)
            {
                double volumen          = d.Setovi * d.Ponavljanja * d.MaxKg;
                double prethodniVolumen = 0;

                try
                {
                    using (MySqlConnection conn2 = DbHelper.GetConnection())
                    using (MySqlCommand cmd2 = new MySqlCommand(
                        "SELECT tv2.OdradjeniSetovi, tv2.OdradjenaPonavlajnja, tv2.MaxTezina " +
                        "FROM treningvjezba tv2 " +
                        "JOIN trening t2 ON t2.TreningID=tv2.TreningID " +
                        "WHERE tv2.VjezbaID=@vid AND t2.KorisnikID=@kid " +
                        "AND t2.Datum < @datum AND t2.TreningID != @tid " +
                        "ORDER BY t2.Datum DESC LIMIT 1", conn2))
                    {
                        cmd2.Parameters.AddWithValue("@vid",   d.VjezbaID);
                        cmd2.Parameters.AddWithValue("@kid",   KorisnikManager.TrenutniKorisnikID);
                        cmd2.Parameters.AddWithValue("@datum", datum.ToString("yyyy-MM-dd"));
                        cmd2.Parameters.AddWithValue("@tid",   treningID);
                        using (MySqlDataReader r2 = cmd2.ExecuteReader())
                            if (r2.Read())
                            {
                                int    ps = r2.IsDBNull(0) ? 0 : r2.GetInt32(0);
                                int    pp = r2.IsDBNull(1) ? 0 : r2.GetInt32(1);
                                double pk = r2.IsDBNull(2) ? 0 : r2.GetDouble(2);
                                prethodniVolumen = ps * pp * pk;
                            }
                    }
                }
                catch { }

                double razlika  = volumen - prethodniVolumen;
                string prVolStr = prethodniVolumen > 0 ? prethodniVolumen.ToString("0.#") : "-";
                string deltaStr = prethodniVolumen > 0
                    ? (razlika >= 0 ? "+" : "") + razlika.ToString("0.#")
                    : "Prvi put";

                int idx = dgvDetalji.Rows.Add(
                    d.Naziv,
                    d.Setovi > 0 ? d.Setovi.ToString() : "-",
                    d.Ponavljanja > 0 ? d.Ponavljanja.ToString() : "-",
                    d.MaxKg > 0 ? d.MaxKg.ToString("0.##") + " kg" : "-",
                    volumen > 0 ? volumen.ToString("0.#") : "-",
                    d.Gotovo ? "OK" : "-",
                    prVolStr,
                    deltaStr
                );

            
                if (prethodniVolumen > 0)
                    dgvDetalji.Rows[idx].DefaultCellStyle.BackColor =
                        razlika > 0 ? Color.FromArgb(210, 245, 210) :
                        razlika < 0 ? Color.FromArgb(255, 215, 215) :
                        Color.White;

             
                if (prethodniVolumen > 0)
                {
                    dgvDetalji.Rows[idx].Cells["dDelta"].Style.ForeColor =
                        razlika > 0 ? Color.FromArgb(20, 140, 60) :
                        razlika < 0 ? Color.FromArgb(180, 40, 40) : Color.Gray;
                    dgvDetalji.Rows[idx].Cells["dDelta"].Style.Font =
                        new Font("Segoe UI", 9f, FontStyle.Bold);
                }
            }
        }

        private void cmbVjezbe_SelectedIndexChanged(object sender, EventArgs e)
        {
            var sel = cmbVjezbe.SelectedItem as VjezbaItem;
            if (sel == null || sel.VjezbaID == -1)
            {
                chartTacke.Clear();
                lblChartNaslov.Text = "Odaberi vjezbu da vidis napredak";
                pnlChart.Invalidate();
                return;
            }
            UcitajProgressZaVjezbu(sel.VjezbaID, sel.Naziv);
        }

        private void UcitajProgressZaVjezbu(int vjezbaID, string naziv)
        {
            chartTacke.Clear();
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                using (MySqlCommand cmd = new MySqlCommand(
                    "SELECT t.Datum, tv.MaxTezina, tv.OdradjeniSetovi, tv.OdradjenaPonavlajnja " +
                    "FROM treningvjezba tv " +
                    "JOIN trening t ON t.TreningID=tv.TreningID " +
                    "WHERE tv.VjezbaID=@vid AND t.KorisnikID=@kid ORDER BY t.Datum ASC", conn))
                {
                    cmd.Parameters.AddWithValue("@vid", vjezbaID);
                    cmd.Parameters.AddWithValue("@kid", KorisnikManager.TrenutniKorisnikID);
                    using (MySqlDataReader r = cmd.ExecuteReader())
                        while (r.Read())
                            chartTacke.Add(new ProgressTacka
                            {
                                Datum       = r.GetDateTime(0),
                                MaxKg       = r.IsDBNull(1) ? 0 : r.GetDouble(1),
                                Setovi      = r.IsDBNull(2) ? 0 : r.GetInt32(2),
                                Ponavljanja = r.IsDBNull(3) ? 0 : r.GetInt32(3)
                            });
                }
            }
            catch (Exception ex) { MessageBox.Show("Greska chart: " + ex.Message); }

            if (chartTacke.Count > 0)
            {
                double maxKg = 0, maxVol = 0;
                foreach (var t in chartTacke)
                {
                    if (t.MaxKg > maxKg)    maxKg  = t.MaxKg;
                    if (t.Volumen > maxVol) maxVol = t.Volumen;
                }
                lblChartNaslov.Text = naziv
                    + "   Max: " + maxKg.ToString("0.##") + " kg"
                    + "   |   Max volumen: " + maxVol.ToString("0.#")
                    + "   |   Treninga: " + chartTacke.Count;
            }
            else
            {
                lblChartNaslov.Text = naziv + "  —  Nema podataka jos.";
            }
            pnlChart.Invalidate();
        }

        private void pnlChart_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode     = SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            Rectangle rc = pnlChart.ClientRectangle;
            g.Clear(Color.White);

            if (chartTacke.Count < 1)
            {
                using (var br   = new SolidBrush(Color.FromArgb(160, 160, 180)))
                using (var font = new Font("Segoe UI", 11f))
                {
                    string msg = "Nema podataka za prikaz";
                    SizeF  sz  = g.MeasureString(msg, font);
                    g.DrawString(msg, font, br,
                        rc.Width / 2f - sz.Width / 2f,
                        rc.Height / 2f - sz.Height / 2f + 20);
                }
                return;
            }

            bool prikaziVolumen = cmbChartTip.SelectedIndex == 1;
            int padL = 65, padR = 20, padT = 30, padB = 40;
            int cw = rc.Width - padL - padR;
            int ch = rc.Height - padT - padB;

            double[] vals = new double[chartTacke.Count];
            for (int i = 0; i < chartTacke.Count; i++)
                vals[i] = prikaziVolumen ? chartTacke[i].Volumen : chartTacke[i].MaxKg;

            double minV = double.MaxValue, maxV = 0;
            foreach (double v in vals) { if (v < minV) minV = v; if (v > maxV) maxV = v; }
            if (maxV == minV) { minV = maxV == 0 ? 0 : maxV * 0.9; maxV = maxV == 0 ? 10 : maxV * 1.1; }
            double range = maxV - minV;

            using (var pen = new Pen(Color.FromArgb(235, 235, 240)))
                for (int i = 0; i <= 5; i++)
                {
                    int    y  = padT + ch - (int)(i * ch / 5.0);
                    double vv = minV + i * range / 5.0;
                    g.DrawLine(pen, padL, y, padL + cw, y);
                    using (var font = new Font("Segoe UI", 7.5f))
                    using (var br   = new SolidBrush(Color.FromArgb(140, 140, 160)))
                        g.DrawString(vv.ToString("0.#"), font, br, 2, y - 7);
                }

            using (var pen = new Pen(Color.FromArgb(200, 200, 215)))
            {
                g.DrawLine(pen, padL, padT, padL, padT + ch);
                g.DrawLine(pen, padL, padT + ch, padL + cw, padT + ch);
            }

            var pts = new PointF[chartTacke.Count];
            for (int i = 0; i < chartTacke.Count; i++)
            {
                float x = padL + (chartTacke.Count == 1 ? cw / 2f
                    : i * cw / (float)(chartTacke.Count - 1));
                float y = padT + ch - (float)((vals[i] - minV) / range * ch);
                pts[i] = new PointF(x, y);
            }

            if (pts.Length > 1)
            {
                var fill = new PointF[pts.Length + 2];
                fill[0] = new PointF(pts[0].X, padT + ch);
                for (int i = 0; i < pts.Length; i++) fill[i + 1] = pts[i];
                fill[fill.Length - 1] = new PointF(pts[pts.Length - 1].X, padT + ch);
                using (var path = new GraphicsPath())
                {
                    path.AddPolygon(fill);
                    using (var br = new LinearGradientBrush(
                        new Point(0, padT), new Point(0, padT + ch),
                        Color.FromArgb(70, 88, 86, 214), Color.FromArgb(8, 88, 86, 214)))
                        g.FillPath(br, path);
                }
            }

            if (pts.Length > 1)
                using (var pen = new Pen(Color.FromArgb(88, 86, 214), 2.5f))
                    g.DrawLines(pen, pts);

            for (int i = 0; i < pts.Length; i++)
            {
                float r2 = 5.5f;
                using (var br = new SolidBrush(Color.FromArgb(88, 86, 214)))
                    g.FillEllipse(br, pts[i].X - r2, pts[i].Y - r2, r2 * 2, r2 * 2);
                using (var pen = new Pen(Color.White, 2f))
                    g.DrawEllipse(pen, pts[i].X - r2, pts[i].Y - r2, r2 * 2, r2 * 2);

                using (var font = new Font("Segoe UI", 7.5f, FontStyle.Bold))
                using (var br   = new SolidBrush(Color.FromArgb(28, 28, 38)))
                {
                    string lbl = vals[i].ToString("0.#");
                    SizeF  sz  = g.MeasureString(lbl, font);
                    g.DrawString(lbl, font, br, pts[i].X - sz.Width / 2, pts[i].Y - 18);
                }

                if (chartTacke.Count <= 12 || i % 2 == 0)
                    using (var font = new Font("Segoe UI", 7f))
                    using (var br   = new SolidBrush(Color.FromArgb(120, 120, 150)))
                    {
                        string d  = chartTacke[i].Datum.ToString("dd.MM");
                        SizeF  sz = g.MeasureString(d, font);
                        g.DrawString(d, font, br, pts[i].X - sz.Width / 2, padT + ch + 6);
                    }
            }

            string yLabel = prikaziVolumen ? "vol" : "kg";
            using (var font = new Font("Segoe UI", 8f, FontStyle.Bold))
            using (var br   = new SolidBrush(Color.FromArgb(88, 86, 214)))
                g.DrawString(yLabel, font, br, 2, padT - 16);
        }

        private void FrmEvidencija_Load(object sender, EventArgs e) { }
    }
}
