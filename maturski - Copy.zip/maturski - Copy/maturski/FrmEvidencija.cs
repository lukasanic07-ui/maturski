using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApplication1
{
    public partial class FrmEvidencija : Form
    {
        // ── State ──────────────────────────────────────────────────────────
        private List<ProgressTacka> chartTacke = new List<ProgressTacka>();
        private int odabraniTreningID = -1;

        // ── Inner types ────────────────────────────────────────────────────
        private class ProgressTacka
        {
            public DateTime Datum;
            public double MaxKg;
            public int Setovi;
            public int Ponavljanja;
            public double Volumen { get { return Setovi * Ponavljanja * MaxKg; } }
        }

        private class TreningItem
        {
            public int TreningID;
            public DateTime Datum;
            public string PlanNaziv;
            public override string ToString()
            {
                return Datum.ToString("dd.MM.yyyy") + "  —  " + PlanNaziv;
            }
        }

        private class VjezbaItem
        {
            public int VjezbaID;
            public string Naziv;
            public override string ToString() { return Naziv; }
        }

        private class DetaljiRed
        {
            public int VjezbaID;
            public string Naziv;
            public int Setovi;
            public int Ponavljanja;
            public double MaxKg;
            public bool Gotovo;
        }

        // ── Constructor ────────────────────────────────────────────────────
        public FrmEvidencija()
        {
            InitializeComponent();

            pnlChart.Paint += pnlChart_Paint;
            cmbPrikazCharta.SelectedIndex = 0;
            cmbPrikazCharta.SelectedIndexChanged += cmbPrikazCharta_SelectedIndexChanged;

            lstHistorija.DrawMode = DrawMode.OwnerDrawFixed;
            lstHistorija.DrawItem += lstHistorija_DrawItem;

            UcitajVjezbe();
            UcitajTreningHistoriju();
        }

        // ── Load ───────────────────────────────────────────────────────────
        private void FrmEvidencija_Load(object sender, EventArgs e) { }

        // ── Combo: odaberi vježbu za chart ─────────────────────────────────
        private void cmbVjezba_SelectedIndexChanged(object sender, EventArgs e)
        {
            var sel = cmbVjezba.SelectedItem as VjezbaItem;
            if (sel == null || sel.VjezbaID == -1)
            {
                chartTacke.Clear();
                lblChartTitle.Text = "Odaberi vjezbu da vidis napredak";
                lblChartPlaceholder.Visible = true;
                pnlChart.Invalidate();
                return;
            }
            UcitajProgressZaVjezbu(sel.VjezbaID, sel.Naziv);
        }

        // ── Combo: promjena tipa charta ────────────────────────────────────
        private void cmbPrikazCharta_SelectedIndexChanged(object sender, EventArgs e)
        {
            pnlChart.Invalidate();
        }

        // ── ListBox: odaberi trening iz historije ──────────────────────────
        private void lstHistorija_SelectedIndexChanged(object sender, EventArgs e)
        {
            var item = lstHistorija.SelectedItem as TreningItem;
            if (item == null) return;
            odabraniTreningID = item.TreningID;
            UcitajDetalje(item.TreningID, item.Datum);
        }

        // ── Custom draw za listbox ─────────────────────────────────────────
        private void lstHistorija_DrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0) return;
            bool sel = (e.State & DrawItemState.Selected) != 0;
            Color bg = sel
                ? Color.FromArgb(88, 86, 214)
                : (e.Index % 2 == 0
                    ? Color.FromArgb(40, 37, 62)
                    : Color.FromArgb(34, 31, 53));
            e.Graphics.FillRectangle(new SolidBrush(bg), e.Bounds);
            e.Graphics.DrawString(
                lstHistorija.Items[e.Index].ToString(),
                new Font("Segoe UI", 8.5f, sel ? FontStyle.Bold : FontStyle.Regular),
                new SolidBrush(Color.White),
                new PointF(e.Bounds.X + 8, e.Bounds.Y + 5));
        }

        // ── Učitaj vježbe u combo ──────────────────────────────────────────
        private void UcitajVjezbe()
        {
            cmbVjezba.Items.Clear();
            cmbVjezba.Items.Add(new VjezbaItem { VjezbaID = -1, Naziv = "-- Odaberi vjezbu --" });
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                using (MySqlCommand cmd = new MySqlCommand(
                    "SELECT DISTINCT v.VjezbaID, v.Naziv " +
                    "FROM treningvjezba tv " +
                    "JOIN vjezba v ON v.VjezbaID=tv.VjezbaID " +
                    "JOIN trening t ON t.TreningID=tv.TreningID " +
                    "WHERE t.KorisnikID=@kid ORDER BY v.Naziv", conn))
                {
                    cmd.Parameters.AddWithValue("@kid", KorisnikManager.TrenutniKorisnikID);
                    using (MySqlDataReader r = cmd.ExecuteReader())
                        while (r.Read())
                            cmbVjezba.Items.Add(new VjezbaItem { VjezbaID = r.GetInt32(0), Naziv = r.GetString(1) });
                }
            }
            catch { }
            cmbVjezba.SelectedIndex = 0;
        }

        // ── Učitaj historiju treninga u listbox ────────────────────────────
        private void UcitajTreningHistoriju()
        {
            lstHistorija.Items.Clear();
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                using (MySqlCommand cmd = new MySqlCommand(
                    "SELECT t.TreningID, t.Datum, COALESCE(tp.Naziv,'Bez plana') " +
                    "FROM trening t " +
                    "LEFT JOIN treningplan tp ON tp.PlanID=t.PlanID " +
                    "WHERE t.KorisnikID=@kid ORDER BY t.Datum DESC", conn))
                {
                    cmd.Parameters.AddWithValue("@kid", KorisnikManager.TrenutniKorisnikID);
                    using (MySqlDataReader r = cmd.ExecuteReader())
                        while (r.Read())
                            lstHistorija.Items.Add(new TreningItem
                            {
                                TreningID = r.GetInt32(0),
                                Datum = r.GetDateTime(1),
                                PlanNaziv = r.GetString(2)
                            });
                }
            }
            catch (Exception ex) { MessageBox.Show("Greška: " + ex.Message); }
            lblUkupnoTreninga.Text = "Ukupno treninga: " + lstHistorija.Items.Count;
        }

        // ── Učitaj detalje odabranog treninga u grid ───────────────────────
        private void UcitajDetalje(int treningID, DateTime datum)
        {
            dgvDetalji.Rows.Clear();
            lblKlikNaInfo.Text = "Trening od " + datum.ToString("dd.MM.yyyy") + ":";

            var redovi = new List<DetaljiRed>();
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                using (MySqlCommand cmd = new MySqlCommand(
                    "SELECT tv.VjezbaID, v.Naziv, tv.OdradjeniSetovi, " +
                    "tv.OdradjenaPonavlajnja, tv.MaxTezina, tv.Uradjeno " +
                    "FROM treningvjezba tv " +
                    "JOIN vjezba v ON v.VjezbaID=tv.VjezbaID " +
                    "WHERE tv.TreningID=@tid ORDER BY v.Naziv", conn))
                {
                    cmd.Parameters.AddWithValue("@tid", treningID);
                    using (MySqlDataReader r = cmd.ExecuteReader())
                        while (r.Read())
                            redovi.Add(new DetaljiRed
                            {
                                VjezbaID = r.GetInt32(0),
                                Naziv = r.GetString(1),
                                Setovi = r.IsDBNull(2) ? 0 : r.GetInt32(2),
                                Ponavljanja = r.IsDBNull(3) ? 0 : r.GetInt32(3),
                                MaxKg = r.IsDBNull(4) ? 0 : r.GetDouble(4),
                                Gotovo = !r.IsDBNull(5) && r.GetInt32(5) == 1
                            });
                }
            }
            catch (Exception ex) { MessageBox.Show("Greška ucitavanja: " + ex.Message); return; }

            foreach (DetaljiRed d in redovi)
            {
                double volumen = d.Setovi * d.Ponavljanja * d.MaxKg;
                double prethodniVolumen = 0;

                try
                {
                    using (MySqlConnection conn2 = DbHelper.GetConnection())
                    using (MySqlCommand cmd2 = new MySqlCommand(
                        "SELECT tv2.OdradjeniSetovi, tv2.OdradjenaPonavlajnja, tv2.MaxTezina " +
                        "FROM treningvjezba tv2 " +
                        "JOIN trening t2 ON t2.TreningID=tv2.TreningID " +
                        "WHERE tv2.VjezbaID=@vid AND t2.KorisnikID=@kid " +
                        "AND t2.Datum < @datum AND t2.TreningID != @tid " +
                        "ORDER BY t2.Datum DESC LIMIT 1", conn2))
                    {
                        cmd2.Parameters.AddWithValue("@vid", d.VjezbaID);
                        cmd2.Parameters.AddWithValue("@kid", KorisnikManager.TrenutniKorisnikID);
                        cmd2.Parameters.AddWithValue("@datum", datum.ToString("yyyy-MM-dd"));
                        cmd2.Parameters.AddWithValue("@tid", treningID);
                        using (MySqlDataReader r2 = cmd2.ExecuteReader())
                            if (r2.Read())
                            {
                                int ps = r2.IsDBNull(0) ? 0 : r2.GetInt32(0);
                                int pp = r2.IsDBNull(1) ? 0 : r2.GetInt32(1);
                                double pk = r2.IsDBNull(2) ? 0 : r2.GetDouble(2);
                                prethodniVolumen = ps * pp * pk;
                            }
                    }
                }
                catch { }

                double razlika = volumen - prethodniVolumen;
                string prVolStr = prethodniVolumen > 0 ? prethodniVolumen.ToString("0.#") : "-";
                string deltaStr = prethodniVolumen > 0
                    ? (razlika >= 0 ? "+" : "") + razlika.ToString("0.#")
                    : "Prvi put";

                int idx = dgvDetalji.Rows.Add(
                    d.Naziv,
                    d.Setovi > 0 ? d.Setovi.ToString() : "-",
                    d.Ponavljanja > 0 ? d.Ponavljanja.ToString() : "-",
                    d.MaxKg > 0 ? d.MaxKg.ToString("0.##") + " kg" : "-",
                    volumen > 0 ? volumen.ToString("0.#") : "-",
                    d.Gotovo ? "OK" : "-",
                    prVolStr,
                    deltaStr
                );

                if (prethodniVolumen > 0)
                {
                    dgvDetalji.Rows[idx].DefaultCellStyle.BackColor =
                        razlika > 0 ? Color.FromArgb(210, 245, 210) :
                        razlika < 0 ? Color.FromArgb(255, 215, 215) :
                        Color.White;

                    dgvDetalji.Rows[idx].Cells["colDelta"].Style.ForeColor =
                        razlika > 0 ? Color.FromArgb(20, 140, 60) :
                        razlika < 0 ? Color.FromArgb(180, 40, 40) :
                        Color.Gray;
                    dgvDetalji.Rows[idx].Cells["colDelta"].Style.Font =
                        new Font("Segoe UI", 9f, FontStyle.Bold);
                }
            }
        }

        // ── Učitaj progress za vježbu (chart data) ─────────────────────────
        private void UcitajProgressZaVjezbu(int vjezbaID, string naziv)
        {
            chartTacke.Clear();
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                using (MySqlCommand cmd = new MySqlCommand(
                    "SELECT t.Datum, tv.MaxTezina, tv.OdradjeniSetovi, tv.OdradjenaPonavlajnja " +
                    "FROM treningvjezba tv " +
                    "JOIN trening t ON t.TreningID=tv.TreningID " +
                    "WHERE tv.VjezbaID=@vid AND t.KorisnikID=@kid ORDER BY t.Datum ASC", conn))
                {
                    cmd.Parameters.AddWithValue("@vid", vjezbaID);
                    cmd.Parameters.AddWithValue("@kid", KorisnikManager.TrenutniKorisnikID);
                    using (MySqlDataReader r = cmd.ExecuteReader())
                        while (r.Read())
                            chartTacke.Add(new ProgressTacka
                            {
                                Datum = r.GetDateTime(0),
                                MaxKg = r.IsDBNull(1) ? 0 : r.GetDouble(1),
                                Setovi = r.IsDBNull(2) ? 0 : r.GetInt32(2),
                                Ponavljanja = r.IsDBNull(3) ? 0 : r.GetInt32(3)
                            });
                }
            }
            catch (Exception ex) { MessageBox.Show("Greška chart: " + ex.Message); }

            // Sakrij placeholder kad ima podataka, pokaži ga kad nema
            lblChartPlaceholder.Visible = (chartTacke.Count == 0);

            if (chartTacke.Count > 0)
            {
                double maxKg = 0, maxVol = 0;
                foreach (var t in chartTacke)
                {
                    if (t.MaxKg > maxKg) maxKg = t.MaxKg;
                    if (t.Volumen > maxVol) maxVol = t.Volumen;
                }
                lblChartTitle.Text = naziv
                    + "   Max: " + maxKg.ToString("0.##") + " kg"
                    + "   |   Max vol: " + maxVol.ToString("0.#")
                    + "   |   Treninga: " + chartTacke.Count;
            }
            else
            {
                lblChartTitle.Text = naziv + "  —  Nema podataka još.";
            }
            pnlChart.Invalidate();
        }

        // ── Chart paint ────────────────────────────────────────────────────
        private void pnlChart_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            Rectangle rc = pnlChart.ClientRectangle;
            g.Clear(Color.White);

            if (chartTacke.Count < 1)
            {
                using (var br = new SolidBrush(Color.FromArgb(160, 160, 180)))
                using (var font = new Font("Segoe UI", 11f))
                {
                    string msg = "Nema podataka za prikaz";
                    SizeF sz = g.MeasureString(msg, font);
                    g.DrawString(msg, font, br,
                        rc.Width / 2f - sz.Width / 2f,
                        rc.Height / 2f - sz.Height / 2f + 10);
                }
                return;
            }

            bool prikaziVolumen = (cmbPrikazCharta.SelectedIndex == 1);
            bool prikaziPonavljanja = (cmbPrikazCharta.SelectedIndex == 2);

            int padL = 62, padR = 20, padT = 28, padB = 36;
            int cw = rc.Width - padL - padR;
            int ch = rc.Height - padT - padB;

            double[] vals = new double[chartTacke.Count];
            for (int i = 0; i < chartTacke.Count; i++)
            {
                if (prikaziVolumen)
                    vals[i] = chartTacke[i].Volumen;
                else if (prikaziPonavljanja)
                    vals[i] = chartTacke[i].Ponavljanja;
                else
                    vals[i] = chartTacke[i].MaxKg;
            }

            double minV = double.MaxValue, maxV = 0;
            foreach (double v in vals) { if (v < minV) minV = v; if (v > maxV) maxV = v; }
            if (maxV == minV) { minV = maxV == 0 ? 0 : maxV * 0.9; maxV = maxV == 0 ? 10 : maxV * 1.1; }
            double range = maxV - minV;

            // Grid lines + Y labels
            using (var pen = new Pen(Color.FromArgb(235, 235, 242)))
                for (int i = 0; i <= 5; i++)
                {
                    int y = padT + ch - (int)(i * ch / 5.0);
                    double vv = minV + i * range / 5.0;
                    g.DrawLine(pen, padL, y, padL + cw, y);
                    using (var font = new Font("Segoe UI", 7.5f))
                    using (var br = new SolidBrush(Color.FromArgb(140, 140, 160)))
                        g.DrawString(vv.ToString("0.#"), font, br, 2, y - 7);
                }

            // Axes
            using (var pen = new Pen(Color.FromArgb(200, 200, 215)))
            {
                g.DrawLine(pen, padL, padT, padL, padT + ch);
                g.DrawLine(pen, padL, padT + ch, padL + cw, padT + ch);
            }

            // Data points
            var pts = new PointF[chartTacke.Count];
            for (int i = 0; i < chartTacke.Count; i++)
            {
                float x = padL + (chartTacke.Count == 1 ? cw / 2f
                    : i * cw / (float)(chartTacke.Count - 1));
                float y = padT + ch - (float)((vals[i] - minV) / range * ch);
                pts[i] = new PointF(x, y);
            }

            // Area fill
            if (pts.Length > 1)
            {
                var fill = new PointF[pts.Length + 2];
                fill[0] = new PointF(pts[0].X, padT + ch);
                for (int i = 0; i < pts.Length; i++) fill[i + 1] = pts[i];
                fill[fill.Length - 1] = new PointF(pts[pts.Length - 1].X, padT + ch);
                using (var path = new GraphicsPath())
                {
                    path.AddPolygon(fill);
                    using (var br = new LinearGradientBrush(
                        new Point(0, padT), new Point(0, padT + ch),
                        Color.FromArgb(70, 88, 86, 214), Color.FromArgb(8, 88, 86, 214)))
                        g.FillPath(br, path);
                }
            }

            // Line
            if (pts.Length > 1)
                using (var pen = new Pen(Color.FromArgb(88, 86, 214), 2.5f))
                    g.DrawLines(pen, pts);

            // Dots + labels
            for (int i = 0; i < pts.Length; i++)
            {
                float r2 = 5.5f;
                using (var br = new SolidBrush(Color.FromArgb(88, 86, 214)))
                    g.FillEllipse(br, pts[i].X - r2, pts[i].Y - r2, r2 * 2, r2 * 2);
                using (var pen = new Pen(Color.White, 2f))
                    g.DrawEllipse(pen, pts[i].X - r2, pts[i].Y - r2, r2 * 2, r2 * 2);

                using (var font = new Font("Segoe UI", 7.5f, FontStyle.Bold))
                using (var br = new SolidBrush(Color.FromArgb(28, 25, 45)))
                {
                    string lbl = vals[i].ToString("0.#");
                    SizeF sz = g.MeasureString(lbl, font);
                    g.DrawString(lbl, font, br, pts[i].X - sz.Width / 2, pts[i].Y - 18);
                }

                if (chartTacke.Count <= 12 || i % 2 == 0)
                    using (var font = new Font("Segoe UI", 7f))
                    using (var br = new SolidBrush(Color.FromArgb(120, 120, 150)))
                    {
                        string d = chartTacke[i].Datum.ToString("dd.MM");
                        SizeF sz = g.MeasureString(d, font);
                        g.DrawString(d, font, br, pts[i].X - sz.Width / 2, padT + ch + 5);
                    }
            }

            // Y-axis label
            string yLabel = prikaziVolumen ? "vol" : prikaziPonavljanja ? "rep" : "kg";
            using (var font = new Font("Segoe UI", 8f, FontStyle.Bold))
            using (var br = new SolidBrush(Color.FromArgb(88, 86, 214)))
                g.DrawString(yLabel, font, br, 2, padT - 16);
        }

        private void lblChartPlaceholder_Click(object sender, EventArgs e)
        {

        }
    }
}