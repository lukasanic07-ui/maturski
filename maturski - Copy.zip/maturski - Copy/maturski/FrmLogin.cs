using System;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
            // Sakrij lozinku
            txtLozinka.UseSystemPasswordChar = true;
            this.AcceptButton = btnLogin;
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string lozinka = txtLozinka.Text;

            if (username == "" || lozinka == "")
            {
                MessageBox.Show("Upi�i username i lozinku!", "Upozorenje",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (KorisnikManager.Prijavi(username, lozinka))
            {
                this.Hide();
                FrmNaslovna frm = new FrmNaslovna();
                frm.ShowDialog();
                this.Close();
            }
            else
            {
                MessageBox.Show("Pogre�an username ili lozinka!", "Gre�ka pri prijavi",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtLozinka.Clear();
                txtLozinka.Focus();
            }
        }

        private void btnRegistracija_Click(object sender, EventArgs e)
        {
            FrmRegistracija frmReg = new FrmRegistracija();
            if (frmReg.ShowDialog() == DialogResult.OK)
            {
                MessageBox.Show("Nalog kreiran! Mo�ete se sada prijaviti.", "Dobrodo�li",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void FrmLogin_Load(object sender, EventArgs e)
        {

        }

        private void FrmLogin_Load_1(object sender, EventArgs e)
        {

        }
    }
}