namespace WindowsFormsApplication1
{
    partial class FrmVjezbe
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.pnlLeft        = new System.Windows.Forms.Panel();
            this.dgvVjezbe      = new System.Windows.Forms.DataGridView();
            this.pnlRight       = new System.Windows.Forms.Panel();
            this.lblRightTitle  = new System.Windows.Forms.Label();
            this.pnlSep1        = new System.Windows.Forms.Panel();
            this.label2         = new System.Windows.Forms.Label();
            this.txtNaziv       = new System.Windows.Forms.TextBox();
            this.label3         = new System.Windows.Forms.Label();
            this.txtOpis        = new System.Windows.Forms.TextBox();
            this.label1         = new System.Windows.Forms.Label();
            this.cmbTip         = new System.Windows.Forms.ComboBox();
            this.label4         = new System.Windows.Forms.Label();
            this.cmbGrupa       = new System.Windows.Forms.ComboBox();
            this.pnlActionBtns  = new System.Windows.Forms.Panel();
            this.btnObrisi      = new System.Windows.Forms.Button();
            this.btnAzuriraj    = new System.Windows.Forms.Button();
            this.btnDodaj       = new System.Windows.Forms.Button();
            this.btnNovo        = new System.Windows.Forms.Button();
            this.btnUcitajSve   = new System.Windows.Forms.Button();
            this.pnlSep2        = new System.Windows.Forms.Panel();
            this.F              = new System.Windows.Forms.Label();
            this.label5         = new System.Windows.Forms.Label();
            this.label6         = new System.Windows.Forms.Label();
            this.cmbFilterTip   = new System.Windows.Forms.ComboBox();
            this.cmbFilterGrupa = new System.Windows.Forms.ComboBox();
            this.pnlSep3        = new System.Windows.Forms.Panel();
            this.label7         = new System.Windows.Forms.Label();
            this.comboBox1      = new System.Windows.Forms.ComboBox();
            this.button1        = new System.Windows.Forms.Button();
            this.btnTheme       = new System.Windows.Forms.Button();

            this.pnlLeft.SuspendLayout();
            this.pnlRight.SuspendLayout();
            this.pnlActionBtns.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVjezbe)).BeginInit();
            this.SuspendLayout();

            // ── LEFT — DataGridView ───────────────────────────────────────
            this.pnlLeft.Dock      = System.Windows.Forms.DockStyle.Fill;
            this.pnlLeft.BackColor = System.Drawing.Color.FromArgb(245, 247, 252);
            this.pnlLeft.Controls.Add(this.dgvVjezbe);

            this.dgvVjezbe.BackgroundColor       = System.Drawing.Color.White;
            this.dgvVjezbe.Dock                  = System.Windows.Forms.DockStyle.Fill;
            this.dgvVjezbe.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvVjezbe.EnableHeadersVisualStyles = false;
            this.dgvVjezbe.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(34, 31, 53);
            this.dgvVjezbe.ColumnHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.White;
            this.dgvVjezbe.ColumnHeadersDefaultCellStyle.Font      = new System.Drawing.Font("Segoe UI", 9f, System.Drawing.FontStyle.Bold);
            this.dgvVjezbe.DefaultCellStyle.Font                   = new System.Drawing.Font("Segoe UI", 9f);
            this.dgvVjezbe.DefaultCellStyle.SelectionBackColor     = System.Drawing.Color.FromArgb(88, 86, 214);
            this.dgvVjezbe.DefaultCellStyle.SelectionForeColor     = System.Drawing.Color.White;
            this.dgvVjezbe.AlternatingRowsDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(248, 248, 252);
            this.dgvVjezbe.RowHeadersVisible   = false;
            this.dgvVjezbe.BorderStyle         = System.Windows.Forms.BorderStyle.None;
            this.dgvVjezbe.SelectionMode       = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvVjezbe.RowTemplate.Height  = 30;
            this.dgvVjezbe.Name                = "dgvVjezbe";
            this.dgvVjezbe.CellMouseLeave     += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvVjezbe_CellMouseLeave);
            this.dgvVjezbe.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvVjezbe_ColumnHeaderMouseClick);
            this.dgvVjezbe.RowPrePaint        += new System.Windows.Forms.DataGridViewRowPrePaintEventHandler(this.dgvVjezbe_RowPrePaint);
            this.dgvVjezbe.MouseUp            += new System.Windows.Forms.MouseEventHandler(this.dgvVjezbe_MouseUp);
            this.dgvVjezbe.CellMouseEnter     += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvVjezbe_CellMouseEnter);
            this.dgvVjezbe.SelectionChanged   += new System.EventHandler(this.dgvVjezbe_SelectionChanged);
            this.dgvVjezbe.Click              += new System.EventHandler(this.dgvVjezbe_Click);
            this.dgvVjezbe.CellContentClick   += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvVjezbe_CellContentClick);

            // ── RIGHT PANEL ──────────────────────────────────────────────
            this.pnlRight.BackColor  = System.Drawing.Color.FromArgb(34, 31, 53);
            this.pnlRight.Dock       = System.Windows.Forms.DockStyle.Right;
            this.pnlRight.Width      = 270;
            this.pnlRight.Padding    = new System.Windows.Forms.Padding(0);
            this.pnlRight.Controls.AddRange(new System.Windows.Forms.Control[] {
                this.lblRightTitle, this.pnlSep1,
                this.label2, this.txtNaziv,
                this.label3, this.txtOpis,
                this.label1, this.cmbTip,
                this.label4, this.cmbGrupa,
                this.pnlActionBtns,
                this.pnlSep2,
                this.F, this.label5, this.label6, this.cmbFilterTip, this.cmbFilterGrupa,
                this.pnlSep3,
                this.label7, this.comboBox1, this.button1,
                this.btnTheme });

            // Title
            this.lblRightTitle.Text      = "Detalji vježbe";
            this.lblRightTitle.Font      = new System.Drawing.Font("Segoe UI", 10f, System.Drawing.FontStyle.Bold);
            this.lblRightTitle.ForeColor = System.Drawing.Color.White;
            this.lblRightTitle.Location  = new System.Drawing.Point(14, 14);
            this.lblRightTitle.AutoSize  = true;

            this.btnTheme.Text      = "Dark Mode";
            this.btnTheme.Location  = new System.Drawing.Point(170, 10);
            this.btnTheme.Size      = new System.Drawing.Size(85, 26);
            this.btnTheme.Font      = new System.Drawing.Font("Segoe UI", 7.5f);
            this.btnTheme.ForeColor = System.Drawing.Color.White;
            this.btnTheme.BackColor = System.Drawing.Color.FromArgb(60, 57, 90);
            this.btnTheme.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTheme.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(80, 77, 120);
            this.btnTheme.Click    += new System.EventHandler(this.btnTheme_Click);

            this.pnlSep1.BackColor = System.Drawing.Color.FromArgb(55, 52, 80);
            this.pnlSep1.Location  = new System.Drawing.Point(10, 44);
            this.pnlSep1.Size      = new System.Drawing.Size(248, 1);

            // Helper to style labels on dark panel
            System.Action<System.Windows.Forms.Label, string, int, int> styleLabel =
                (lbl, txt, x, y) => {
                    lbl.Text      = txt;
                    lbl.Font      = new System.Drawing.Font("Segoe UI", 8.5f);
                    lbl.ForeColor = System.Drawing.Color.FromArgb(180, 176, 220);
                    lbl.Location  = new System.Drawing.Point(x, y);
                    lbl.AutoSize  = true;
                };

            // Helper for styled textboxes
            System.Action<System.Windows.Forms.TextBox, int, int, int, int> styleTxt =
                (txt, x, y, w, h) => {
                    txt.Font      = new System.Drawing.Font("Segoe UI", 9f);
                    txt.BackColor = System.Drawing.Color.FromArgb(50, 47, 75);
                    txt.ForeColor = System.Drawing.Color.White;
                    txt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
                    txt.Location  = new System.Drawing.Point(x, y);
                    txt.Size      = new System.Drawing.Size(w, h);
                };

            // Helper for styled combos
            System.Action<System.Windows.Forms.ComboBox, int, int, int> styleCmb =
                (cmb, x, y, w) => {
                    cmb.Font      = new System.Drawing.Font("Segoe UI", 9f);
                    cmb.BackColor = System.Drawing.Color.FromArgb(50, 47, 75);
                    cmb.ForeColor = System.Drawing.Color.White;
                    cmb.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
                    cmb.Location  = new System.Drawing.Point(x, y);
                    cmb.Size      = new System.Drawing.Size(w, 24);
                    cmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
                };

            styleLabel(this.label2, "Naziv",        14, 52);  styleTxt(this.txtNaziv, 14, 70, 240, 24);
            styleLabel(this.label3, "Opis",         14, 100); 
            this.txtOpis.Multiline  = true;
            styleTxt(this.txtOpis, 14, 118, 240, 70);

            styleLabel(this.label1, "Tip",          14, 196); styleCmb(this.cmbTip,   14, 214, 240);
            styleLabel(this.label4, "Mišićna Grupa",14, 244); styleCmb(this.cmbGrupa, 14, 262, 240);

            // Action buttons panel
            this.pnlActionBtns.BackColor = System.Drawing.Color.Transparent;
            this.pnlActionBtns.Location  = new System.Drawing.Point(10, 295);
            this.pnlActionBtns.Size      = new System.Drawing.Size(250, 80);
            this.pnlActionBtns.Controls.AddRange(new System.Windows.Forms.Control[] {
                this.btnObrisi, this.btnAzuriraj, this.btnDodaj, this.btnNovo, this.btnUcitajSve });

            System.Action<System.Windows.Forms.Button, string, int, int, System.Drawing.Color> styleBtn =
                (btn, txt, x, y, col) => {
                    btn.Text      = txt;
                    btn.Location  = new System.Drawing.Point(x, y);
                    btn.Size      = new System.Drawing.Size(115, 34);
                    btn.Font      = new System.Drawing.Font("Segoe UI", 8.5f, System.Drawing.FontStyle.Bold);
                    btn.ForeColor = System.Drawing.Color.White;
                    btn.BackColor = col;
                    btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
                    btn.FlatAppearance.BorderSize = 0;
                    btn.Cursor    = System.Windows.Forms.Cursors.Hand;
                };

            styleBtn(this.btnObrisi,    "Obrisi",      0,  0,  System.Drawing.Color.FromArgb(180, 50, 50));
            styleBtn(this.btnAzuriraj,  "Azuriraj",  127,  0,  System.Drawing.Color.FromArgb(88, 86, 214));
            styleBtn(this.btnDodaj,     "Dodaj",       0, 42,  System.Drawing.Color.FromArgb(34, 139, 34));
            styleBtn(this.btnNovo,      "Ocisti",    127, 42,  System.Drawing.Color.FromArgb(90, 87, 110));

            this.btnNovo.Size = new System.Drawing.Size(115, 34);
            this.btnNovo.Click += new System.EventHandler(this.btnNovo_Click);

            this.btnUcitajSve.Text      = "UcitajNovu";
            this.btnUcitajSve.Location  = new System.Drawing.Point(0, 84);
            this.btnUcitajSve.Size      = new System.Drawing.Size(242, 0); // hidden, kept for compat
            this.btnUcitajSve.Visible   = false;
            this.btnUcitajSve.Click    += new System.EventHandler(this.btnUcitajSve_Click);

            this.btnObrisi.Click   += new System.EventHandler(this.btnObrisi_Click);
            this.btnAzuriraj.Click += new System.EventHandler(this.btnAzuriraj_Click);
            this.btnDodaj.Click    += new System.EventHandler(this.btnDodaj_Click);

            // Separator
            this.pnlSep2.BackColor = System.Drawing.Color.FromArgb(55, 52, 80);
            this.pnlSep2.Location  = new System.Drawing.Point(10, 382);
            this.pnlSep2.Size      = new System.Drawing.Size(248, 1);

            // Filter section
            this.F.Text      = "Filtriraj po";
            this.F.Font      = new System.Drawing.Font("Segoe UI", 9f, System.Drawing.FontStyle.Bold);
            this.F.ForeColor = System.Drawing.Color.FromArgb(180, 176, 220);
            this.F.Location  = new System.Drawing.Point(14, 390);
            this.F.AutoSize  = true;

            styleLabel(this.label5, "Tipu",  14,  412);
            styleLabel(this.label6, "Grupi", 140, 412);
            styleCmb(this.cmbFilterTip,   14,  430, 118);
            styleCmb(this.cmbFilterGrupa, 140, 430, 118);
            this.cmbFilterTip.FormattingEnabled   = true;
            this.cmbFilterGrupa.FormattingEnabled = true;
            this.cmbFilterTip.SelectedIndexChanged   += new System.EventHandler(this.cmbFilterTip_SelectedIndexChanged);
            this.cmbFilterGrupa.SelectedIndexChanged += new System.EventHandler(this.cmbFilterGrupa_SelectedIndexChanged);

            // Separator
            this.pnlSep3.BackColor = System.Drawing.Color.FromArgb(55, 52, 80);
            this.pnlSep3.Location  = new System.Drawing.Point(10, 465);
            this.pnlSep3.Size      = new System.Drawing.Size(248, 1);

            // Dodaj u plan
            styleLabel(this.label7, "Dodaj vježbu u plan", 14, 473);
            this.label7.Font      = new System.Drawing.Font("Segoe UI", 8.5f, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.FromArgb(180, 176, 220);
            this.label7.Click    += new System.EventHandler(this.label7_Click);

            styleCmb(this.comboBox1, 14, 493, 240);
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
                "Ponedeljak","Utorak","Srijeda","Cetvrtak","Petak","Subota","Nedelja"});

            this.button1.Text      = "Dodaj u plan";
            this.button1.Location  = new System.Drawing.Point(14, 525);
            this.button1.Size      = new System.Drawing.Size(240, 34);
            this.button1.Font      = new System.Drawing.Font("Segoe UI", 9f, System.Drawing.FontStyle.Bold);
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.BackColor = System.Drawing.Color.FromArgb(88, 86, 214);
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.Cursor    = System.Windows.Forms.Cursors.Hand;
            this.button1.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.button1.Click    += new System.EventHandler(this.button1_Click);

            // ── FrmVjezbe ────────────────────────────────────────────────
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode       = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize          = new System.Drawing.Size(1027, 631);
            this.Text                = "Vjezbe";
            this.BackColor           = System.Drawing.Color.FromArgb(245, 247, 252);
            this.Controls.Add(this.pnlLeft);
            this.Controls.Add(this.pnlRight);
            this.Load  += new System.EventHandler(this.FrmVjezbe_Load);
            this.Click += new System.EventHandler(this.FrmVjezbe_Click);

            this.pnlLeft.ResumeLayout(false);
            this.pnlRight.ResumeLayout(false);
            this.pnlRight.PerformLayout();
            this.pnlActionBtns.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvVjezbe)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Panel    pnlLeft;
        private System.Windows.Forms.Panel    pnlRight;
        private System.Windows.Forms.Label    lblRightTitle;
        private System.Windows.Forms.Panel    pnlSep1;
        private System.Windows.Forms.Panel    pnlSep2;
        private System.Windows.Forms.Panel    pnlSep3;
        private System.Windows.Forms.Panel    pnlActionBtns;
        private System.Windows.Forms.DataGridView dgvVjezbe;
        private System.Windows.Forms.TextBox  txtNaziv;
        private System.Windows.Forms.TextBox  txtOpis;
        private System.Windows.Forms.Label    label1;
        private System.Windows.Forms.Label    label2;
        private System.Windows.Forms.Label    label3;
        private System.Windows.Forms.Label    label4;
        private System.Windows.Forms.Button   btnObrisi;
        private System.Windows.Forms.Button   btnAzuriraj;
        private System.Windows.Forms.Button   btnDodaj;
        private System.Windows.Forms.Button   btnNovo;
        private System.Windows.Forms.Button   btnUcitajSve;
        private System.Windows.Forms.Button   btnTheme;
        private System.Windows.Forms.ComboBox cmbTip;
        private System.Windows.Forms.ComboBox cmbGrupa;
        private System.Windows.Forms.Label    F;
        private System.Windows.Forms.Label    label5;
        private System.Windows.Forms.Label    label6;
        private System.Windows.Forms.ComboBox cmbFilterTip;
        private System.Windows.Forms.ComboBox cmbFilterGrupa;
        private System.Windows.Forms.Button   button1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label    label7;
    }
}
