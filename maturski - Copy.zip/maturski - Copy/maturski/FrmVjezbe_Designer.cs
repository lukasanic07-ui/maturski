namespace WindowsFormsApplication1
{
    partial class FrmVjezbe
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.dgvVjezbe       = new System.Windows.Forms.DataGridView();
            this.pnlTop          = new System.Windows.Forms.Panel();
            this.lblTitle        = new System.Windows.Forms.Label();
            this.lblFilterTip    = new System.Windows.Forms.Label();
            this.F               = new System.Windows.Forms.Label();
            this.label5          = new System.Windows.Forms.Label();
            this.label6          = new System.Windows.Forms.Label();
            this.cmbFilterTip    = new System.Windows.Forms.ComboBox();
            this.cmbFilterGrupa  = new System.Windows.Forms.ComboBox();
            this.btnTheme        = new System.Windows.Forms.Button();
            this.pnlForma        = new System.Windows.Forms.Panel();
            this.lblFormaHeader  = new System.Windows.Forms.Label();
            this.pnlDivider1     = new System.Windows.Forms.Panel();
            this.label2          = new System.Windows.Forms.Label();
            this.txtNaziv        = new System.Windows.Forms.TextBox();
            this.label3          = new System.Windows.Forms.Label();
            this.txtOpis         = new System.Windows.Forms.TextBox();
            this.label1          = new System.Windows.Forms.Label();
            this.cmbTip          = new System.Windows.Forms.ComboBox();
            this.label4          = new System.Windows.Forms.Label();
            this.cmbGrupa        = new System.Windows.Forms.ComboBox();
            this.pnlDivider2     = new System.Windows.Forms.Panel();
            this.btnDodaj        = new System.Windows.Forms.Button();
            this.btnAzuriraj     = new System.Windows.Forms.Button();
            this.btnObrisi       = new System.Windows.Forms.Button();
            this.btnNovo         = new System.Windows.Forms.Button();
            this.btnUcitajSve    = new System.Windows.Forms.Button();
            this.pnlDivider3     = new System.Windows.Forms.Panel();
            this.label7          = new System.Windows.Forms.Label();
            this.comboBox1       = new System.Windows.Forms.ComboBox();
            this.button1         = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVjezbe)).BeginInit();
            this.pnlTop.SuspendLayout();
            this.pnlForma.SuspendLayout();
            this.SuspendLayout();

            // ── dgvVjezbe ────────────────────────────────────────────────
            this.dgvVjezbe.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvVjezbe.Location = new System.Drawing.Point(0, 55);
            this.dgvVjezbe.Name = "dgvVjezbe";
            this.dgvVjezbe.BackgroundColor = System.Drawing.Color.White;
            this.dgvVjezbe.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvVjezbe.TabIndex = 0;
            this.dgvVjezbe.CellMouseLeave        += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvVjezbe_CellMouseLeave);
            this.dgvVjezbe.CellMouseEnter        += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvVjezbe_CellMouseEnter);
            this.dgvVjezbe.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvVjezbe_ColumnHeaderMouseClick);
            this.dgvVjezbe.RowPrePaint           += new System.Windows.Forms.DataGridViewRowPrePaintEventHandler(this.dgvVjezbe_RowPrePaint);
            this.dgvVjezbe.MouseUp               += new System.Windows.Forms.MouseEventHandler(this.dgvVjezbe_MouseUp);
            this.dgvVjezbe.SelectionChanged      += new System.EventHandler(this.dgvVjezbe_SelectionChanged);
            this.dgvVjezbe.Click                 += new System.EventHandler(this.dgvVjezbe_Click);
            this.dgvVjezbe.CellContentClick      += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvVjezbe_CellContentClick);
            this.dgvVjezbe.DoubleClick           += new System.EventHandler(this.dgvVjezbe_DoubleClick);

            // ── pnlTop ───────────────────────────────────────────────────
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.BackColor = System.Drawing.Color.FromArgb(30, 58, 95);
            this.pnlTop.Height = 55;
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.TabIndex = 1;
            this.pnlTop.Controls.Add(this.lblTitle);
            this.pnlTop.Controls.Add(this.F);
            this.pnlTop.Controls.Add(this.label5);
            this.pnlTop.Controls.Add(this.cmbFilterTip);
            this.pnlTop.Controls.Add(this.label6);
            this.pnlTop.Controls.Add(this.cmbFilterGrupa);
            this.pnlTop.Controls.Add(this.btnTheme);

            // lblTitle
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location = new System.Drawing.Point(15, 14);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Text = "VJEZBE";

            // F (label "Filter:")
            this.F.AutoSize = true;
            this.F.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.F.ForeColor = System.Drawing.Color.FromArgb(180, 210, 240);
            this.F.Location = new System.Drawing.Point(200, 19);
            this.F.Name = "F";
            this.F.Text = "Filter:";

            // label5 ("Tip")
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label5.ForeColor = System.Drawing.Color.FromArgb(180, 210, 240);
            this.label5.Location = new System.Drawing.Point(252, 19);
            this.label5.Name = "label5";
            this.label5.Text = "Tip:";

            // cmbFilterTip
            this.cmbFilterTip.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFilterTip.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbFilterTip.Location = new System.Drawing.Point(285, 16);
            this.cmbFilterTip.Name = "cmbFilterTip";
            this.cmbFilterTip.Size = new System.Drawing.Size(120, 23);
            this.cmbFilterTip.TabIndex = 1;

            // label6 ("Grupa")
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label6.ForeColor = System.Drawing.Color.FromArgb(180, 210, 240);
            this.label6.Location = new System.Drawing.Point(420, 19);
            this.label6.Name = "label6";
            this.label6.Text = "Grupa:";

            // cmbFilterGrupa
            this.cmbFilterGrupa.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFilterGrupa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbFilterGrupa.Location = new System.Drawing.Point(465, 16);
            this.cmbFilterGrupa.Name = "cmbFilterGrupa";
            this.cmbFilterGrupa.Size = new System.Drawing.Size(140, 23);
            this.cmbFilterGrupa.TabIndex = 2;

            // btnTheme
            this.btnTheme.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTheme.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(100, 150, 200);
            this.btnTheme.ForeColor = System.Drawing.Color.White;
            this.btnTheme.BackColor = System.Drawing.Color.FromArgb(50, 80, 120);
            this.btnTheme.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnTheme.Location = new System.Drawing.Point(980, 12);
            this.btnTheme.Name = "btnTheme";
            this.btnTheme.Size = new System.Drawing.Size(100, 30);
            this.btnTheme.TabIndex = 3;
            this.btnTheme.Text = "Dark Mode";
            this.btnTheme.Click += new System.EventHandler(this.btnTheme_Click);

            // ── pnlForma ─────────────────────────────────────────────────
            this.pnlForma.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlForma.BackColor = System.Drawing.Color.White;
            this.pnlForma.Width = 300;
            this.pnlForma.Name = "pnlForma";
            this.pnlForma.Padding = new System.Windows.Forms.Padding(16);
            this.pnlForma.TabIndex = 2;
            this.pnlForma.Controls.Add(this.lblFormaHeader);
            this.pnlForma.Controls.Add(this.pnlDivider1);
            this.pnlForma.Controls.Add(this.label2);
            this.pnlForma.Controls.Add(this.txtNaziv);
            this.pnlForma.Controls.Add(this.label3);
            this.pnlForma.Controls.Add(this.txtOpis);
            this.pnlForma.Controls.Add(this.label1);
            this.pnlForma.Controls.Add(this.cmbTip);
            this.pnlForma.Controls.Add(this.label4);
            this.pnlForma.Controls.Add(this.cmbGrupa);
            this.pnlForma.Controls.Add(this.pnlDivider2);
            this.pnlForma.Controls.Add(this.btnDodaj);
            this.pnlForma.Controls.Add(this.btnAzuriraj);
            this.pnlForma.Controls.Add(this.btnObrisi);
            this.pnlForma.Controls.Add(this.btnNovo);
            this.pnlForma.Controls.Add(this.btnUcitajSve);
            this.pnlForma.Controls.Add(this.pnlDivider3);
            this.pnlForma.Controls.Add(this.label7);
            this.pnlForma.Controls.Add(this.comboBox1);
            this.pnlForma.Controls.Add(this.button1);

            // inner control X and width helpers
            int fx = 16, fw = 268;

            // lblFormaHeader
            this.lblFormaHeader.AutoSize = false;
            this.lblFormaHeader.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblFormaHeader.ForeColor = System.Drawing.Color.FromArgb(30, 58, 95);
            this.lblFormaHeader.Location = new System.Drawing.Point(fx, 12);
            this.lblFormaHeader.Name = "lblFormaHeader";
            this.lblFormaHeader.Size = new System.Drawing.Size(fw, 24);
            this.lblFormaHeader.Text = "DETALJI VJEZBE";

            // pnlDivider1
            this.pnlDivider1.BackColor = System.Drawing.Color.FromArgb(220, 225, 235);
            this.pnlDivider1.Location = new System.Drawing.Point(fx, 40);
            this.pnlDivider1.Name = "pnlDivider1";
            this.pnlDivider1.Size = new System.Drawing.Size(fw, 1);

            // label2 "Naziv"
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(80, 100, 130);
            this.label2.Location = new System.Drawing.Point(fx, 50);
            this.label2.Name = "label2";
            this.label2.Text = "NAZIV";
            this.label2.Click += new System.EventHandler(this.label2_Click);

            // txtNaziv
            this.txtNaziv.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNaziv.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtNaziv.Location = new System.Drawing.Point(fx, 68);
            this.txtNaziv.Name = "txtNaziv";
            this.txtNaziv.Size = new System.Drawing.Size(fw, 26);
            this.txtNaziv.TabIndex = 4;
            this.txtNaziv.TextChanged += new System.EventHandler(this.txtNaziv_TextChanged);

            // label3 "Opis"
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.FromArgb(80, 100, 130);
            this.label3.Location = new System.Drawing.Point(fx, 104);
            this.label3.Name = "label3";
            this.label3.Text = "OPIS";
            this.label3.Click += new System.EventHandler(this.label3_Click);

            // txtOpis
            this.txtOpis.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtOpis.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtOpis.Location = new System.Drawing.Point(fx, 122);
            this.txtOpis.Multiline = true;
            this.txtOpis.Name = "txtOpis";
            this.txtOpis.Size = new System.Drawing.Size(fw, 72);
            this.txtOpis.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtOpis.TabIndex = 5;

            // label1 "Tip"
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(80, 100, 130);
            this.label1.Location = new System.Drawing.Point(fx, 204);
            this.label1.Name = "label1";
            this.label1.Text = "TIP";
            this.label1.Click += new System.EventHandler(this.label1_Click);

            // cmbTip
            this.cmbTip.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTip.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbTip.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.cmbTip.Location = new System.Drawing.Point(fx, 222);
            this.cmbTip.Name = "cmbTip";
            this.cmbTip.Size = new System.Drawing.Size(fw, 24);
            this.cmbTip.TabIndex = 6;

            // label4 "Misicna Grupa"
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.FromArgb(80, 100, 130);
            this.label4.Location = new System.Drawing.Point(fx, 256);
            this.label4.Name = "label4";
            this.label4.Text = "MISICNA GRUPA";
            this.label4.Click += new System.EventHandler(this.label4_Click);

            // cmbGrupa
            this.cmbGrupa.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbGrupa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbGrupa.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.cmbGrupa.Location = new System.Drawing.Point(fx, 274);
            this.cmbGrupa.Name = "cmbGrupa";
            this.cmbGrupa.Size = new System.Drawing.Size(fw, 24);
            this.cmbGrupa.TabIndex = 7;

            // pnlDivider2
            this.pnlDivider2.BackColor = System.Drawing.Color.FromArgb(220, 225, 235);
            this.pnlDivider2.Location = new System.Drawing.Point(fx, 310);
            this.pnlDivider2.Name = "pnlDivider2";
            this.pnlDivider2.Size = new System.Drawing.Size(fw, 1);

            // btnDodaj
            this.btnDodaj.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDodaj.FlatAppearance.BorderSize = 0;
            this.btnDodaj.BackColor = System.Drawing.Color.FromArgb(40, 167, 69);
            this.btnDodaj.ForeColor = System.Drawing.Color.White;
            this.btnDodaj.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnDodaj.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDodaj.Location = new System.Drawing.Point(fx, 320);
            this.btnDodaj.Name = "btnDodaj";
            this.btnDodaj.Size = new System.Drawing.Size(fw, 34);
            this.btnDodaj.TabIndex = 8;
            this.btnDodaj.Text = "+ Dodaj novu vjezbu";
            this.btnDodaj.Click += new System.EventHandler(this.button3_Click);

            // btnAzuriraj
            this.btnAzuriraj.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAzuriraj.FlatAppearance.BorderSize = 0;
            this.btnAzuriraj.BackColor = System.Drawing.Color.FromArgb(0, 123, 255);
            this.btnAzuriraj.ForeColor = System.Drawing.Color.White;
            this.btnAzuriraj.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnAzuriraj.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAzuriraj.Location = new System.Drawing.Point(fx, 362);
            this.btnAzuriraj.Name = "btnAzuriraj";
            this.btnAzuriraj.Size = new System.Drawing.Size(fw, 34);
            this.btnAzuriraj.TabIndex = 9;
            this.btnAzuriraj.Text = "Azuriraj odabranu";
            this.btnAzuriraj.Click += new System.EventHandler(this.btnAzuriraj_Click);

            // btnObrisi (half width, left)
            this.btnObrisi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnObrisi.FlatAppearance.BorderSize = 0;
            this.btnObrisi.BackColor = System.Drawing.Color.FromArgb(220, 53, 69);
            this.btnObrisi.ForeColor = System.Drawing.Color.White;
            this.btnObrisi.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnObrisi.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnObrisi.Location = new System.Drawing.Point(fx, 404);
            this.btnObrisi.Name = "btnObrisi";
            this.btnObrisi.Size = new System.Drawing.Size(130, 34);
            this.btnObrisi.TabIndex = 10;
            this.btnObrisi.Text = "Obrisi";
            this.btnObrisi.Click += new System.EventHandler(this.btnObrisi_Click);

            // btnNovo (half width, right)
            this.btnNovo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNovo.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(180, 185, 195);
            this.btnNovo.BackColor = System.Drawing.Color.FromArgb(240, 242, 245);
            this.btnNovo.ForeColor = System.Drawing.Color.FromArgb(80, 90, 110);
            this.btnNovo.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnNovo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNovo.Location = new System.Drawing.Point(fx + 138, 404);
            this.btnNovo.Name = "btnNovo";
            this.btnNovo.Size = new System.Drawing.Size(130, 34);
            this.btnNovo.TabIndex = 11;
            this.btnNovo.Text = "Ocisti polja";
            this.btnNovo.Click += new System.EventHandler(this.btnNovo_Click);

            // btnUcitajSve
            this.btnUcitajSve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUcitajSve.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(180, 185, 195);
            this.btnUcitajSve.BackColor = System.Drawing.Color.FromArgb(240, 242, 245);
            this.btnUcitajSve.ForeColor = System.Drawing.Color.FromArgb(80, 90, 110);
            this.btnUcitajSve.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnUcitajSve.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUcitajSve.Location = new System.Drawing.Point(fx, 446);
            this.btnUcitajSve.Name = "btnUcitajSve";
            this.btnUcitajSve.Size = new System.Drawing.Size(fw, 34);
            this.btnUcitajSve.TabIndex = 12;
            this.btnUcitajSve.Text = "Osvjezi listu";
            this.btnUcitajSve.Click += new System.EventHandler(this.btnUcitajSve_Click);

            // pnlDivider3
            this.pnlDivider3.BackColor = System.Drawing.Color.FromArgb(220, 225, 235);
            this.pnlDivider3.Location = new System.Drawing.Point(fx, 492);
            this.pnlDivider3.Name = "pnlDivider3";
            this.pnlDivider3.Size = new System.Drawing.Size(fw, 1);

            // label7
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.FromArgb(80, 100, 130);
            this.label7.Location = new System.Drawing.Point(fx, 502);
            this.label7.Name = "label7";
            this.label7.Text = "DODAJ U PLAN";
            this.label7.Click += new System.EventHandler(this.label7_Click);

            // comboBox1 (day selector)
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox1.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.comboBox1.Items.AddRange(new object[] {
                "Ponedeljak", "Utorak", "Srijeda",
                "Cetvrtak",  "Petak",  "Subota", "Nedelja" });
            this.comboBox1.Location = new System.Drawing.Point(fx, 520);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(fw, 24);
            this.comboBox1.TabIndex = 13;

            // button1 "Odaberi"
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(40, 167, 69);
            this.button1.FlatAppearance.BorderSize = 2;
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.ForeColor = System.Drawing.Color.FromArgb(40, 167, 69);
            this.button1.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Location = new System.Drawing.Point(fx, 554);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(fw, 34);
            this.button1.TabIndex = 14;
            this.button1.Text = "Odaberi vjezbu";
            this.button1.Click += new System.EventHandler(this.button1_Click);

            // ── FrmVjezbe ────────────────────────────────────────────────
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(245, 247, 250);
            this.ClientSize = new System.Drawing.Size(1100, 660);
            this.MinimumSize = new System.Drawing.Size(900, 500);
            this.Name = "FrmVjezbe";
            this.Text = "Vjezbe";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.FrmVjezbe_Load);
            this.Click += new System.EventHandler(this.FrmVjezbe_Click);

            // ORDER MATTERS for Dock layout: Fill first, then Right, then Top
            this.Controls.Add(this.dgvVjezbe);
            this.Controls.Add(this.pnlForma);
            this.Controls.Add(this.pnlTop);

            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.pnlForma.ResumeLayout(false);
            this.pnlForma.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVjezbe)).EndInit();
            this.ResumeLayout(false);
        }

        #endregion

        // ── Top bar ──────────────────────────────────────────────────────
        private System.Windows.Forms.Panel       pnlTop;
        private System.Windows.Forms.Label       lblTitle;
        private System.Windows.Forms.Label       F;           // "Filter:"
        private System.Windows.Forms.Label       label5;      // "Tip:"
        private System.Windows.Forms.Label       label6;      // "Grupa:"
        private System.Windows.Forms.ComboBox    cmbFilterTip;
        private System.Windows.Forms.ComboBox    cmbFilterGrupa;
        private System.Windows.Forms.Button      btnTheme;
        private System.Windows.Forms.Label       lblFilterTip;

        // ── Form panel ───────────────────────────────────────────────────
        private System.Windows.Forms.Panel       pnlForma;
        private System.Windows.Forms.Label       lblFormaHeader;
        private System.Windows.Forms.Panel       pnlDivider1;
        private System.Windows.Forms.Label       label2;      // "Naziv"
        private System.Windows.Forms.TextBox     txtNaziv;
        private System.Windows.Forms.Label       label3;      // "Opis"
        private System.Windows.Forms.TextBox     txtOpis;
        private System.Windows.Forms.Label       label1;      // "Tip"
        private System.Windows.Forms.ComboBox    cmbTip;
        private System.Windows.Forms.Label       label4;      // "Misicna Grupa"
        private System.Windows.Forms.ComboBox    cmbGrupa;
        private System.Windows.Forms.Panel       pnlDivider2;
        private System.Windows.Forms.Button      btnDodaj;
        private System.Windows.Forms.Button      btnAzuriraj;
        private System.Windows.Forms.Button      btnObrisi;
        private System.Windows.Forms.Button      btnNovo;
        private System.Windows.Forms.Button      btnUcitajSve;
        private System.Windows.Forms.Panel       pnlDivider3;
        private System.Windows.Forms.Label       label7;
        private System.Windows.Forms.ComboBox    comboBox1;
        private System.Windows.Forms.Button      button1;

        // ── Grid ─────────────────────────────────────────────────────────
        private System.Windows.Forms.DataGridView dgvVjezbe;
    }
}
