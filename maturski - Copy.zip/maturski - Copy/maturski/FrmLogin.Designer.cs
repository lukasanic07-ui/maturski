namespace WindowsFormsApplication1
{
    partial class FrmLogin
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.pnlLijevo = new System.Windows.Forms.Panel();
            this.lblAppNaziv = new System.Windows.Forms.Label();
            this.lblPodnaslov = new System.Windows.Forms.Label();
            this.pnlDesno = new System.Windows.Forms.Panel();
            this.lblNaslov = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtLozinka = new System.Windows.Forms.TextBox();
            this.btnLogin = new System.Windows.Forms.Button();
            this.btnRegistracija = new System.Windows.Forms.Button();
            this.pnlLijevo.SuspendLayout();
            this.pnlDesno.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlLijevo
            // 
            this.pnlLijevo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.pnlLijevo.Controls.Add(this.lblAppNaziv);
            this.pnlLijevo.Controls.Add(this.lblPodnaslov);
            this.pnlLijevo.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlLijevo.Location = new System.Drawing.Point(0, 0);
            this.pnlLijevo.Name = "pnlLijevo";
            this.pnlLijevo.Size = new System.Drawing.Size(200, 275);
            this.pnlLijevo.TabIndex = 1;
            // 
            // lblAppNaziv
            // 
            this.lblAppNaziv.AutoSize = true;
            this.lblAppNaziv.Font = new System.Drawing.Font("Segoe UI", 22F, System.Drawing.FontStyle.Bold);
            this.lblAppNaziv.ForeColor = System.Drawing.Color.White;
            this.lblAppNaziv.Location = new System.Drawing.Point(17, 108);
            this.lblAppNaziv.Name = "lblAppNaziv";
            this.lblAppNaziv.Size = new System.Drawing.Size(158, 41);
            this.lblAppNaziv.TabIndex = 0;
            this.lblAppNaziv.Text = "FitTracker";
            // 
            // lblPodnaslov
            // 
            this.lblPodnaslov.AutoSize = true;
            this.lblPodnaslov.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblPodnaslov.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(220)))));
            this.lblPodnaslov.Location = new System.Drawing.Point(20, 168);
            this.lblPodnaslov.Name = "lblPodnaslov";
            this.lblPodnaslov.Size = new System.Drawing.Size(66, 38);
            this.lblPodnaslov.TabIndex = 1;
            this.lblPodnaslov.Text = "Prati svoj\nnapredak";
            // 
            // pnlDesno
            // 
            this.pnlDesno.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(245)))), ((int)(((byte)(250)))));
            this.pnlDesno.Controls.Add(this.lblNaslov);
            this.pnlDesno.Controls.Add(this.label1);
            this.pnlDesno.Controls.Add(this.txtUsername);
            this.pnlDesno.Controls.Add(this.label2);
            this.pnlDesno.Controls.Add(this.txtLozinka);
            this.pnlDesno.Controls.Add(this.btnLogin);
            this.pnlDesno.Controls.Add(this.btnRegistracija);
            this.pnlDesno.Location = new System.Drawing.Point(199, 0);
            this.pnlDesno.Name = "pnlDesno";
            this.pnlDesno.Padding = new System.Windows.Forms.Padding(30, 20, 30, 20);
            this.pnlDesno.Size = new System.Drawing.Size(275, 276);
            this.pnlDesno.TabIndex = 0;
            // 
            // lblNaslov
            // 
            this.lblNaslov.AutoSize = true;
            this.lblNaslov.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblNaslov.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.lblNaslov.Location = new System.Drawing.Point(30, 25);
            this.lblNaslov.Name = "lblNaslov";
            this.lblNaslov.Size = new System.Drawing.Size(118, 32);
            this.lblNaslov.TabIndex = 0;
            this.lblNaslov.Text = "Prijavi se";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(80)))));
            this.label1.Location = new System.Drawing.Point(30, 90);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "Username *";
            // 
            // txtUsername
            // 
            this.txtUsername.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUsername.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtUsername.Location = new System.Drawing.Point(30, 108);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(230, 25);
            this.txtUsername.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(80)))));
            this.label2.Location = new System.Drawing.Point(30, 148);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "Lozinka *";
            // 
            // txtLozinka
            // 
            this.txtLozinka.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtLozinka.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtLozinka.Location = new System.Drawing.Point(30, 166);
            this.txtLozinka.Name = "txtLozinka";
            this.txtLozinka.Size = new System.Drawing.Size(230, 25);
            this.txtLozinka.TabIndex = 4;
            this.txtLozinka.UseSystemPasswordChar = true;
            // 
            // btnLogin
            // 
            this.btnLogin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.btnLogin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLogin.FlatAppearance.BorderSize = 0;
            this.btnLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogin.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnLogin.ForeColor = System.Drawing.Color.White;
            this.btnLogin.Location = new System.Drawing.Point(30, 215);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(118, 38);
            this.btnLogin.TabIndex = 5;
            this.btnLogin.Text = "Prijavi se";
            this.btnLogin.UseVisualStyleBackColor = false;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // btnRegistracija
            // 
            this.btnRegistracija.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(245)))), ((int)(((byte)(250)))));
            this.btnRegistracija.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRegistracija.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.btnRegistracija.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegistracija.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnRegistracija.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.btnRegistracija.Location = new System.Drawing.Point(154, 215);
            this.btnRegistracija.Name = "btnRegistracija";
            this.btnRegistracija.Size = new System.Drawing.Size(106, 38);
            this.btnRegistracija.TabIndex = 6;
            this.btnRegistracija.Text = "Registruj";
            this.btnRegistracija.UseVisualStyleBackColor = false;
            this.btnRegistracija.Click += new System.EventHandler(this.btnRegistracija_Click);
            // 
            // FrmLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(245)))), ((int)(((byte)(250)))));
            this.ClientSize = new System.Drawing.Size(469, 275);
            this.Controls.Add(this.pnlDesno);
            this.Controls.Add(this.pnlLijevo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmLogin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Login";
            this.Load += new System.EventHandler(this.FrmLogin_Load_1);
            this.pnlLijevo.ResumeLayout(false);
            this.pnlLijevo.PerformLayout();
            this.pnlDesno.ResumeLayout(false);
            this.pnlDesno.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlLijevo;
        private System.Windows.Forms.Label lblAppNaziv;
        private System.Windows.Forms.Label lblPodnaslov;
        private System.Windows.Forms.Panel pnlDesno;
        private System.Windows.Forms.Label lblNaslov;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtLozinka;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Button btnRegistracija;
    }
}