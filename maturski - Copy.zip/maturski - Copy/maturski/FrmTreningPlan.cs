using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApplication1
{
    public class FrmTreningPlan : Form
    {
        // ── Kontrole ────────────────────────────────────────────────────────
        private Panel pnlLijevo;
        private Panel pnlLogoArea;
        private Label lblLogo;
        private ListBox lstbPlanovi;
        private Panel pnlPlanBtns;
        private Button btnNoviPlan;
        private Button btnObrisiPlan;
        private Panel pnlDesno;
        private Panel pnlDesnoTop;
        private Label lblNaziv;
        private TextBox txtNazivPlana;
        private Panel pnlTipFilteri;
        private Label lblFilterSnaga;
        private Label lblFilterKardio;
        private Label lblFilterMob;
        private Label lblFilterIzdrz;
        private DataGridView dgvVjezbeZaDan;
        private Panel pnlDesnoBottom;
        private Button btnDodajVjezbu;
        private Button btnObrisiVjezbu;
        private Button btnSpremiPlan;
        private Label lblStatus;

        // ── Stanje ──────────────────────────────────────────────────────────
        private List<TreningVjezba> vjezbeZaDan = new List<TreningVjezba>();
        private int odabraniPlanID = -1;
        private bool noviPlanMode = false;

        private class TreningVjezba
        {
            public int VjezbaID;
            public string Naziv;
            public string Opis;
            public string Tip;
            public string MisicnaGrupa;
            public int BrojSetova = 3;
            public int BrojPonavljanja = 10;
        }

        public class PlanItem
        {
            public int PlanID;
            public string Naziv;
            public override string ToString() { return Naziv; }
        }

        // ── Tip helperi ─────────────────────────────────────────────────────
        private static string TipIkona(string tip)
        {
            if (tip == null) return "❓";
            switch (tip.Trim())
            {
                case "Snaga": return "🏋️ Snaga";
                case "Kardio": return "🏃 Kardio";
                case "Mobilnost": return "🧘 Mobilnost";
                case "Izdrzljivost": return "💪 Izdržljivost";
                default: return "🏅 " + tip;
            }
        }

        private static Color TipBoja(string tip)
        {
            if (tip == null) return Color.FromArgb(245, 245, 245);
            switch (tip.Trim())
            {
                case "Snaga": return Color.FromArgb(255, 228, 218);
                case "Kardio": return Color.FromArgb(212, 245, 212);
                case "Mobilnost": return Color.FromArgb(210, 232, 255);
                case "Izdrzljivost": return Color.FromArgb(235, 218, 255);
                default: return Color.FromArgb(242, 242, 242);
            }
        }

        private static Color TipBojaTamna(string tip)
        {
            if (tip == null) return Color.Gray;
            switch (tip.Trim())
            {
                case "Snaga": return Color.FromArgb(180, 50, 10);
                case "Kardio": return Color.FromArgb(20, 120, 50);
                case "Mobilnost": return Color.FromArgb(20, 80, 180);
                case "Izdrzljivost": return Color.FromArgb(100, 30, 180);
                default: return Color.FromArgb(60, 60, 60);
            }
        }

        // ── Konstruktor ─────────────────────────────────────────────────────
        public FrmTreningPlan()
        {
            GradiForme();
            UcitajPlanove();
        }

        // ── Gradnja UI ──────────────────────────────────────────────────────
        private void GradiForme()
        {
            this.SuspendLayout();

            this.Text = "Trening planovi";
            this.ClientSize = new Size(820, 480);
            this.MinimumSize = new Size(820, 480);
            this.MaximumSize = new Size(820, 480);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.Font = new Font("Segoe UI", 9f);
            this.BackColor = Color.FromArgb(245, 247, 250);

            // ── LIJEVA SIDEBAR ───────────────────────────────────────────
            pnlLijevo = new Panel
            {
                Dock = DockStyle.Left,
                Width = 200,
                BackColor = Color.FromArgb(28, 25, 45)
            };

            pnlLogoArea = new Panel
            {
                Dock = DockStyle.Top,
                Height = 70,
                BackColor = Color.FromArgb(34, 31, 53)
            };

            lblLogo = new Label
            {
                Text = "🏋 Moji planovi",
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                ForeColor = Color.White
            };
            pnlLogoArea.Controls.Add(lblLogo);

            lstbPlanovi = new ListBox
            {
                Dock = DockStyle.Fill,
                BorderStyle = BorderStyle.None,
                DrawMode = DrawMode.OwnerDrawFixed,
                ItemHeight = 28,
                BackColor = Color.FromArgb(40, 37, 62),
                ForeColor = Color.FromArgb(200, 196, 230),
                Font = new Font("Segoe UI", 9.5f)
            };
            lstbPlanovi.DrawItem += lstbPlanovi_DrawItem;
            lstbPlanovi.SelectedIndexChanged += lstbPlanovi_SelectedIndexChanged;

            pnlPlanBtns = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 54,
                BackColor = Color.FromArgb(28, 25, 45)
            };

            btnNoviPlan = new Button { Text = "+ Novi plan", Location = new Point(6, 9), Size = new Size(88, 36) };
            btnObrisiPlan = new Button { Text = "🗑 Obriši", Location = new Point(100, 9), Size = new Size(92, 36) };
            btnNoviPlan.Click += btnNoviPlan_Click;
            btnObrisiPlan.Click += btnObrisiPlan_Click;
            StilBtn(btnNoviPlan, Color.FromArgb(88, 86, 214), Color.White);
            StilBtn(btnObrisiPlan, Color.FromArgb(180, 50, 50), Color.White);

            pnlPlanBtns.Controls.Add(btnNoviPlan);
            pnlPlanBtns.Controls.Add(btnObrisiPlan);

            pnlLijevo.Controls.Add(lstbPlanovi);
            pnlLijevo.Controls.Add(pnlPlanBtns);
            pnlLijevo.Controls.Add(pnlLogoArea);

            // ── DESNA STRANA ─────────────────────────────────────────────
            pnlDesno = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(245, 247, 252)
            };

            pnlDesnoTop = new Panel
            {
                Dock = DockStyle.Top,
                Height = 50,
                BackColor = Color.White
            };

            lblNaziv = new Label
            {
                Text = "Naziv:",
                Location = new Point(10, 15),
                AutoSize = true,
                Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                ForeColor = Color.FromArgb(88, 86, 214)
            };

            txtNazivPlana = new TextBox
            {
                Location = new Point(58, 12),
                Size = new Size(210, 26),
                Font = new Font("Segoe UI", 9.5f),
                BorderStyle = BorderStyle.FixedSingle,
                ReadOnly = true
            };

            pnlTipFilteri = new Panel
            {
                Location = new Point(280, 10),
                Size = new Size(430, 32),
                BackColor = Color.Transparent
            };

            lblFilterSnaga = new Label(); lblFilterKardio = new Label();
            lblFilterMob = new Label(); lblFilterIzdrz = new Label();
            StilBadge(lblFilterSnaga, "🏋 Snaga", 0, Color.FromArgb(180, 50, 50));
            StilBadge(lblFilterKardio, "🏃 Kardio", 80, Color.FromArgb(34, 139, 34));
            StilBadge(lblFilterMob, "🧘 Mobilnost", 160, Color.FromArgb(88, 86, 214));
            StilBadge(lblFilterIzdrz, "💪 Izdržljivost", 255, Color.FromArgb(200, 130, 0));
            pnlTipFilteri.Controls.AddRange(new Control[] { lblFilterSnaga, lblFilterKardio, lblFilterMob, lblFilterIzdrz });

            pnlDesnoTop.Controls.Add(lblNaziv);
            pnlDesnoTop.Controls.Add(txtNazivPlana);
            pnlDesnoTop.Controls.Add(pnlTipFilteri);

            // ── DataGridView ─────────────────────────────────────────────
            dgvVjezbeZaDan = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None,
                AllowUserToAddRows = false,
                AllowUserToResizeRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoGenerateColumns = false,
                RowHeadersVisible = false,
                ScrollBars = ScrollBars.Vertical,
                EnableHeadersVisualStyles = false,
                ColumnHeadersHeight = 36,
                ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing,
                CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal,
                GridColor = Color.FromArgb(220, 220, 228)
            };

            dgvVjezbeZaDan.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(34, 31, 53);
            dgvVjezbeZaDan.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgvVjezbeZaDan.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
            dgvVjezbeZaDan.DefaultCellStyle.Font = new Font("Segoe UI", 9f);
            dgvVjezbeZaDan.DefaultCellStyle.Padding = new Padding(6, 4, 6, 4);
            dgvVjezbeZaDan.DefaultCellStyle.SelectionBackColor = Color.FromArgb(88, 86, 214);
            dgvVjezbeZaDan.DefaultCellStyle.SelectionForeColor = Color.White;
            dgvVjezbeZaDan.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 248, 252);
            dgvVjezbeZaDan.RowTemplate.Height = 30;

            // Tip i Naziv – read-only
            dgvVjezbeZaDan.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "Tip",
                Name = "colTip",
                Width = 100,
                ReadOnly = true
            });
            dgvVjezbeZaDan.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "Naziv vježbe",
                Name = "colNazivVjezbe",
                AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill,
                ReadOnly = true
            });
            dgvVjezbeZaDan.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "Mišićna grupa",
                Name = "colMisicnaGrupa",
                Width = 120,
                ReadOnly = true
            });
            // Setovi i Ponavljanja su EDITABILNI
            dgvVjezbeZaDan.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "Setovi",
                Name = "colSetovi",
                Width = 65,
                ReadOnly = false
            });
            dgvVjezbeZaDan.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "Ponavljanja",
                Name = "colPonavljanja",
                Width = 90,
                ReadOnly = false
            });

            dgvVjezbeZaDan.CellFormatting += dgvVjezbeZaDan_CellFormatting;
            dgvVjezbeZaDan.RowPrePaint += dgvVjezbeZaDan_RowPrePaint;
            // Novi event – validacija i čuvanje izmjena setova/ponavljanja
            dgvVjezbeZaDan.CellEndEdit += dgvVjezbeZaDan_CellEndEdit;

            // Bottom action bar
            pnlDesnoBottom = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 62,
                BackColor = Color.White
            };

            btnDodajVjezbu = new Button { Text = "+ Dodaj vježbu", Location = new Point(10, 11), Size = new Size(148, 38) };
            btnObrisiVjezbu = new Button { Text = "🗑 Obriši vježbu", Location = new Point(166, 11), Size = new Size(148, 38) };
            btnSpremiPlan = new Button { Text = "💾 Spremi plan", Location = new Point(322, 11), Size = new Size(148, 38) };

            btnDodajVjezbu.Click += btnDodajVjezbu_Click;
            btnObrisiVjezbu.Click += btnObrisiVjezbu_Click;
            btnSpremiPlan.Click += btnSpremiPlan_Click;

            StilBtn(btnDodajVjezbu, Color.FromArgb(34, 139, 34), Color.White);
            StilBtn(btnObrisiVjezbu, Color.FromArgb(180, 50, 50), Color.White);
            StilBtn(btnSpremiPlan, Color.FromArgb(88, 86, 214), Color.White);

            lblStatus = new Label
            {
                Text = "Odaberite plan sa lijeve strane ili kreirajte novi.",
                Location = new Point(468, 20),
                Size = new Size(310, 22),
                AutoSize = false,
                ForeColor = Color.FromArgb(100, 100, 120),
                Font = new Font("Segoe UI", 8f, FontStyle.Italic)
            };

            pnlDesnoBottom.Controls.Add(btnDodajVjezbu);
            pnlDesnoBottom.Controls.Add(btnObrisiVjezbu);
            pnlDesnoBottom.Controls.Add(btnSpremiPlan);
            pnlDesnoBottom.Controls.Add(lblStatus);

            pnlDesno.Controls.Add(dgvVjezbeZaDan);
            pnlDesno.Controls.Add(pnlDesnoBottom);
            pnlDesno.Controls.Add(pnlDesnoTop);

            this.Controls.Add(pnlDesno);
            this.Controls.Add(pnlLijevo);
            this.ResumeLayout(false);
        }

        // ── Stil helperi ─────────────────────────────────────────────────────
        private void StilBtn(Button b, Color back, Color fore)
        {
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderSize = 0;
            b.BackColor = back;
            b.ForeColor = fore;
            b.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
            b.Cursor = Cursors.Hand;
        }

        private void StilBadge(Label lbl, string tekst, int x, Color boja)
        {
            lbl.Text = tekst;
            lbl.Font = new Font("Segoe UI", 8f, FontStyle.Bold);
            lbl.ForeColor = boja;
            lbl.Location = new Point(x, 8);
            lbl.AutoSize = true;
            lbl.Cursor = Cursors.Hand;
        }

        // ── Grid eventi ─────────────────────────────────────────────────────
        private void dgvVjezbeZaDan_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            if (e.RowIndex < 0 || e.RowIndex >= vjezbeZaDan.Count) return;
            // Ne prepisuj pozadinu ako ima >4 seta – CellFormatting će je bojati crvenom
            if (vjezbeZaDan[e.RowIndex].BrojSetova <= 4)
                dgvVjezbeZaDan.Rows[e.RowIndex].DefaultCellStyle.BackColor =
                    TipBoja(vjezbeZaDan[e.RowIndex].Tip);
        }

        private void dgvVjezbeZaDan_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.RowIndex < 0 || e.RowIndex >= vjezbeZaDan.Count) return;
            var v = vjezbeZaDan[e.RowIndex];
            string colName = dgvVjezbeZaDan.Columns[e.ColumnIndex].Name;

            // Stilizacija Tip kolone (tip boja + bold)
            if (colName == "colTip")
            {
                e.CellStyle.ForeColor = TipBojaTamna(v.Tip);
                e.CellStyle.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
                e.CellStyle.BackColor = TipBoja(v.Tip);
            }

            // Ako je broj setova > 4, označi Setovi ćeliju crvenom s ⚠ simbolom
            if (colName == "colSetovi" && v.BrojSetova > 4)
            {
                e.CellStyle.BackColor = Color.FromArgb(255, 200, 200);
                e.CellStyle.ForeColor = Color.FromArgb(180, 0, 0);
                e.CellStyle.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
                e.Value = "⚠ " + v.BrojSetova;
                e.FormattingApplied = true;
            }
        }

        // ── Novi event: CellEndEdit – čuva izmjene Setova i Ponavljanja ─────
        private void dgvVjezbeZaDan_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.RowIndex >= vjezbeZaDan.Count) return;
            string colName = dgvVjezbeZaDan.Columns[e.ColumnIndex].Name;
            if (colName != "colSetovi" && colName != "colPonavljanja") return;

            object raw = dgvVjezbeZaDan.Rows[e.RowIndex].Cells[e.ColumnIndex].Value;
            int vrijednost;
            if (!int.TryParse(raw == null ? "" : raw.ToString().Replace("⚠ ", "").Trim(), out vrijednost)
                || vrijednost < 1)
            {
                MessageBox.Show("Unesite pozitivan cijeli broj!", "Neispravna vrijednost",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                // Vrati staru vrijednost
                if (colName == "colSetovi")
                    dgvVjezbeZaDan.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = vjezbeZaDan[e.RowIndex].BrojSetova;
                else
                    dgvVjezbeZaDan.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = vjezbeZaDan[e.RowIndex].BrojPonavljanja;
                return;
            }

            if (colName == "colSetovi")
            {
                vjezbeZaDan[e.RowIndex].BrojSetova = vrijednost;

                // Upozorenje za više od 4 serije
                if (vrijednost > 4)
                {
                    MessageBox.Show(
                        "⚠ Nepreporučeno je raditi više od 4 serije jedne vježbe!\n\n" +
                        "Broj serija " + vrijednost + " je zapisan, ali imajte na umu " +
                        "da to može dovesti do prekomjernog zamora mišića.",
                        "Upozorenje – previše serija",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else // colPonavljanja
            {
                vjezbeZaDan[e.RowIndex].BrojPonavljanja = vrijednost;
            }

            // Automatski sačuvaj u bazu ako plan nije u noviPlanMode
            if (!noviPlanMode && odabraniPlanID != -1)
                AzurirajPlanUBazi();

            // Osvježi grid da CellFormatting primijeni crvenu boju
            dgvVjezbeZaDan.InvalidateRow(e.RowIndex);
        }

        private void lstbPlanovi_DrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0) return;
            bool sel = (e.State & DrawItemState.Selected) != 0;
            Color bg = sel
                ? Color.FromArgb(88, 86, 214)
                : (e.Index % 2 == 0 ? Color.FromArgb(40, 37, 62) : Color.FromArgb(46, 43, 68));

            e.Graphics.FillRectangle(new SolidBrush(bg), e.Bounds);
            e.Graphics.DrawString(
                "📋  " + lstbPlanovi.Items[e.Index].ToString(),
                new Font("Segoe UI", 9.5f, sel ? FontStyle.Bold : FontStyle.Regular),
                new SolidBrush(Color.White),
                new PointF(e.Bounds.X + 8, e.Bounds.Y + 6));
        }

        // ── Logika ───────────────────────────────────────────────────────────
        private void UcitajPlanove()
        {
            lstbPlanovi.Items.Clear();
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                using (MySqlCommand cmd = new MySqlCommand(
                    "SELECT PlanID, Naziv FROM treningplan " +
                    "WHERE KorisnikID=@kid ORDER BY DatumKreiranja DESC", conn))
                {
                    cmd.Parameters.AddWithValue("@kid", KorisnikManager.TrenutniKorisnikID);
                    using (MySqlDataReader r = cmd.ExecuteReader())
                        while (r.Read())
                            lstbPlanovi.Items.Add(new PlanItem { PlanID = r.GetInt32(0), Naziv = r.GetString(1) });
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška pri učitavanju planova: " + ex.Message, "Greška",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void lstbPlanovi_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstbPlanovi.SelectedItem == null) return;
            noviPlanMode = false;
            var plan = (PlanItem)lstbPlanovi.SelectedItem;
            odabraniPlanID = plan.PlanID;
            txtNazivPlana.Text = plan.Naziv;
            txtNazivPlana.ReadOnly = true;
            UcitajVjezbeZaPlan(plan.PlanID);
            lblStatus.Text = "Plan učitan. Dodajte ili obrišite vježbe.";
        }

        private void UcitajVjezbeZaPlan(int planID)
        {
            vjezbeZaDan.Clear();
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                using (MySqlCommand cmd = new MySqlCommand(
                    "SELECT v.VjezbaID, v.Naziv, v.Opis, v.Tip, v.MisicnaGrupa, " +
                    "pv.BrojSetova, pv.BrojPonavljanja " +
                    "FROM planvjezba pv JOIN vjezba v ON v.VjezbaID=pv.VjezbaID " +
                    "WHERE pv.PlanID=@pid", conn))
                {
                    cmd.Parameters.AddWithValue("@pid", planID);
                    using (MySqlDataReader r = cmd.ExecuteReader())
                        while (r.Read())
                            vjezbeZaDan.Add(new TreningVjezba
                            {
                                VjezbaID = r.GetInt32(0),
                                Naziv = r.GetString(1),
                                Opis = r.IsDBNull(2) ? "" : r.GetString(2),
                                Tip = r.GetString(3),
                                MisicnaGrupa = r.GetString(4),
                                BrojSetova = r.IsDBNull(5) ? 3 : r.GetInt32(5),
                                BrojPonavljanja = r.IsDBNull(6) ? 10 : r.GetInt32(6)
                            });
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška pri učitavanju vježbi: " + ex.Message, "Greška",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            OsvjeziGrid();
        }

        private void OsvjeziGrid()
        {
            dgvVjezbeZaDan.Rows.Clear();
            foreach (TreningVjezba v in vjezbeZaDan)
                dgvVjezbeZaDan.Rows.Add(
                    TipIkona(v.Tip), v.Naziv, v.MisicnaGrupa,
                    v.BrojSetova, v.BrojPonavljanja);
        }

        private void btnNoviPlan_Click(object sender, EventArgs e)
        {
            noviPlanMode = true;
            odabraniPlanID = -1;
            vjezbeZaDan.Clear();
            OsvjeziGrid();
            txtNazivPlana.ReadOnly = false;
            txtNazivPlana.Text = "Novi plan " + DateTime.Now.ToString("dd.MM.yyyy");
            txtNazivPlana.Focus();
            lstbPlanovi.ClearSelected();
            lblStatus.Text = "Unesite naziv i dodajte vježbe, zatim kliknite Spremi.";
        }

        private void btnDodajVjezbu_Click(object sender, EventArgs e)
        {
            if (!noviPlanMode && odabraniPlanID == -1)
            {
                MessageBox.Show("Odaberite plan ili kliknite 'Novi plan'!", "Upozorenje",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            FrmVjezbe f = new FrmVjezbe();
            if (f.ShowDialog() == DialogResult.OK && f.OdabranaVjezba != null)
            {
                foreach (TreningVjezba tv in vjezbeZaDan)
                    if (tv.VjezbaID == f.OdabranaVjezba.VjezbaID)
                    {
                        MessageBox.Show("Ta vježba je već u planu!", "Upozorenje",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                vjezbeZaDan.Add(new TreningVjezba
                {
                    VjezbaID = f.OdabranaVjezba.VjezbaID,
                    Naziv = f.OdabranaVjezba.Naziv,
                    Opis = f.OdabranaVjezba.Opis,
                    Tip = f.OdabranaVjezba.Tip,
                    MisicnaGrupa = f.OdabranaVjezba.MisicnaGrupa,
                    BrojSetova = 3,
                    BrojPonavljanja = 10
                });
                OsvjeziGrid();
                if (!noviPlanMode) AzurirajPlanUBazi();
            }
        }

        private void btnObrisiVjezbu_Click(object sender, EventArgs e)
        {
            if (dgvVjezbeZaDan.CurrentRow == null)
            {
                MessageBox.Show("Odaberite vježbu za brisanje!", "Upozorenje",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            int idx = dgvVjezbeZaDan.CurrentRow.Index;
            if (idx < 0 || idx >= vjezbeZaDan.Count) return;

            if (!noviPlanMode && odabraniPlanID != -1)
            {
                try
                {
                    using (MySqlConnection conn = DbHelper.GetConnection())
                    using (MySqlCommand cmd = new MySqlCommand(
                        "DELETE FROM planvjezba WHERE PlanID=@pid AND VjezbaID=@vid", conn))
                    {
                        cmd.Parameters.AddWithValue("@pid", odabraniPlanID);
                        cmd.Parameters.AddWithValue("@vid", vjezbeZaDan[idx].VjezbaID);
                        cmd.ExecuteNonQuery();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Greška pri brisanju vježbe: " + ex.Message, "Greška",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }
            vjezbeZaDan.RemoveAt(idx);
            OsvjeziGrid();
            lblStatus.Text = "Vježba obrisana.";
        }

        private void btnObrisiPlan_Click(object sender, EventArgs e)
        {
            if (odabraniPlanID == -1)
            {
                MessageBox.Show("Odaberite plan!", "Upozorenje",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            var plan = lstbPlanovi.SelectedItem as PlanItem;
            if (plan == null) return;
            if (MessageBox.Show("Obrisati plan '" + plan.Naziv + "'?", "Potvrda brisanja",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                {
                    using (MySqlCommand cmd = new MySqlCommand(
                        "DELETE FROM planvjezba WHERE PlanID=@pid", conn))
                    { cmd.Parameters.AddWithValue("@pid", odabraniPlanID); cmd.ExecuteNonQuery(); }
                    using (MySqlCommand cmd = new MySqlCommand(
                        "DELETE FROM treningplan WHERE PlanID=@pid", conn))
                    { cmd.Parameters.AddWithValue("@pid", odabraniPlanID); cmd.ExecuteNonQuery(); }
                }
                odabraniPlanID = -1;
                vjezbeZaDan.Clear();
                OsvjeziGrid();
                txtNazivPlana.Text = "";
                UcitajPlanove();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška pri brisanju plana: " + ex.Message, "Greška",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSpremiPlan_Click(object sender, EventArgs e)
        {
            if (vjezbeZaDan.Count == 0)
            {
                MessageBox.Show("Dodaj barem jednu vježbu!", "Upozorenje",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            string naziv = txtNazivPlana.Text.Trim();
            if (naziv.Length == 0)
            {
                MessageBox.Show("Upišite naziv plana!", "Upozorenje",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (noviPlanMode) SpremiNoviPlan(naziv);
            else AzurirajPlanUBazi();
        }

        private void SpremiNoviPlan(string naziv)
        {
            try
            {
                int planID;
                using (MySqlConnection conn = DbHelper.GetConnection())
                {
                    using (MySqlCommand cmd = new MySqlCommand(
                        "INSERT INTO treningplan (KorisnikID,Naziv,DatumKreiranja) " +
                        "VALUES (@kid,@n,@d); SELECT LAST_INSERT_ID();", conn))
                    {
                        cmd.Parameters.AddWithValue("@kid", KorisnikManager.TrenutniKorisnikID);
                        cmd.Parameters.AddWithValue("@n", naziv);
                        cmd.Parameters.AddWithValue("@d", DateTime.Now.ToString("yyyy-MM-dd"));
                        planID = Convert.ToInt32(cmd.ExecuteScalar());
                    }
                    foreach (TreningVjezba v in vjezbeZaDan)
                        using (MySqlCommand cmd = new MySqlCommand(
                            "INSERT INTO planvjezba (PlanID,VjezbaID,BrojSetova,BrojPonavljanja) " +
                            "VALUES (@pid,@vid,@bs,@bp)", conn))
                        {
                            cmd.Parameters.AddWithValue("@pid", planID);
                            cmd.Parameters.AddWithValue("@vid", v.VjezbaID);
                            cmd.Parameters.AddWithValue("@bs", v.BrojSetova);
                            cmd.Parameters.AddWithValue("@bp", v.BrojPonavljanja);
                            cmd.ExecuteNonQuery();
                        }
                    odabraniPlanID = planID;
                    noviPlanMode = false;
                    txtNazivPlana.ReadOnly = true;
                }
                MessageBox.Show("Plan '" + naziv + "' uspješno sačuvan!", "Uspjeh",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                lblStatus.Text = "✅  Plan sačuvan!";
                UcitajPlanove();
                foreach (object item in lstbPlanovi.Items)
                    if (((PlanItem)item).PlanID == odabraniPlanID)
                    { lstbPlanovi.SelectedItem = item; break; }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška pri snimanju plana: " + ex.Message, "Greška",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void AzurirajPlanUBazi()
        {
            if (odabraniPlanID == -1) return;
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                {
                    using (MySqlCommand cmd = new MySqlCommand(
                        "DELETE FROM planvjezba WHERE PlanID=@pid", conn))
                    { cmd.Parameters.AddWithValue("@pid", odabraniPlanID); cmd.ExecuteNonQuery(); }

                    foreach (TreningVjezba v in vjezbeZaDan)
                        using (MySqlCommand cmd = new MySqlCommand(
                            "INSERT INTO planvjezba (PlanID,VjezbaID,BrojSetova,BrojPonavljanja) " +
                            "VALUES (@pid,@vid,@bs,@bp)", conn))
                        {
                            cmd.Parameters.AddWithValue("@pid", odabraniPlanID);
                            cmd.Parameters.AddWithValue("@vid", v.VjezbaID);
                            cmd.Parameters.AddWithValue("@bs", v.BrojSetova);
                            cmd.Parameters.AddWithValue("@bp", v.BrojPonavljanja);
                            cmd.ExecuteNonQuery();
                        }

                    using (MySqlCommand cmd = new MySqlCommand(
                        "UPDATE treningplan SET Naziv=@n WHERE PlanID=@pid", conn))
                    {
                  //      cmd.Parameters.AddWithValue("@n", txtNazivPlana.Text.Trim());
                 //       cmd.Parameters.AddWithValue("@pid", odabraniPlanID);
                      //  cmd.ExecuteNonQuery();
                    }
                }
                lblStatus.Text = "✅  Promjene sačuvane!";
                UcitajPlanove();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška pri ažuriranju plana: " + ex.Message, "Greška",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}