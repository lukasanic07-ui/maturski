using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApplication1
{
    public class FrmNaslovna : Form
    {
        // ── Kontrole ─────────────────────────────────────────────────────
        private Panel        pnlSidebar;
        private Label        lblFit;
        private Button       btnHome;
        private Button       btnVjezbe;
        private Button       btnPlanovi;
        private Button       btnEvidencija;
        private Panel        pnlTop;
        private Label        lblTopNaslov;
        private Label        lblTopKorisnik;
        private Panel        pnlRecap;
        private Label        lblOdaberiPlan;
        private ComboBox     cmbPlanovi;
        private Label        lblPlanVjezbe;
        private DataGridView dgvPlanVjezbe;
        private Panel        pnlToday;
        private Label        lblDanasnji;
        private Label        lblUputstvo;
        private DataGridView dgvLog;
        private Button       btnZapocniTrening;
        private Button       btnSpremiTrening;
        private Label        lblStatus;

        // ── Podaci ───────────────────────────────────────────────────────
        private int              aktivniTreningID = -1;
        private List<LogVjezba>  logVjezbe        = new List<LogVjezba>();

        private class LogVjezba
        {
            public int    VjezbaID;
            public string Naziv;
            public int    PlaniraniSetovi;
            public int    PlaniranaPonavl;
        }

        private class PlanItem
        {
            public int    PlanID;
            public string Naziv;
            public override string ToString() { return Naziv; }
        }

        // ── Konstruktor ──────────────────────────────────────────────────
        public FrmNaslovna()
        {
            GradiForme();
            PrimijeniStil();
            UcitajPlanoveZaDanas();
        }

        // ── Gradnja forme ────────────────────────────────────────────────
        private void GradiForme()
        {
            this.SuspendLayout();
            this.Text          = "FitApp";
            this.ClientSize    = new Size(1140, 700);
            this.MinimumSize   = new Size(1140, 700);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Font          = new Font("Segoe UI", 9f);

            // ── Sidebar ──────────────────────────────────────────────────
            pnlSidebar = new Panel { Dock = DockStyle.Left, Size = new Size(110, 700) };

            lblFit = new Label
            {
                Text      = "Fit",
                Location  = new Point(0, 10),
                Size      = new Size(110, 80),
                TextAlign = ContentAlignment.MiddleCenter
            };

            btnHome       = SbBtn("Korisnik",   100);
            btnVjezbe     = SbBtn("Vjezbe",     175);
            btnPlanovi    = SbBtn("Planovi",    250);
            btnEvidencija = SbBtn("Evidencija", 325);

            btnHome.Click       += (s, e) => { using (var f = new FrmKorisnik()) f.ShowDialog(); };
            btnVjezbe.Click     += (s, e) => { using (var f = new FrmVjezbe())   f.ShowDialog(); };
            btnPlanovi.Click    += btnPlanovi_Click;
            btnEvidencija.Click += (s, e) => { using (var f = new FrmEvidencija()) f.ShowDialog(); };

            pnlSidebar.Controls.AddRange(new Control[]
                { lblFit, btnHome, btnVjezbe, btnPlanovi, btnEvidencija });

            // ── Top bar ──────────────────────────────────────────────────
            pnlTop = new Panel { Dock = DockStyle.Top, Height = 70 };

            lblTopNaslov = new Label
            {
                Text     = "Pocetna stranica",
                Location = new Point(16, 12),
                AutoSize = true
            };
            lblTopKorisnik = new Label
            {
                Text     = "",
                Location = new Point(16, 42),
                AutoSize = true
            };
            pnlTop.Controls.AddRange(new Control[] { lblTopNaslov, lblTopKorisnik });

            // ── pnlRecap - lijevo: odabir plana + pregled ────────────────
            pnlRecap = new Panel
            {
                Location = new Point(118, 78),
                Size     = new Size(460, 612)
            };

            lblOdaberiPlan = new Label
            {
                Text     = "Odaberi plan za danas:",
                Location = new Point(12, 14),
                AutoSize = true
            };

            cmbPlanovi = new ComboBox
            {
                Location      = new Point(12, 40),
                Size          = new Size(432, 24),
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            cmbPlanovi.SelectedIndexChanged += cmbPlanovi_SelectedIndexChanged;

            lblPlanVjezbe = new Label
            {
                Text     = "Vjezbe u planu:",
                Location = new Point(12, 74),
                AutoSize = true
            };

            dgvPlanVjezbe = new DataGridView
            {
                Location            = new Point(12, 96),
                Size                = new Size(432, 500),
                ReadOnly            = true,
                AllowUserToAddRows  = false,
                SelectionMode       = DataGridViewSelectionMode.FullRowSelect,
                AutoGenerateColumns = false,
                ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
            };
            dgvPlanVjezbe.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Naziv vjezbe",  Name = "cNaziv",  Width = 155 });
            dgvPlanVjezbe.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Tip",           Name = "cTip",    Width = 80  });
            dgvPlanVjezbe.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Grupa",         Name = "cGrupa",  Width = 90  });
            dgvPlanVjezbe.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Setovi x Rep.", Name = "cSetovi", Width = 100 });

            pnlRecap.Controls.AddRange(new Control[]
                { lblOdaberiPlan, cmbPlanovi, lblPlanVjezbe, dgvPlanVjezbe });

            // ── pnlToday - desno: logovanje treninga ─────────────────────
            pnlToday = new Panel
            {
                Location = new Point(585, 78),
                Size     = new Size(545, 612)
            };

            lblDanasnji = new Label
            {
                Text     = "Loguj danasnji trening:",
                Location = new Point(12, 14),
                AutoSize = true
            };

            lblUputstvo = new Label
            {
                Text     = "Odaberite plan sa lijeve strane.",
                Location = new Point(12, 40),
                Size     = new Size(520, 28),
                AutoSize = false
            };

            // Grid za logovanje - kolone: Vjezba | Plan | Set1 kg | Set2 kg | Set3 kg | Pon. | Uradjeno
            dgvLog = new DataGridView
            {
                Location            = new Point(12, 76),
                Size                = new Size(518, 460),
                AllowUserToAddRows  = false,
                SelectionMode       = DataGridViewSelectionMode.FullRowSelect,
                AutoGenerateColumns = false,
                ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize,
                ScrollBars          = ScrollBars.Both
            };

            var cN  = new DataGridViewTextBoxColumn  { HeaderText = "Vjezba",     Name = "cN",   Width = 120, ReadOnly = true };
            var cP  = new DataGridViewTextBoxColumn  { HeaderText = "Planirano",  Name = "cP",   Width = 72,  ReadOnly = true };
            var cS1 = new DataGridViewTextBoxColumn  { HeaderText = "Set 1 (kg)", Name = "cS1",  Width = 72 };
            var cS2 = new DataGridViewTextBoxColumn  { HeaderText = "Set 2 (kg)", Name = "cS2",  Width = 72 };
            var cS3 = new DataGridViewTextBoxColumn  { HeaderText = "Set 3 (kg)", Name = "cS3",  Width = 72 };
            var cPon= new DataGridViewTextBoxColumn  { HeaderText = "Pon./set",   Name = "cPon", Width = 65 };
            var cCh = new DataGridViewCheckBoxColumn { HeaderText = "Gotovo",     Name = "cCh",  Width = 58 };
            dgvLog.Columns.AddRange(new DataGridViewColumn[] { cN, cP, cS1, cS2, cS3, cPon, cCh });

            lblStatus = new Label
            {
                Text     = "",
                Location = new Point(12, 542),
                Size     = new Size(520, 18),
                AutoSize = false,
                ForeColor= Color.FromArgb(88, 86, 214)
            };

            btnZapocniTrening = new Button
            {
                Text     = "▶  Zapocni trening",
                Location = new Point(12, 566),
                Size     = new Size(170, 38)
            };
            btnZapocniTrening.Click += btnZapocniTrening_Click;

            btnSpremiTrening = new Button
            {
                Text     = "✔  Spremi trening",
                Location = new Point(356, 566),
                Size     = new Size(170, 38)
            };
            btnSpremiTrening.Click += btnSpremiTrening_Click;

            pnlToday.Controls.AddRange(new Control[]
                { lblDanasnji, lblUputstvo, dgvLog, lblStatus, btnZapocniTrening, btnSpremiTrening });

            // ── Forma ────────────────────────────────────────────────────
            this.Controls.Add(pnlToday);
            this.Controls.Add(pnlRecap);
            this.Controls.Add(pnlTop);
            this.Controls.Add(pnlSidebar);
            this.ResumeLayout(false);
        }

        private Button SbBtn(string txt, int top)
        {
            return new Button { Text = txt, Location = new Point(5, top), Size = new Size(100, 60) };
        }

        // ── Stil ─────────────────────────────────────────────────────────
        private void PrimijeniStil()
        {
            this.BackColor = Color.FromArgb(245, 247, 250);

            // Sidebar
            pnlSidebar.BackColor = Color.FromArgb(88, 86, 214);
            lblFit.ForeColor = Color.White;
            lblFit.Font      = new Font("Segoe UI", 26f, FontStyle.Bold);
            foreach (Control c in pnlSidebar.Controls)
                if (c is Button) SbStil((Button)c);

            // Top
            pnlTop.BackColor        = Color.White;
            lblTopNaslov.Font       = new Font("Segoe UI", 14f, FontStyle.Bold);
            lblTopNaslov.ForeColor  = Color.FromArgb(50, 50, 70);
            lblTopKorisnik.Font     = new Font("Segoe UI", 10f);
            lblTopKorisnik.ForeColor= Color.FromArgb(100, 100, 120);

            // Recap
            pnlRecap.BackColor       = Color.White;
            lblOdaberiPlan.Font      = new Font("Segoe UI", 11f, FontStyle.Bold);
            lblOdaberiPlan.ForeColor = Color.FromArgb(50, 50, 70);
            lblPlanVjezbe.Font       = new Font("Segoe UI", 10f, FontStyle.Bold);
            lblPlanVjezbe.ForeColor  = Color.FromArgb(88, 86, 214);
            cmbPlanovi.Font          = new Font("Segoe UI", 10f);
            StilGrid(dgvPlanVjezbe);

            // Today
            pnlToday.BackColor       = Color.White;
            lblDanasnji.Font         = new Font("Segoe UI", 11f, FontStyle.Bold);
            lblDanasnji.ForeColor    = Color.FromArgb(50, 50, 70);
            lblUputstvo.Font         = new Font("Segoe UI", 9f);
            lblUputstvo.ForeColor    = Color.FromArgb(120, 120, 140);
            lblStatus.Font           = new Font("Segoe UI", 9f, FontStyle.Bold);
            StilGrid(dgvLog);

            // Kolone za unos kg - naglasi ih zelenom headerom
            dgvLog.Columns["cS1"].HeaderCell.Style.BackColor = Color.FromArgb(34, 139, 100);
            dgvLog.Columns["cS2"].HeaderCell.Style.BackColor = Color.FromArgb(34, 139, 100);
            dgvLog.Columns["cS3"].HeaderCell.Style.BackColor = Color.FromArgb(34, 139, 100);

            BtnStil(btnZapocniTrening, Color.FromArgb(40, 167, 69),  Color.White);
            BtnStil(btnSpremiTrening,  Color.FromArgb(88, 86, 214),  Color.White);
        }

        private void SbStil(Button b)
        {
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderSize = 0;
            b.BackColor = Color.FromArgb(88, 86, 214);
            b.ForeColor = Color.White;
            b.Font      = new Font("Segoe UI", 9f);
            b.Cursor    = Cursors.Hand;
        }

        private void BtnStil(Button b, Color back, Color fore)
        {
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderSize = 0;
            b.BackColor = back;
            b.ForeColor = fore;
            b.Font      = new Font("Segoe UI", 10f, FontStyle.Bold);
            b.Cursor    = Cursors.Hand;
        }

        private void StilGrid(DataGridView g)
        {
            g.BackgroundColor                           = Color.White;
            g.BorderStyle                               = BorderStyle.None;
            g.CellBorderStyle                           = DataGridViewCellBorderStyle.SingleHorizontal;
            g.GridColor                                 = Color.FromArgb(230, 230, 230);
            g.RowHeadersVisible                         = false;
            g.EnableHeadersVisualStyles                 = false;
            g.ColumnHeadersDefaultCellStyle.BackColor   = Color.FromArgb(88, 86, 214);
            g.ColumnHeadersDefaultCellStyle.ForeColor   = Color.White;
            g.ColumnHeadersDefaultCellStyle.Font        = new Font("Segoe UI", 9f, FontStyle.Bold);
            g.ColumnHeadersHeight                       = 36;
            g.DefaultCellStyle.Font                     = new Font("Segoe UI", 9f);
            g.DefaultCellStyle.SelectionBackColor       = Color.FromArgb(88, 86, 214);
            g.DefaultCellStyle.SelectionForeColor       = Color.White;
            g.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 249, 252);
            g.RowTemplate.Height                        = 32;
        }

        // ── Logika ───────────────────────────────────────────────────────
        private void UcitajPlanoveZaDanas()
        {
            lblTopKorisnik.Text = "Dobrodosli, " + KorisnikManager.TrenutniUsername + "!";
            cmbPlanovi.Items.Clear();
            cmbPlanovi.Items.Add(new PlanItem { PlanID = -1, Naziv = "-- Odaberi plan --" });
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                using (MySqlCommand cmd = new MySqlCommand(
                    "SELECT PlanID, Naziv FROM treningplan " +
                    "WHERE KorisnikID=@kid ORDER BY DatumKreiranja DESC", conn))
                {
                    cmd.Parameters.AddWithValue("@kid", KorisnikManager.TrenutniKorisnikID);
                    using (MySqlDataReader r = cmd.ExecuteReader())
                        while (r.Read())
                            cmbPlanovi.Items.Add(new PlanItem
                                { PlanID = r.GetInt32(0), Naziv = r.GetString(1) });
                }
            }
            catch { }
            cmbPlanovi.SelectedIndex = 0;
        }

        private void cmbPlanovi_SelectedIndexChanged(object sender, EventArgs e)
        {
            var sel = cmbPlanovi.SelectedItem as PlanItem;
            if (sel == null || sel.PlanID == -1)
            {
                dgvPlanVjezbe.Rows.Clear();
                dgvLog.Rows.Clear();
                logVjezbe.Clear();
                aktivniTreningID = -1;
                lblStatus.Text = "";
                return;
            }
            UcitajVjezbeZaPlan(sel.PlanID);
        }

        private void UcitajVjezbeZaPlan(int planID)
        {
            logVjezbe.Clear();
            dgvPlanVjezbe.Rows.Clear();
            dgvLog.Rows.Clear();
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                using (MySqlCommand cmd = new MySqlCommand(
                    "SELECT v.VjezbaID, v.Naziv, v.Tip, v.MisicnaGrupa, " +
                    "pv.BrojSetova, pv.BrojPonavljanja " +
                    "FROM planvjezba pv JOIN vjezba v ON v.VjezbaID=pv.VjezbaID " +
                    "WHERE pv.PlanID=@pid", conn))
                {
                    cmd.Parameters.AddWithValue("@pid", planID);
                    using (MySqlDataReader r = cmd.ExecuteReader())
                        while (r.Read())
                        {
                            int bs = r.IsDBNull(4) ? 3  : r.GetInt32(4);
                            int bp = r.IsDBNull(5) ? 10 : r.GetInt32(5);
                            logVjezbe.Add(new LogVjezba
                            {
                                VjezbaID        = r.GetInt32(0),
                                Naziv           = r.GetString(1),
                                PlaniraniSetovi = bs,
                                PlaniranaPonavl = bp
                            });
                            // Pregled plan (lijevo)
                            dgvPlanVjezbe.Rows.Add(
                                r.GetString(1), r.GetString(2), r.GetString(3),
                                bs + " x " + bp);
                            // Log grid (desno) - Set1, Set2, Set3 prazni za unos
                            dgvLog.Rows.Add(r.GetString(1), bs + "x" + bp,
                                            "", "", "", bp, false);
                        }
                }
            }
            catch (Exception ex) { MessageBox.Show("Greska: " + ex.Message); }

            lblUputstvo.Text = "Unesite kilazu za svaki set (Set1/Set2/Set3), ponavljanja i oznacite 'Gotovo'.";
            lblStatus.Text   = "Plan ucitan — kliknite 'Zapocni trening' kad budete spremni.";
        }

        private void btnZapocniTrening_Click(object sender, EventArgs e)
        {
            var sel = cmbPlanovi.SelectedItem as PlanItem;
            if (sel == null || sel.PlanID == -1) { MessageBox.Show("Odaberite plan!"); return; }
            if (aktivniTreningID != -1)           { MessageBox.Show("Trening je vec zapocet!"); return; }
            if (dgvLog.Rows.Count == 0)           { MessageBox.Show("Plan nema vjezbi!"); return; }

            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                using (MySqlCommand cmd = new MySqlCommand(
                    "INSERT INTO trening (KorisnikID,PlanID,Datum) " +
                    "VALUES (@kid,@pid,@d); SELECT LAST_INSERT_ID();", conn))
                {
                    cmd.Parameters.AddWithValue("@kid", KorisnikManager.TrenutniKorisnikID);
                    cmd.Parameters.AddWithValue("@pid", sel.PlanID);
                    cmd.Parameters.AddWithValue("@d",   DateTime.Now.ToString("yyyy-MM-dd"));
                    aktivniTreningID = Convert.ToInt32(cmd.ExecuteScalar());
                }
                BtnStil(btnZapocniTrening, Color.FromArgb(22, 120, 55), Color.White);
                btnZapocniTrening.Text = "✔  Trening u toku...";
                lblStatus.Text = "Trening zapocet u " + DateTime.Now.ToString("HH:mm") +
                                 " — unesite kilaze i kliknite 'Spremi trening'.";
            }
            catch (Exception ex) { MessageBox.Show("Greska: " + ex.Message); }
        }

        private void btnSpremiTrening_Click(object sender, EventArgs e)
        {
            if (aktivniTreningID == -1)
            { MessageBox.Show("Prvo kliknite 'Zapocni trening'!"); return; }

            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                {
                    for (int i = 0; i < dgvLog.Rows.Count && i < logVjezbe.Count; i++)
                    {
                        // Izracunaj max kilazu od sva 3 seta
                        double s1 = ParseDouble(dgvLog.Rows[i].Cells["cS1"].Value);
                        double s2 = ParseDouble(dgvLog.Rows[i].Cells["cS2"].Value);
                        double s3 = ParseDouble(dgvLog.Rows[i].Cells["cS3"].Value);
                        double maxKg = Math.Max(s1, Math.Max(s2, s3));

                        // Broj ponavljanja
                        int pon = 0;
                        try { pon = Convert.ToInt32(dgvLog.Rows[i].Cells["cPon"].Value); } catch { }

                        // Broj uradjenih setova (koliko setova ima kilazu > 0)
                        int uradjeniSetovi = (s1 > 0 ? 1 : 0) + (s2 > 0 ? 1 : 0) + (s3 > 0 ? 1 : 0);

                        bool gotovo = false;
                        try { gotovo = Convert.ToBoolean(dgvLog.Rows[i].Cells["cCh"].Value); } catch { }

                        using (MySqlCommand cmd = new MySqlCommand(
                            "INSERT INTO treningvjezba " +
                            "(TreningID,VjezbaID,OdradjeniSetovi,MaxTezina,Uradjeno) " +
                            "VALUES (@tid,@vid,@os,@mt,@ur)", conn))
                        {
                            cmd.Parameters.AddWithValue("@tid", aktivniTreningID);
                            cmd.Parameters.AddWithValue("@vid", logVjezbe[i].VjezbaID);
                            cmd.Parameters.AddWithValue("@os",  uradjeniSetovi > 0
                                                                    ? uradjeniSetovi
                                                                    : logVjezbe[i].PlaniraniSetovi);
                            cmd.Parameters.AddWithValue("@mt",  maxKg);
                            cmd.Parameters.AddWithValue("@ur",  gotovo ? 1 : 0);
                            cmd.ExecuteNonQuery();
                        }
                    }
                }

                MessageBox.Show("Trening uspjesno sačuvan!", "Bravo!",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
                aktivniTreningID = -1;
                BtnStil(btnZapocniTrening, Color.FromArgb(40, 167, 69), Color.White);
                btnZapocniTrening.Text = "▶  Zapocni trening";
                lblStatus.Text = "";
                UcitajPlanoveZaDanas();
                cmbPlanovi.SelectedIndex = 0;
            }
            catch (Exception ex) { MessageBox.Show("Greska: " + ex.Message); }
        }

        private double ParseDouble(object val)
        {
            if (val == null || val.ToString().Trim() == "") return 0;
            double d;
            double.TryParse(val.ToString().Replace(",", "."),
                System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture, out d);
            return d;
        }

        private void btnPlanovi_Click(object sender, EventArgs e)
        {
            using (var frm = new FrmTreningPlan())
            {
                frm.ShowDialog();
                UcitajPlanoveZaDanas();
            }
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // FrmNaslovna
            // 
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Name = "FrmNaslovna";
            this.Load += new System.EventHandler(this.FrmNaslovna_Load);
            this.ResumeLayout(false);

        }

        private void FrmNaslovna_Load(object sender, EventArgs e)
        {

        }
    }
}
