using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApplication1
{
    public class FrmNaslovna : Form
    {
        // ── Kontrole ─────────────────────────────────────────────────────
        private Panel pnlSidebar;
        private Label lblFit;
        private Button btnHome;
        private Button btnVjezbe;
        private Button btnPlanovi;
        private Button btnEvidencija;
        private Panel pnlTop;
        private Label lblTopNaslov;
        private Label lblTopKorisnik;
        private Panel pnlRecap;
        private Label lblOdaberiPlan;
        private ComboBox cmbPlanovi;
        private Label lblPlanVjezbe;
        private DataGridView dgvPlanVjezbe;
        private Panel pnlToday;
        private Label lblDanasnji;
        private Label lblUputstvo;
        private DataGridView dgvLog;
        private Button btnZapocniTrening;
        private Button btnSpremiTrening;
        private Label lblStatus;

        // ── Podaci ───────────────────────────────────────────────────────
        private int aktivniTreningID = -1;
        private List<LogVjezba> logVjezbe = new List<LogVjezba>();

        private class LogVjezba
        {
            public int VjezbaID;
            public string Naziv;
            public int PlaniraniSetovi;
            public int PlaniranaPonavl;
        }

        private class PlanItem
        {
            public int PlanID;
            public string Naziv;
            public override string ToString() { return Naziv; }
        }

        // ── Konstruktor ──────────────────────────────────────────────────
        public FrmNaslovna()
        {
            GradiForme();
            PrimijeniStil();
            UcitajPlanoveZaDanas();
        }

        // ── Gradnja forme ────────────────────────────────────────────────
        private void GradiForme()
        {
            this.SuspendLayout();
            this.Text = "FitApp";
            this.ClientSize = new Size(1168, 700);
            this.MinimumSize = new Size(1100, 700);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Font = new Font("Segoe UI", 9f);

            // ── Sidebar ──────────────────────────────────────────────────
            pnlSidebar = new Panel { Dock = DockStyle.Left, Size = new Size(200, 720) };

            lblFit = new Label
            {
                Text = "FitApp",
                Location = new Point(0, 20),
                Size = new Size(200, 34),
                TextAlign = ContentAlignment.MiddleCenter
            };

            var lblSub = new Label
            {
                Text = "Trening tracker",
                Location = new Point(0, 52),
                Size = new Size(200, 18),
                TextAlign = ContentAlignment.MiddleCenter
            };

            var pnlSep = new Panel { Location = new Point(14, 78), Size = new Size(172, 1) };

            btnHome = SbBtn("  Korisnik", 94);
            btnVjezbe = SbBtn("  Vježbe", 146);
            btnPlanovi = SbBtn("  Planovi", 198);
            btnEvidencija = SbBtn("  Evidencija", 250);

            btnHome.Click += (s, e) => { using (var f = new FrmKorisnik())   f.ShowDialog(); };
            btnVjezbe.Click += (s, e) => { using (var f = new FrmVjezbe())     f.ShowDialog(); };
            btnPlanovi.Click += btnPlanovi_Click;
            btnEvidencija.Click += (s, e) => { using (var f = new FrmEvidencija()) f.ShowDialog(); };

            pnlSidebar.Controls.AddRange(new Control[] { lblFit, lblSub, pnlSep, btnHome, btnVjezbe, btnPlanovi, btnEvidencija });

            // ── Top bar ──────────────────────────────────────────────────
            pnlTop = new Panel { Dock = DockStyle.Top, Height = 70 };
            lblTopNaslov = new Label { Text = "Početna stranica", Location = new Point(20, 14), AutoSize = true };
            lblTopKorisnik = new Label { Text = "", Location = new Point(22, 42), AutoSize = true };
            pnlTop.Controls.AddRange(new Control[] { lblTopNaslov, lblTopKorisnik });

            // ── pnlRecap — lijevo ─────────────────────────────────────────
            pnlRecap = new Panel { Location = new Point(208, 78), Size = new Size(390, 612) };

            lblOdaberiPlan = new Label { Text = "Odaberi plan za danas:", Location = new Point(12, 12), AutoSize = true };

            cmbPlanovi = new ComboBox
            {
                Location = new Point(12, 32),
                Size = new Size(364, 24),
                DropDownStyle = ComboBoxStyle.DropDownList,
                FlatStyle = FlatStyle.Flat
            };
            cmbPlanovi.SelectedIndexChanged += cmbPlanovi_SelectedIndexChanged;

            lblPlanVjezbe = new Label { Text = "Vježbe u planu:", Location = new Point(12, 66), AutoSize = true };

            dgvPlanVjezbe = new DataGridView
            {
                Location = new Point(12, 86),
                Size = new Size(364, 510),
                ReadOnly = true,
                AllowUserToAddRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoGenerateColumns = false,
                ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing,
                ColumnHeadersHeight = 34
            };
            dgvPlanVjezbe.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Naziv vježbe", Name = "cNaziv", Width = 150 });
            dgvPlanVjezbe.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Tip", Name = "cTip", Width = 68 });
            dgvPlanVjezbe.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Grupa", Name = "cGrupa", Width = 80 });
            dgvPlanVjezbe.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Set x Rep.", Name = "cSetovi", Width = 66 });

            pnlRecap.Controls.AddRange(new Control[] { lblOdaberiPlan, cmbPlanovi, lblPlanVjezbe, dgvPlanVjezbe });

            // ── pnlToday — desno ──────────────────────────────────────────
            pnlToday = new Panel { Location = new Point(610, 78), Size = new Size(580, 612) };

            lblDanasnji = new Label { Text = "Logiraj današnji trening:", Location = new Point(12, 12), AutoSize = true };

            lblUputstvo = new Label
            {
                Text = "Odaberite plan sa lijeve strane.",
                Location = new Point(12, 36),
                Size = new Size(544, 20),
                AutoSize = false
            };

            dgvLog = new DataGridView
            {
                Location = new Point(12, 62),
                Size = new Size(544, 468),
                AllowUserToAddRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoGenerateColumns = false,
                ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing,
                ColumnHeadersHeight = 34,
                ScrollBars = ScrollBars.Vertical
            };

            // Vježba — read only
            dgvLog.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Vježba", Name = "cN", Width = 118, ReadOnly = true });
            // Set 1
            dgvLog.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "S1 (kg)", Name = "cS1k", Width = 58 });
            dgvLog.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "S1 pon.", Name = "cS1p", Width = 50 });
            // Set 2
            dgvLog.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "S2 (kg)", Name = "cS2k", Width = 58 });
            dgvLog.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "S2 pon.", Name = "cS2p", Width = 50 });
            // Set 3
            dgvLog.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "S3 (kg)", Name = "cS3k", Width = 58 });
            dgvLog.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "S3 pon.", Name = "cS3p", Width = 50 });
            // Set 4 (uvijek prikazan, ali zaključan/crven ako vježba nema 4 serije)
            dgvLog.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "S4 (kg)", Name = "cS4k", Width = 58 });
            dgvLog.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "S4 pon.", Name = "cS4p", Width = 50 });
            // Gotovo
            dgvLog.Columns.Add(new DataGridViewCheckBoxColumn { HeaderText = "OK", Name = "cCh", Width = 36 });

            dgvLog.DataError += (s, ev) => ev.Cancel = true;
            // CellFormatting – zaključaj/oboji ćelije setova koji su izvan planiranog broja serija
            dgvLog.CellFormatting += dgvLog_CellFormatting;
            // Spriječi unos u zaključane S4 ćelije
            dgvLog.CellBeginEdit += dgvLog_CellBeginEdit;

            lblStatus = new Label
            {
                Text = "",
                Location = new Point(12, 538),
                Size = new Size(544, 18),
                AutoSize = false,
                ForeColor = Color.FromArgb(88, 86, 214)
            };

            btnZapocniTrening = new Button
            {
                Text = "▶  Započni trening",
                Location = new Point(7, 562),
                Size = new Size(282, 42)
            };
            btnZapocniTrening.Click += btnZapocniTrening_Click;

            btnSpremiTrening = new Button
            {
                Text = "✔  Spremi trening",
                Location = new Point(299, 562),
                Size = new Size(282, 42)
            };
            btnSpremiTrening.Click += btnSpremiTrening_Click;

            pnlToday.Controls.AddRange(new Control[] { lblDanasnji, lblUputstvo, dgvLog, lblStatus, btnZapocniTrening, btnSpremiTrening });

            // ── Forma ────────────────────────────────────────────────────
            this.Controls.Add(pnlToday);
            this.Controls.Add(pnlRecap);
            this.Controls.Add(pnlTop);
            this.Controls.Add(pnlSidebar);
            this.ResumeLayout(false);
        }

        private Button SbBtn(string txt, int top)
        {
            return new Button
            {
                Text = txt,
                Location = new Point(0, top),
                Size = new Size(200, 48),
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(20, 0, 0, 0)
            };
        }

        // ── Stil ─────────────────────────────────────────────────────────
        private void PrimijeniStil()
        {
            this.BackColor = Color.FromArgb(240, 242, 248);

            // Sidebar
            pnlSidebar.BackColor = Color.FromArgb(28, 25, 45);
            lblFit.Font = new Font("Segoe UI", 15f, FontStyle.Bold);
            lblFit.ForeColor = Color.White;
            pnlSidebar.Controls[1].ForeColor = Color.FromArgb(140, 136, 180);
            pnlSidebar.Controls[1].Font = new Font("Segoe UI", 7.5f);
            pnlSidebar.Controls[2].BackColor = Color.FromArgb(55, 52, 80);
            foreach (Control c in pnlSidebar.Controls)
                if (c is Button) SbStil((Button)c);

            // Top
            pnlTop.BackColor = Color.White;
            lblTopNaslov.Font = new Font("Segoe UI", 15f, FontStyle.Bold);
            lblTopNaslov.ForeColor = Color.FromArgb(28, 25, 45);
            lblTopKorisnik.Font = new Font("Segoe UI", 9f);
            lblTopKorisnik.ForeColor = Color.FromArgb(120, 116, 160);

            // Recap — tamna tema
            pnlRecap.BackColor = Color.FromArgb(28, 25, 45);
            lblOdaberiPlan.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
            lblOdaberiPlan.ForeColor = Color.FromArgb(180, 176, 220);
            cmbPlanovi.Font = new Font("Segoe UI", 9.5f);
            cmbPlanovi.BackColor = Color.FromArgb(50, 47, 75);
            cmbPlanovi.ForeColor = Color.White;
            lblPlanVjezbe.Font = new Font("Segoe UI", 8.5f, FontStyle.Bold);
            lblPlanVjezbe.ForeColor = Color.FromArgb(88, 86, 214);
            dgvPlanVjezbe.BackgroundColor = Color.FromArgb(28, 25, 45);
            dgvPlanVjezbe.BorderStyle = BorderStyle.None;
            dgvPlanVjezbe.GridColor = Color.FromArgb(45, 42, 68);
            dgvPlanVjezbe.RowHeadersVisible = false;
            dgvPlanVjezbe.EnableHeadersVisualStyles = false;
            dgvPlanVjezbe.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgvPlanVjezbe.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(20, 17, 35);
            dgvPlanVjezbe.ColumnHeadersDefaultCellStyle.ForeColor = Color.FromArgb(180, 176, 220);
            dgvPlanVjezbe.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 8.5f, FontStyle.Bold);
            dgvPlanVjezbe.DefaultCellStyle.BackColor = Color.FromArgb(34, 31, 53);
            dgvPlanVjezbe.DefaultCellStyle.ForeColor = Color.FromArgb(210, 207, 240);
            dgvPlanVjezbe.DefaultCellStyle.Font = new Font("Segoe UI", 9f);
            dgvPlanVjezbe.DefaultCellStyle.SelectionBackColor = Color.FromArgb(88, 86, 214);
            dgvPlanVjezbe.DefaultCellStyle.SelectionForeColor = Color.White;
            dgvPlanVjezbe.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(40, 37, 62);
            dgvPlanVjezbe.AlternatingRowsDefaultCellStyle.ForeColor = Color.FromArgb(210, 207, 240);
            dgvPlanVjezbe.RowTemplate.Height = 28;

            // Today — bijela tema
            pnlToday.BackColor = Color.White;
            pnlToday.BorderStyle = BorderStyle.FixedSingle;
            lblDanasnji.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
            lblDanasnji.ForeColor = Color.FromArgb(28, 25, 45);
            lblUputstvo.Font = new Font("Segoe UI", 8.5f);
            lblUputstvo.ForeColor = Color.FromArgb(120, 116, 160);
            lblStatus.Font = new Font("Segoe UI", 9f, FontStyle.Bold);

            StilGridBijeli(dgvLog);

            // Naglasi kg kolone zelenkastom pozadinom headera (S1–S4)
            foreach (string col in new[] { "cS1k", "cS2k", "cS3k", "cS4k" })
            {
                dgvLog.Columns[col].HeaderCell.Style.BackColor = Color.FromArgb(30, 100, 60);
                dgvLog.Columns[col].HeaderCell.Style.ForeColor = Color.White;
            }

            BtnStil(btnZapocniTrening, Color.FromArgb(34, 139, 34), Color.FromArgb(40, 160, 40));
            BtnStil(btnSpremiTrening, Color.FromArgb(88, 86, 214), Color.FromArgb(100, 98, 230));
        }

        private void SbStil(Button b)
        {
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderSize = 0;
            b.BackColor = Color.FromArgb(28, 25, 45);
            b.ForeColor = Color.FromArgb(190, 186, 225);
            b.Font = new Font("Segoe UI", 9f);
            b.Cursor = Cursors.Hand;
            b.UseVisualStyleBackColor = false;
            b.FlatAppearance.MouseOverBackColor = Color.FromArgb(55, 52, 80);
            b.FlatAppearance.MouseDownBackColor = Color.FromArgb(70, 66, 100);
            b.TextAlign = ContentAlignment.MiddleLeft;
            b.Padding = new Padding(20, 0, 0, 0);
        }

        private void BtnStil(Button b, Color bg, Color hover)
        {
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderSize = 0;
            b.BackColor = bg;
            b.ForeColor = Color.White;
            b.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold);
            b.Cursor = Cursors.Hand;
            b.FlatAppearance.MouseOverBackColor = hover;
        }

        private void StilGridBijeli(DataGridView g)
        {
            g.BackgroundColor = Color.White;
            g.BorderStyle = BorderStyle.None;
            g.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            g.GridColor = Color.FromArgb(230, 230, 235);
            g.RowHeadersVisible = false;
            g.EnableHeadersVisualStyles = false;
            g.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(28, 25, 45);
            g.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            g.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 8.5f, FontStyle.Bold);
            g.DefaultCellStyle.Font = new Font("Segoe UI", 9f);
            g.DefaultCellStyle.SelectionBackColor = Color.FromArgb(88, 86, 214);
            g.DefaultCellStyle.SelectionForeColor = Color.White;
            g.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 248, 252);
            g.RowTemplate.Height = 32;
        }

        // ── dgvLog eventi ────────────────────────────────────────────────

        /// <summary>
        /// Vraća true ako je data kolona (po imenu) izvan planiranog broja setova za taj red.
        /// Npr. ako vježba ima 3 seta, kolone cS4k i cS4p su "zaključane".
        /// </summary>
        private bool JeZakljucanaKolona(int rowIndex, string colName)
        {
            if (rowIndex < 0 || rowIndex >= logVjezbe.Count) return false;
            int planirani = logVjezbe[rowIndex].PlaniraniSetovi;
            // S4 kolone su aktivne samo ako je planirani >= 4
            if ((colName == "cS4k" || colName == "cS4p") && planirani < 4) return true;
            // S3 kolone su aktivne samo ako je planirani >= 3
            if ((colName == "cS3k" || colName == "cS3p") && planirani < 3) return true;
            // S2 kolone su aktivne samo ako je planirani >= 2
            if ((colName == "cS2k" || colName == "cS2p") && planirani < 2) return true;
            return false;
        }

        private void dgvLog_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.RowIndex < 0 || e.RowIndex >= logVjezbe.Count) return;
            string colName = dgvLog.Columns[e.ColumnIndex].Name;

            if (JeZakljucanaKolona(e.RowIndex, colName))
            {
                // Crvena pozadina + sivi tekst + simbol /
                e.CellStyle.BackColor = Color.FromArgb(255, 210, 210);
                e.CellStyle.ForeColor = Color.FromArgb(160, 40, 40);
                e.CellStyle.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
                e.Value = "/";
                e.FormattingApplied = true;
            }
        }

        private void dgvLog_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (e.RowIndex < 0 || e.RowIndex >= logVjezbe.Count) return;
            string colName = dgvLog.Columns[e.ColumnIndex].Name;
            if (JeZakljucanaKolona(e.RowIndex, colName))
                e.Cancel = true; // Blokira editovanje zaključanih ćelija
        }

        // ── Logika ───────────────────────────────────────────────────────
        private void UcitajPlanoveZaDanas()
        {
            lblTopKorisnik.Text = "Dobrodošli, " + KorisnikManager.TrenutniUsername + "!";
            cmbPlanovi.Items.Clear();
            cmbPlanovi.Items.Add(new PlanItem { PlanID = -1, Naziv = "-- Odaberi plan --" });
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                using (MySqlCommand cmd = new MySqlCommand(
                    "SELECT PlanID, Naziv FROM treningplan " +
                    "WHERE KorisnikID=@kid ORDER BY DatumKreiranja DESC", conn))
                {
                    cmd.Parameters.AddWithValue("@kid", KorisnikManager.TrenutniKorisnikID);
                    using (MySqlDataReader r = cmd.ExecuteReader())
                        while (r.Read())
                            cmbPlanovi.Items.Add(new PlanItem { PlanID = r.GetInt32(0), Naziv = r.GetString(1) });
                }
            }
            catch { }
            cmbPlanovi.SelectedIndex = 0;
        }

        private void cmbPlanovi_SelectedIndexChanged(object sender, EventArgs e)
        {
            var sel = cmbPlanovi.SelectedItem as PlanItem;
            if (sel == null || sel.PlanID == -1)
            {
                dgvPlanVjezbe.Rows.Clear();
                dgvLog.Rows.Clear();
                logVjezbe.Clear();
                aktivniTreningID = -1;
                lblStatus.Text = "";
                lblUputstvo.Text = "Odaberite plan sa lijeve strane.";
                return;
            }
            UcitajVjezbeZaPlan(sel.PlanID);
        }

        private void UcitajVjezbeZaPlan(int planID)
        {
            logVjezbe.Clear();
            dgvPlanVjezbe.Rows.Clear();
            dgvLog.Rows.Clear();
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                using (MySqlCommand cmd = new MySqlCommand(
                    "SELECT v.VjezbaID, v.Naziv, v.Tip, v.MisicnaGrupa, " +
                    "pv.BrojSetova, pv.BrojPonavljanja " +
                    "FROM planvjezba pv JOIN vjezba v ON v.VjezbaID=pv.VjezbaID " +
                    "WHERE pv.PlanID=@pid", conn))
                {
                    cmd.Parameters.AddWithValue("@pid", planID);
                    using (MySqlDataReader r = cmd.ExecuteReader())
                        while (r.Read())
                        {
                            int bs = r.IsDBNull(4) ? 3 : r.GetInt32(4);
                            int bp = r.IsDBNull(5) ? 10 : r.GetInt32(5);
                            logVjezbe.Add(new LogVjezba
                            {
                                VjezbaID = r.GetInt32(0),
                                Naziv = r.GetString(1),
                                PlaniraniSetovi = bs,
                                PlaniranaPonavl = bp
                            });

                            // Lijevi panel
                            dgvPlanVjezbe.Rows.Add(r.GetString(1), r.GetString(2),
                                                   r.GetString(3), bs + " x " + bp);

                            // Desni panel — popuni ponavljanja za planirane setove
                            int idx = dgvLog.Rows.Add();
                            var row = dgvLog.Rows[idx];
                            row.Cells["cN"].Value = r.GetString(1);

                            // Postavi ponavljanja samo za planirane setove;
                            // preostale ćelije ostaju prazne (CellFormatting će ih prikazati kao /)
                            if (bs >= 1) row.Cells["cS1p"].Value = bp;
                            if (bs >= 2) row.Cells["cS2p"].Value = bp;
                            if (bs >= 3) row.Cells["cS3p"].Value = bp;
                            if (bs >= 4) row.Cells["cS4p"].Value = bp;

                            row.Cells["cCh"].Value = false;
                            row.Tag = logVjezbe[logVjezbe.Count - 1].VjezbaID;
                        }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška pri učitavanju vježbi: " + ex.Message, "Greška",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            lblPlanVjezbe.Text = "Vježbe u planu: " + dgvPlanVjezbe.Rows.Count;
            lblUputstvo.Text = "Unesite kilažu i ponavljanja za svaki set.";
            lblStatus.Text = "Plan učitan — kliknite 'Započni trening'.";
        }

        private void btnZapocniTrening_Click(object sender, EventArgs e)
        {
            var sel = cmbPlanovi.SelectedItem as PlanItem;
            if (sel == null || sel.PlanID == -1)
            {
                MessageBox.Show("Odaberite plan!", "Upozorenje",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (aktivniTreningID != -1)
            {
                MessageBox.Show("Trening je već započet!", "Upozorenje",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (dgvLog.Rows.Count == 0)
            {
                MessageBox.Show("Plan nema vježbi!", "Upozorenje",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                using (MySqlCommand cmd = new MySqlCommand(
                    "INSERT INTO trening (KorisnikID,PlanID,Datum) " +
                    "VALUES (@kid,@pid,@d); SELECT LAST_INSERT_ID();", conn))
                {
                    cmd.Parameters.AddWithValue("@kid", KorisnikManager.TrenutniKorisnikID);
                    cmd.Parameters.AddWithValue("@pid", sel.PlanID);
                    cmd.Parameters.AddWithValue("@d", DateTime.Now.ToString("yyyy-MM-dd"));
                    aktivniTreningID = Convert.ToInt32(cmd.ExecuteScalar());
                }
                BtnStil(btnZapocniTrening, Color.FromArgb(22, 120, 55), Color.FromArgb(30, 140, 65));
                btnZapocniTrening.Text = "✔  Trening u toku...";
                lblStatus.Text = "Trening započet u " + DateTime.Now.ToString("HH:mm") +
                                 "  —  unesite kilažu i kliknite 'Spremi trening'.";
                lblStatus.ForeColor = Color.FromArgb(40, 160, 80);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška pri pokretanju treninga: " + ex.Message, "Greška",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSpremiTrening_Click(object sender, EventArgs e)
        {
            if (aktivniTreningID == -1)
            {
                MessageBox.Show("Prvo kliknite 'Započni trening'!", "Upozorenje",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                {
                    for (int i = 0; i < dgvLog.Rows.Count && i < logVjezbe.Count; i++)
                    {
                        var row = dgvLog.Rows[i];
                        int planirani = logVjezbe[i].PlaniraniSetovi;

                        double s1k = ParseDouble(row.Cells["cS1k"].Value);
                        double s2k = planirani >= 2 ? ParseDouble(row.Cells["cS2k"].Value) : 0;
                        double s3k = planirani >= 3 ? ParseDouble(row.Cells["cS3k"].Value) : 0;
                        double s4k = planirani >= 4 ? ParseDouble(row.Cells["cS4k"].Value) : 0;
                        double maxKg = Math.Max(s1k, Math.Max(s2k, Math.Max(s3k, s4k)));

                        int s1p = 0, s2p = 0, s3p = 0, s4p = 0;
                        try { s1p = Convert.ToInt32(row.Cells["cS1p"].Value); }
                        catch { }
                        if (planirani >= 2) try { s2p = Convert.ToInt32(row.Cells["cS2p"].Value); }
                            catch { }
                        if (planirani >= 3) try { s3p = Convert.ToInt32(row.Cells["cS3p"].Value); }
                            catch { }
                        if (planirani >= 4) try { s4p = Convert.ToInt32(row.Cells["cS4p"].Value); }
                            catch { }

                        // Broj odrađenih setova = setovi gdje je kg > 0
                        int setCount = (s1k > 0 ? 1 : 0) + (s2k > 0 ? 1 : 0)
                                     + (s3k > 0 ? 1 : 0) + (s4k > 0 ? 1 : 0);
                        if (setCount == 0) setCount = planirani;

                        int ponSum = s1p + s2p + s3p + s4p;
                        int ponCnt = (s1p > 0 ? 1 : 0) + (s2p > 0 ? 1 : 0)
                                   + (s3p > 0 ? 1 : 0) + (s4p > 0 ? 1 : 0);
                        int ponAvg = ponCnt > 0 ? ponSum / ponCnt : logVjezbe[i].PlaniranaPonavl;

                        bool gotovo = false;
                        try { gotovo = Convert.ToBoolean(row.Cells["cCh"].Value); }
                        catch { }

                        using (MySqlCommand cmd = new MySqlCommand(
                            "INSERT INTO treningvjezba " +
                            "(TreningID,VjezbaID,OdradjeniSetovi,OdradjenaPonavlajnja,MaxTezina,Uradjeno) " +
                            "VALUES (@tid,@vid,@os,@pon,@mt,@ur)", conn))
                        {
                            cmd.Parameters.AddWithValue("@tid", aktivniTreningID);
                            cmd.Parameters.AddWithValue("@vid", logVjezbe[i].VjezbaID);
                            cmd.Parameters.AddWithValue("@os", setCount);
                            cmd.Parameters.AddWithValue("@pon", ponAvg);
                            cmd.Parameters.AddWithValue("@mt", maxKg > 0 ? (object)maxKg : DBNull.Value);
                            cmd.Parameters.AddWithValue("@ur", gotovo ? 1 : 0);
                            cmd.ExecuteNonQuery();
                        }
                    }
                }
                MessageBox.Show("Trening uspješno sačuvan!", "Bravo!",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                aktivniTreningID = -1;
                lblStatus.ForeColor = Color.FromArgb(88, 86, 214);
                BtnStil(btnZapocniTrening, Color.FromArgb(34, 139, 34), Color.FromArgb(40, 160, 40));
                btnZapocniTrening.Text = "▶  Započni trening";
                lblStatus.Text = "";
                UcitajPlanoveZaDanas();
                cmbPlanovi.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška pri spremanju treninga: " + ex.Message, "Greška",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private double ParseDouble(object val)
        {
            if (val == null || val.ToString().Trim() == "") return 0;
            double d;
            double.TryParse(val.ToString().Replace(",", "."),
                System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture, out d);
            return d;
        }

        private void btnPlanovi_Click(object sender, EventArgs e)
        {
            using (var frm = new FrmTreningPlan()) { frm.ShowDialog(); UcitajPlanoveZaDanas(); }
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            this.ClientSize = new System.Drawing.Size(1200, 720);
            this.Name = "FrmNaslovna";
            this.ResumeLayout(false);
        }

        private void FrmNaslovna_Load(object sender, EventArgs e) { }
    }
}