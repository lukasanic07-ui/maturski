using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApplication1
{
    public class FrmNaslovna : Form
    {
        // ── Kontrole ─────────────────────────────────────────────────────
        private Panel pnlSidebar;
        private Label lblFit;
        private Button btnHome;
        private Button btnVjezbe;
        private Button btnPlanovi;
        private Button btnEvidencija;
        private Panel pnlTop;
        private Label lblTopNaslov;
        private Label lblTopKorisnik;
        private Panel pnlRecap;
        private Label lblOdaberiPlan;
        private ComboBox cmbPlanovi;
        private Label lblPlanVjezbe;
        private DataGridView dgvPlanVjezbe;
        private Panel pnlToday;
        private Label lblDanasnji;
        private Label lblUputstvo;
        private DataGridView dgvLog;
        private Button btnZapocniTrening;
        private Button btnSpremiTrening;
        private Label lblStatus;

        // ── Podaci ───────────────────────────────────────────────────────
        private int aktivniTreningID = -1;
        private List<LogVjezba> logVjezbe = new List<LogVjezba>();

        private class LogVjezba
        {
            public int VjezbaID;
            public string Naziv;
            public int PlaniraniSetovi;
            public int PlaniranaPonavl;
        }

        private class PlanItem
        {
            public int PlanID;
            public string Naziv;
            public override string ToString() { return Naziv; }
        }

        // ── Konstruktor ──────────────────────────────────────────────────
        public FrmNaslovna()
        {
            GradiForme();
            PrimijeniStil();
            UcitajPlanoveZaDanas();
        }

        // ── Gradnja forme ────────────────────────────────────────────────
        private void GradiForme()
        {
            this.SuspendLayout();
            this.Text = "FitApp";
            this.ClientSize = new Size(1125, 700);
            this.MinimumSize = new Size(1100, 700);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Font = new Font("Segoe UI", 9f);

            // ── Sidebar ──────────────────────────────────────────────────
            pnlSidebar = new Panel { Dock = DockStyle.Left, Size = new Size(200, 720) };

            lblFit = new Label
            {
                Text = "FitApp",
                Location = new Point(0, 20),
                Size = new Size(200, 34),
                TextAlign = ContentAlignment.MiddleCenter
            };

            var lblSub = new Label
            {
                Text = "Trening tracker",
                Location = new Point(0, 52),
                Size = new Size(200, 18),
                TextAlign = ContentAlignment.MiddleCenter
            };

            var pnlSep = new Panel { Location = new Point(14, 78), Size = new Size(172, 1) };

            btnHome = SbBtn("  Korisnik", 94);
            btnVjezbe = SbBtn("  Vjezbe", 146);
            btnPlanovi = SbBtn("  Planovi", 198);
            btnEvidencija = SbBtn("  Evidencija", 250);

            btnHome.Click += (s, e) => { using (var f = new FrmKorisnik())   f.ShowDialog(); };
            btnVjezbe.Click += (s, e) => { using (var f = new FrmVjezbe())     f.ShowDialog(); };
            btnPlanovi.Click += btnPlanovi_Click;
            btnEvidencija.Click += (s, e) => { using (var f = new FrmEvidencija()) f.ShowDialog(); };

            pnlSidebar.Controls.AddRange(new Control[] { lblFit, lblSub, pnlSep, btnHome, btnVjezbe, btnPlanovi, btnEvidencija });

            // ── Top bar ──────────────────────────────────────────────────
            pnlTop = new Panel { Dock = DockStyle.Top, Height = 70 };
            lblTopNaslov = new Label { Text = "Pocetna stranica", Location = new Point(20, 14), AutoSize = true };
            lblTopKorisnik = new Label { Text = "", Location = new Point(22, 42), AutoSize = true };
            pnlTop.Controls.AddRange(new Control[] { lblTopNaslov, lblTopKorisnik });

            // ── pnlRecap — lijevo ─────────────────────────────────────────
            pnlRecap = new Panel { Location = new Point(208, 78), Size = new Size(390, 612) };

            lblOdaberiPlan = new Label { Text = "Odaberi plan za danas:", Location = new Point(12, 12), AutoSize = true };

            cmbPlanovi = new ComboBox
            {
                Location = new Point(12, 32),
                Size = new Size(364, 24),
                DropDownStyle = ComboBoxStyle.DropDownList,
                FlatStyle = FlatStyle.Flat
            };
            cmbPlanovi.SelectedIndexChanged += cmbPlanovi_SelectedIndexChanged;

            lblPlanVjezbe = new Label { Text = "Vjezbe u planu:", Location = new Point(12, 66), AutoSize = true };

            dgvPlanVjezbe = new DataGridView
            {
                Location = new Point(12, 86),
                Size = new Size(364, 510),
                ReadOnly = true,
                AllowUserToAddRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoGenerateColumns = false,
                ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing,
                ColumnHeadersHeight = 34
            };
            dgvPlanVjezbe.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Naziv vjezbe", Name = "cNaziv", Width = 150 });
            dgvPlanVjezbe.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Tip", Name = "cTip", Width = 68 });
            dgvPlanVjezbe.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Grupa", Name = "cGrupa", Width = 80 });
            dgvPlanVjezbe.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Set x Rep.", Name = "cSetovi", Width = 66 });

            pnlRecap.Controls.AddRange(new Control[] { lblOdaberiPlan, cmbPlanovi, lblPlanVjezbe, dgvPlanVjezbe });

            // ── pnlToday — desno ──────────────────────────────────────────
            // Kolone: Vjezba(120) | S1kg(62) | S1p(52) | S2kg(62) | S2p(52) | S3kg(62) | S3p(52) | OK(40)
            // Ukupno: 120+62+52+62+52+62+52+40 = 502 + scrollbar(18) = 520 → grid 534px
            pnlToday = new Panel { Location = new Point(610, 78), Size = new Size(570, 612) };

            lblDanasnji = new Label { Text = "Loguj danasnji trening:", Location = new Point(12, 12), AutoSize = true };

            lblUputstvo = new Label
            {
                Text = "Odaberite plan sa lijeve strane.",
                Location = new Point(12, 36),
                Size = new Size(544, 20),
                AutoSize = false
            };

            dgvLog = new DataGridView
            {
                Location = new Point(12, 62),
                Size = new Size(544, 468),
                AllowUserToAddRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoGenerateColumns = false,
                ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing,
                ColumnHeadersHeight = 34,
                ScrollBars = ScrollBars.Vertical
            };

            // Vjezba — read only
            dgvLog.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Vjezba", Name = "cN", Width = 118, ReadOnly = true });
            // Set 1
            dgvLog.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "S1 (kg)", Name = "cS1k", Width = 62 });
            dgvLog.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "S1 pon.", Name = "cS1p", Width = 52 });
            // Set 2
            dgvLog.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "S2 (kg)", Name = "cS2k", Width = 62 });
            dgvLog.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "S2 pon.", Name = "cS2p", Width = 52 });
            // Set 3
            dgvLog.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "S3 (kg)", Name = "cS3k", Width = 62 });
            dgvLog.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "S3 pon.", Name = "cS3p", Width = 52 });
            // Gotovo
            dgvLog.Columns.Add(new DataGridViewCheckBoxColumn { HeaderText = "OK", Name = "cCh", Width = 40 });

            dgvLog.DataError += (s, ev) => ev.Cancel = true;

            lblStatus = new Label
            {
                Text = "",
                Location = new Point(12, 538),
                Size = new Size(544, 18),
                AutoSize = false,
                ForeColor = Color.FromArgb(88, 86, 214)
            };

            // Buttoni — svaki zauzima polovinu širine grida
            btnZapocniTrening = new Button
            {
                Text = "▶  Zapocni trening",
                Location = new Point(7, 562),
                Size = new Size(242, 42)
            };
            btnZapocniTrening.Click += btnZapocniTrening_Click;

            btnSpremiTrening = new Button
            {
                Text = "✔  Spremi trening",
                Location = new Point(259, 562),
                Size = new Size(242, 42)
            };
            btnSpremiTrening.Click += btnSpremiTrening_Click;

            pnlToday.Controls.AddRange(new Control[] { lblDanasnji, lblUputstvo, dgvLog, lblStatus, btnZapocniTrening, btnSpremiTrening });

            // ── Forma ────────────────────────────────────────────────────
            this.Controls.Add(pnlToday);
            this.Controls.Add(pnlRecap);
            this.Controls.Add(pnlTop);
            this.Controls.Add(pnlSidebar);
            this.ResumeLayout(false);
        }

        private Button SbBtn(string txt, int top)
        {
            return new Button
            {
                Text = txt,
                Location = new Point(0, top),
                Size = new Size(200, 48),
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(20, 0, 0, 0)
            };
        }

        // ── Stil ─────────────────────────────────────────────────────────
        private void PrimijeniStil()
        {
            this.BackColor = Color.FromArgb(240, 242, 248);

            // Sidebar
            pnlSidebar.BackColor = Color.FromArgb(28, 25, 45);
            lblFit.Font = new Font("Segoe UI", 15f, FontStyle.Bold);
            lblFit.ForeColor = Color.White;
            pnlSidebar.Controls[1].ForeColor = Color.FromArgb(140, 136, 180);
            pnlSidebar.Controls[1].Font = new Font("Segoe UI", 7.5f);
            pnlSidebar.Controls[2].BackColor = Color.FromArgb(55, 52, 80);
            foreach (Control c in pnlSidebar.Controls)
                if (c is Button) SbStil((Button)c);

            // Top
            pnlTop.BackColor = Color.White;
            lblTopNaslov.Font = new Font("Segoe UI", 15f, FontStyle.Bold);
            lblTopNaslov.ForeColor = Color.FromArgb(28, 25, 45);
            lblTopKorisnik.Font = new Font("Segoe UI", 9f);
            lblTopKorisnik.ForeColor = Color.FromArgb(120, 116, 160);

            // Recap — tamna tema
            pnlRecap.BackColor = Color.FromArgb(28, 25, 45);
            lblOdaberiPlan.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
            lblOdaberiPlan.ForeColor = Color.FromArgb(180, 176, 220);
            cmbPlanovi.Font = new Font("Segoe UI", 9.5f);
            cmbPlanovi.BackColor = Color.FromArgb(50, 47, 75);
            cmbPlanovi.ForeColor = Color.White;
            lblPlanVjezbe.Font = new Font("Segoe UI", 8.5f, FontStyle.Bold);
            lblPlanVjezbe.ForeColor = Color.FromArgb(88, 86, 214);
            dgvPlanVjezbe.BackgroundColor = Color.FromArgb(28, 25, 45);
            dgvPlanVjezbe.BorderStyle = BorderStyle.None;
            dgvPlanVjezbe.GridColor = Color.FromArgb(45, 42, 68);
            dgvPlanVjezbe.RowHeadersVisible = false;
            dgvPlanVjezbe.EnableHeadersVisualStyles = false;
            dgvPlanVjezbe.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgvPlanVjezbe.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(20, 17, 35);
            dgvPlanVjezbe.ColumnHeadersDefaultCellStyle.ForeColor = Color.FromArgb(180, 176, 220);
            dgvPlanVjezbe.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 8.5f, FontStyle.Bold);
            dgvPlanVjezbe.DefaultCellStyle.BackColor = Color.FromArgb(34, 31, 53);
            dgvPlanVjezbe.DefaultCellStyle.ForeColor = Color.FromArgb(210, 207, 240);
            dgvPlanVjezbe.DefaultCellStyle.Font = new Font("Segoe UI", 9f);
            dgvPlanVjezbe.DefaultCellStyle.SelectionBackColor = Color.FromArgb(88, 86, 214);
            dgvPlanVjezbe.DefaultCellStyle.SelectionForeColor = Color.White;
            dgvPlanVjezbe.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(40, 37, 62);
            dgvPlanVjezbe.AlternatingRowsDefaultCellStyle.ForeColor = Color.FromArgb(210, 207, 240);
            dgvPlanVjezbe.RowTemplate.Height = 28;

            // Today — bijela tema
            pnlToday.BackColor = Color.White;
            pnlToday.BorderStyle = BorderStyle.FixedSingle;
            lblDanasnji.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
            lblDanasnji.ForeColor = Color.FromArgb(28, 25, 45);
            lblUputstvo.Font = new Font("Segoe UI", 8.5f);
            lblUputstvo.ForeColor = Color.FromArgb(120, 116, 160);
            lblStatus.Font = new Font("Segoe UI", 9f, FontStyle.Bold);

            StilGridBijeli(dgvLog);

            // Naglasi kg kolone zelenkastom pozadinom headera
            dgvLog.Columns["cS1k"].HeaderCell.Style.BackColor = Color.FromArgb(30, 100, 60);
            dgvLog.Columns["cS2k"].HeaderCell.Style.BackColor = Color.FromArgb(30, 100, 60);
            dgvLog.Columns["cS3k"].HeaderCell.Style.BackColor = Color.FromArgb(30, 100, 60);
            dgvLog.Columns["cS1k"].HeaderCell.Style.ForeColor = Color.White;
            dgvLog.Columns["cS2k"].HeaderCell.Style.ForeColor = Color.White;
            dgvLog.Columns["cS3k"].HeaderCell.Style.ForeColor = Color.White;

            BtnStil(btnZapocniTrening, Color.FromArgb(34, 139, 34), Color.FromArgb(40, 160, 40));
            BtnStil(btnSpremiTrening, Color.FromArgb(88, 86, 214), Color.FromArgb(100, 98, 230));
        }

        private void SbStil(Button b)
        {
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderSize = 0;
            b.BackColor = Color.FromArgb(28, 25, 45);
            b.ForeColor = Color.FromArgb(190, 186, 225);
            b.Font = new Font("Segoe UI", 9f);
            b.Cursor = Cursors.Hand;
            b.UseVisualStyleBackColor = false;
            b.FlatAppearance.MouseOverBackColor = Color.FromArgb(55, 52, 80);
            b.FlatAppearance.MouseDownBackColor = Color.FromArgb(70, 66, 100);
            b.TextAlign = ContentAlignment.MiddleLeft;
            b.Padding = new Padding(20, 0, 0, 0);
        }

        private void BtnStil(Button b, Color bg, Color hover)
        {
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderSize = 0;
            b.BackColor = bg;
            b.ForeColor = Color.White;
            b.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold);
            b.Cursor = Cursors.Hand;
            b.FlatAppearance.MouseOverBackColor = hover;
        }

        private void StilGridBijeli(DataGridView g)
        {
            g.BackgroundColor = Color.White;
            g.BorderStyle = BorderStyle.None;
            g.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            g.GridColor = Color.FromArgb(230, 230, 235);
            g.RowHeadersVisible = false;
            g.EnableHeadersVisualStyles = false;
            g.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(28, 25, 45);
            g.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            g.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 8.5f, FontStyle.Bold);
            g.DefaultCellStyle.Font = new Font("Segoe UI", 9f);
            g.DefaultCellStyle.SelectionBackColor = Color.FromArgb(88, 86, 214);
            g.DefaultCellStyle.SelectionForeColor = Color.White;
            g.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 248, 252);
            g.RowTemplate.Height = 32;
        }

        // ── Logika ───────────────────────────────────────────────────────
        private void UcitajPlanoveZaDanas()
        {
            lblTopKorisnik.Text = "Dobrodosli, " + KorisnikManager.TrenutniUsername + "!";
            cmbPlanovi.Items.Clear();
            cmbPlanovi.Items.Add(new PlanItem { PlanID = -1, Naziv = "-- Odaberi plan --" });
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                using (MySqlCommand cmd = new MySqlCommand(
                    "SELECT PlanID, Naziv FROM treningplan " +
                    "WHERE KorisnikID=@kid ORDER BY DatumKreiranja DESC", conn))
                {
                    cmd.Parameters.AddWithValue("@kid", KorisnikManager.TrenutniKorisnikID);
                    using (MySqlDataReader r = cmd.ExecuteReader())
                        while (r.Read())
                            cmbPlanovi.Items.Add(new PlanItem { PlanID = r.GetInt32(0), Naziv = r.GetString(1) });
                }
            }
            catch { }
            cmbPlanovi.SelectedIndex = 0;
        }

        private void cmbPlanovi_SelectedIndexChanged(object sender, EventArgs e)
        {
            var sel = cmbPlanovi.SelectedItem as PlanItem;
            if (sel == null || sel.PlanID == -1)
            {
                dgvPlanVjezbe.Rows.Clear();
                dgvLog.Rows.Clear();
                logVjezbe.Clear();
                aktivniTreningID = -1;
                lblStatus.Text = "";
                lblUputstvo.Text = "Odaberite plan sa lijeve strane.";
                return;
            }
            UcitajVjezbeZaPlan(sel.PlanID);
        }

        private void UcitajVjezbeZaPlan(int planID)
        {
            logVjezbe.Clear();
            dgvPlanVjezbe.Rows.Clear();
            dgvLog.Rows.Clear();
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                using (MySqlCommand cmd = new MySqlCommand(
                    "SELECT v.VjezbaID, v.Naziv, v.Tip, v.MisicnaGrupa, " +
                    "pv.BrojSetova, pv.BrojPonavljanja " +
                    "FROM planvjezba pv JOIN vjezba v ON v.VjezbaID=pv.VjezbaID " +
                    "WHERE pv.PlanID=@pid", conn))
                {
                    cmd.Parameters.AddWithValue("@pid", planID);
                    using (MySqlDataReader r = cmd.ExecuteReader())
                        while (r.Read())
                        {
                            int bs = r.IsDBNull(4) ? 3 : r.GetInt32(4);
                            int bp = r.IsDBNull(5) ? 10 : r.GetInt32(5);
                            logVjezbe.Add(new LogVjezba
                            {
                                VjezbaID = r.GetInt32(0),
                                Naziv = r.GetString(1),
                                PlaniraniSetovi = bs,
                                PlaniranaPonavl = bp
                            });

                            // Lijevi panel
                            dgvPlanVjezbe.Rows.Add(r.GetString(1), r.GetString(2),
                                                   r.GetString(3), bs + " x " + bp);

                            // Desni panel — dodaj red i postavi vrijednosti po imenu
                            int idx = dgvLog.Rows.Add();
                            var row = dgvLog.Rows[idx];
                            row.Cells["cN"].Value = r.GetString(1);
                            // Ponavljanja prepopulisana planiranim brojem
                            row.Cells["cS1p"].Value = bp;
                            row.Cells["cS2p"].Value = bp;
                            row.Cells["cS3p"].Value = bp;
                            row.Cells["cCh"].Value = false;
                            row.Tag = logVjezbe[logVjezbe.Count - 1].VjezbaID;
                        }
                }
            }
            catch (Exception ex) { MessageBox.Show("Greska: " + ex.Message); }

            lblPlanVjezbe.Text = "Vjezbe u planu: " + dgvPlanVjezbe.Rows.Count;
            lblUputstvo.Text = "Unesite kilazu i ponavljanja za svaki set.";
            lblStatus.Text = "Plan ucitan — kliknite 'Zapocni trening'.";
        }

        private void btnZapocniTrening_Click(object sender, EventArgs e)
        {
            var sel = cmbPlanovi.SelectedItem as PlanItem;
            if (sel == null || sel.PlanID == -1) { MessageBox.Show("Odaberite plan!"); return; }
            if (aktivniTreningID != -1) { MessageBox.Show("Trening je vec zapocet!"); return; }
            if (dgvLog.Rows.Count == 0) { MessageBox.Show("Plan nema vjezbi!"); return; }

            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                using (MySqlCommand cmd = new MySqlCommand(
                    "INSERT INTO trening (KorisnikID,PlanID,Datum) " +
                    "VALUES (@kid,@pid,@d); SELECT LAST_INSERT_ID();", conn))
                {
                    cmd.Parameters.AddWithValue("@kid", KorisnikManager.TrenutniKorisnikID);
                    cmd.Parameters.AddWithValue("@pid", sel.PlanID);
                    cmd.Parameters.AddWithValue("@d", DateTime.Now.ToString("yyyy-MM-dd"));
                    aktivniTreningID = Convert.ToInt32(cmd.ExecuteScalar());
                }
                BtnStil(btnZapocniTrening, Color.FromArgb(22, 120, 55), Color.FromArgb(30, 140, 65));
                btnZapocniTrening.Text = "✔  Trening u toku...";
                lblStatus.Text = "Trening zapocet u " + DateTime.Now.ToString("HH:mm") +
                                          "  —  unesite kilaze i kliknite 'Spremi trening'.";
                lblStatus.ForeColor = Color.FromArgb(40, 160, 80);
            }
            catch (Exception ex) { MessageBox.Show("Greska: " + ex.Message); }
        }

        private void btnSpremiTrening_Click(object sender, EventArgs e)
        {
            if (aktivniTreningID == -1)
            { MessageBox.Show("Prvo kliknite 'Zapocni trening'!"); return; }

            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                {
                    for (int i = 0; i < dgvLog.Rows.Count && i < logVjezbe.Count; i++)
                    {
                        var row = dgvLog.Rows[i];

                        double s1k = ParseDouble(row.Cells["cS1k"].Value);
                        double s2k = ParseDouble(row.Cells["cS2k"].Value);
                        double s3k = ParseDouble(row.Cells["cS3k"].Value);
                        double maxKg = Math.Max(s1k, Math.Max(s2k, s3k));

                        int s1p = 0, s2p = 0, s3p = 0;
                        try { s1p = Convert.ToInt32(row.Cells["cS1p"].Value); }
                        catch { }
                        try { s2p = Convert.ToInt32(row.Cells["cS2p"].Value); }
                        catch { }
                        try { s3p = Convert.ToInt32(row.Cells["cS3p"].Value); }
                        catch { }

                        int setCount = (s1k > 0 ? 1 : 0) + (s2k > 0 ? 1 : 0) + (s3k > 0 ? 1 : 0);
                        if (setCount == 0) setCount = logVjezbe[i].PlaniraniSetovi;

                        int ponSum = (s1p > 0 ? s1p : 0) + (s2p > 0 ? s2p : 0) + (s3p > 0 ? s3p : 0);
                        int ponCnt = (s1p > 0 ? 1 : 0) + (s2p > 0 ? 1 : 0) + (s3p > 0 ? 1 : 0);
                        int ponAvg = ponCnt > 0 ? ponSum / ponCnt : logVjezbe[i].PlaniranaPonavl;

                        bool gotovo = false;
                        try { gotovo = Convert.ToBoolean(row.Cells["cCh"].Value); }
                        catch { }

                        using (MySqlCommand cmd = new MySqlCommand(
                            "INSERT INTO treningvjezba " +
                            "(TreningID,VjezbaID,OdradjeniSetovi,OdradjenaPonavlajnja,MaxTezina,Uradjeno) " +
                            "VALUES (@tid,@vid,@os,@pon,@mt,@ur)", conn))
                        {
                            cmd.Parameters.AddWithValue("@tid", aktivniTreningID);
                            cmd.Parameters.AddWithValue("@vid", logVjezbe[i].VjezbaID);
                            cmd.Parameters.AddWithValue("@os", setCount);
                            cmd.Parameters.AddWithValue("@pon", ponAvg);
                            cmd.Parameters.AddWithValue("@mt", maxKg > 0 ? (object)maxKg : DBNull.Value);
                            cmd.Parameters.AddWithValue("@ur", gotovo ? 1 : 0);
                            cmd.ExecuteNonQuery();
                        }
                    }
                }
                MessageBox.Show("Trening uspjesno sacuvan!", "Bravo!",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
                aktivniTreningID = -1;
                lblStatus.ForeColor = Color.FromArgb(88, 86, 214);
                BtnStil(btnZapocniTrening, Color.FromArgb(34, 139, 34), Color.FromArgb(40, 160, 40));
                btnZapocniTrening.Text = "▶  Zapocni trening";
                lblStatus.Text = "";
                UcitajPlanoveZaDanas();
                cmbPlanovi.SelectedIndex = 0;
            }
            catch (Exception ex) { MessageBox.Show("Greska: " + ex.Message); }
        }

        private double ParseDouble(object val)
        {
            if (val == null || val.ToString().Trim() == "") return 0;
            double d;
            double.TryParse(val.ToString().Replace(",", "."),
                System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture, out d);
            return d;
        }

        private void btnPlanovi_Click(object sender, EventArgs e)
        {
            using (var frm = new FrmTreningPlan()) { frm.ShowDialog(); UcitajPlanoveZaDanas(); }
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            this.ClientSize = new System.Drawing.Size(1200, 720);
            this.Name = "FrmNaslovna";
            this.ResumeLayout(false);
        }

        private void FrmNaslovna_Load(object sender, EventArgs e) { }
    }
}