using System;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApplication1
{
    public static class KorisnikManager
    {
        public static int TrenutniKorisnikID { get; private set; }
        public static string TrenutniUsername { get; private set; }

        public static bool Prijavi(string username, string password)
        {
            string hash = SHA256Hash(password);
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                {
                    string sql = "SELECT KorisnikID, Username FROM korisnik " +
                                 "WHERE Username=@u AND PasswordHash=@p";
                    using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@u", username);
                        cmd.Parameters.AddWithValue("@p", hash);
                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                TrenutniKorisnikID = reader.GetInt32(0);
                                TrenutniUsername   = reader.GetString(1);
                                return true;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška pri prijavi: " + ex.Message);
            }
            return false;
        }

        public static string SHA256Hash(string input)
        {
            using (SHA256 sha = SHA256.Create())
            {
                byte[] bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(input));
                StringBuilder sb = new StringBuilder();
                foreach (byte b in bytes)
                    sb.Append(b.ToString("x2"));
                return sb.ToString();
            }
        }

        public static void Odjavi()
        {
            TrenutniKorisnikID = 0;
            TrenutniUsername   = null;
        }
    }
}
