﻿namespace WindowsFormsApplication1
{
    partial class FrmEvidencija
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlLijevo = new System.Windows.Forms.Panel();
            this.lblEvidencija = new System.Windows.Forms.Label();
            this.pnlSep1 = new System.Windows.Forms.Panel();
            this.lblNapredakLbl = new System.Windows.Forms.Label();
            this.cmbVjezba = new System.Windows.Forms.ComboBox();
            this.lblPrikazCharta = new System.Windows.Forms.Label();
            this.cmbPrikazCharta = new System.Windows.Forms.ComboBox();
            this.pnlSep2 = new System.Windows.Forms.Panel();
            this.lblHistorijaLbl = new System.Windows.Forms.Label();
            this.lstHistorija = new System.Windows.Forms.ListBox();
            this.lblUkupnoTreninga = new System.Windows.Forms.Label();
            this.pnlDesno = new System.Windows.Forms.Panel();
            this.lblChartTitle = new System.Windows.Forms.Label();
            this.pnlChart = new System.Windows.Forms.Panel();
            this.lblChartPlaceholder = new System.Windows.Forms.Label();
            this.pnlKlikInfo = new System.Windows.Forms.Panel();
            this.lblKlikNaInfo = new System.Windows.Forms.Label();
            this.dgvDetalji = new System.Windows.Forms.DataGridView();
            this.colVjezba = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSerije = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPonavljanja = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMaxKilaza = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colVolumen = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colUradjeno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPrthVolumen = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDelta = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlLijevo.SuspendLayout();
            this.pnlDesno.SuspendLayout();
            this.pnlChart.SuspendLayout();
            this.pnlKlikInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetalji)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlLijevo
            // 
            this.pnlLijevo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(25)))), ((int)(((byte)(45)))));
            this.pnlLijevo.Controls.Add(this.lblEvidencija);
            this.pnlLijevo.Controls.Add(this.pnlSep1);
            this.pnlLijevo.Controls.Add(this.lblNapredakLbl);
            this.pnlLijevo.Controls.Add(this.cmbVjezba);
            this.pnlLijevo.Controls.Add(this.lblPrikazCharta);
            this.pnlLijevo.Controls.Add(this.cmbPrikazCharta);
            this.pnlLijevo.Controls.Add(this.pnlSep2);
            this.pnlLijevo.Controls.Add(this.lblHistorijaLbl);
            this.pnlLijevo.Controls.Add(this.lstHistorija);
            this.pnlLijevo.Controls.Add(this.lblUkupnoTreninga);
            this.pnlLijevo.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlLijevo.Location = new System.Drawing.Point(0, 0);
            this.pnlLijevo.Name = "pnlLijevo";
            this.pnlLijevo.Size = new System.Drawing.Size(250, 560);
            this.pnlLijevo.TabIndex = 1;
            // 
            // lblEvidencija
            // 
            this.lblEvidencija.AutoSize = true;
            this.lblEvidencija.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblEvidencija.ForeColor = System.Drawing.Color.White;
            this.lblEvidencija.Location = new System.Drawing.Point(14, 18);
            this.lblEvidencija.Name = "lblEvidencija";
            this.lblEvidencija.Size = new System.Drawing.Size(117, 30);
            this.lblEvidencija.TabIndex = 0;
            this.lblEvidencija.Text = "Evidencija";
            // 
            // pnlSep1
            // 
            this.pnlSep1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(52)))), ((int)(((byte)(80)))));
            this.pnlSep1.Location = new System.Drawing.Point(10, 58);
            this.pnlSep1.Name = "pnlSep1";
            this.pnlSep1.Size = new System.Drawing.Size(228, 1);
            this.pnlSep1.TabIndex = 1;
            // 
            // lblNapredakLbl
            // 
            this.lblNapredakLbl.AutoSize = true;
            this.lblNapredakLbl.Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold);
            this.lblNapredakLbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(176)))), ((int)(((byte)(220)))));
            this.lblNapredakLbl.Location = new System.Drawing.Point(14, 70);
            this.lblNapredakLbl.Name = "lblNapredakLbl";
            this.lblNapredakLbl.Size = new System.Drawing.Size(117, 15);
            this.lblNapredakLbl.TabIndex = 2;
            this.lblNapredakLbl.Text = "Napredak po vjezbi:";
            // 
            // cmbVjezba
            // 
            this.cmbVjezba.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(47)))), ((int)(((byte)(75)))));
            this.cmbVjezba.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbVjezba.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbVjezba.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.cmbVjezba.ForeColor = System.Drawing.Color.White;
            this.cmbVjezba.Location = new System.Drawing.Point(14, 90);
            this.cmbVjezba.Name = "cmbVjezba";
            this.cmbVjezba.Size = new System.Drawing.Size(222, 23);
            this.cmbVjezba.TabIndex = 3;
            this.cmbVjezba.SelectedIndexChanged += new System.EventHandler(this.cmbVjezba_SelectedIndexChanged);
            // 
            // lblPrikazCharta
            // 
            this.lblPrikazCharta.AutoSize = true;
            this.lblPrikazCharta.Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold);
            this.lblPrikazCharta.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(176)))), ((int)(((byte)(220)))));
            this.lblPrikazCharta.Location = new System.Drawing.Point(14, 124);
            this.lblPrikazCharta.Name = "lblPrikazCharta";
            this.lblPrikazCharta.Size = new System.Drawing.Size(82, 15);
            this.lblPrikazCharta.TabIndex = 4;
            this.lblPrikazCharta.Text = "Prikaz charta:";
            // 
            // cmbPrikazCharta
            // 
            this.cmbPrikazCharta.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(47)))), ((int)(((byte)(75)))));
            this.cmbPrikazCharta.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPrikazCharta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbPrikazCharta.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.cmbPrikazCharta.ForeColor = System.Drawing.Color.White;
            this.cmbPrikazCharta.Items.AddRange(new object[] {
            "Max kilaza (kg)",
            "Ukupni volumen",
            "Broj ponavljanja"});
            this.cmbPrikazCharta.Location = new System.Drawing.Point(14, 144);
            this.cmbPrikazCharta.Name = "cmbPrikazCharta";
            this.cmbPrikazCharta.Size = new System.Drawing.Size(222, 23);
            this.cmbPrikazCharta.TabIndex = 5;
            this.cmbPrikazCharta.SelectedIndexChanged += new System.EventHandler(this.cmbPrikazCharta_SelectedIndexChanged);
            // 
            // pnlSep2
            // 
            this.pnlSep2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(52)))), ((int)(((byte)(80)))));
            this.pnlSep2.Location = new System.Drawing.Point(10, 182);
            this.pnlSep2.Name = "pnlSep2";
            this.pnlSep2.Size = new System.Drawing.Size(228, 1);
            this.pnlSep2.TabIndex = 6;
            // 
            // lblHistorijaLbl
            // 
            this.lblHistorijaLbl.AutoSize = true;
            this.lblHistorijaLbl.Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold);
            this.lblHistorijaLbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(176)))), ((int)(((byte)(220)))));
            this.lblHistorijaLbl.Location = new System.Drawing.Point(14, 192);
            this.lblHistorijaLbl.Name = "lblHistorijaLbl";
            this.lblHistorijaLbl.Size = new System.Drawing.Size(106, 15);
            this.lblHistorijaLbl.TabIndex = 7;
            this.lblHistorijaLbl.Text = "Historija treninga:";
            // 
            // lstHistorija
            // 
            this.lstHistorija.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(37)))), ((int)(((byte)(62)))));
            this.lstHistorija.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lstHistorija.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lstHistorija.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(196)))), ((int)(((byte)(230)))));
            this.lstHistorija.ItemHeight = 15;
            this.lstHistorija.Location = new System.Drawing.Point(0, 215);
            this.lstHistorija.Name = "lstHistorija";
            this.lstHistorija.Size = new System.Drawing.Size(250, 390);
            this.lstHistorija.TabIndex = 8;
            this.lstHistorija.SelectedIndexChanged += new System.EventHandler(this.lstHistorija_SelectedIndexChanged);
            // 
            // lblUkupnoTreninga
            // 
            this.lblUkupnoTreninga.AutoSize = true;
            this.lblUkupnoTreninga.Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold);
            this.lblUkupnoTreninga.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(116)))), ((int)(((byte)(160)))));
            this.lblUkupnoTreninga.Location = new System.Drawing.Point(14, 614);
            this.lblUkupnoTreninga.Name = "lblUkupnoTreninga";
            this.lblUkupnoTreninga.Size = new System.Drawing.Size(114, 15);
            this.lblUkupnoTreninga.TabIndex = 9;
            this.lblUkupnoTreninga.Text = "Ukupno treninga: 0";
            // 
            // pnlDesno
            // 
            this.pnlDesno.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.pnlDesno.Controls.Add(this.lblChartTitle);
            this.pnlDesno.Controls.Add(this.pnlChart);
            this.pnlDesno.Controls.Add(this.pnlKlikInfo);
            this.pnlDesno.Controls.Add(this.dgvDetalji);
            this.pnlDesno.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlDesno.Location = new System.Drawing.Point(250, 0);
            this.pnlDesno.Name = "pnlDesno";
            this.pnlDesno.Size = new System.Drawing.Size(649, 560);
            this.pnlDesno.TabIndex = 0;
            // 
            // lblChartTitle
            // 
            this.lblChartTitle.AutoSize = true;
            this.lblChartTitle.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.lblChartTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(27)))), ((int)(((byte)(50)))));
            this.lblChartTitle.Location = new System.Drawing.Point(20, 18);
            this.lblChartTitle.Name = "lblChartTitle";
            this.lblChartTitle.Size = new System.Drawing.Size(296, 25);
            this.lblChartTitle.TabIndex = 0;
            this.lblChartTitle.Text = "Odaberi vjezbu da vidis napredak";
            // 
            // pnlChart
            // 
            this.pnlChart.BackColor = System.Drawing.Color.White;
            this.pnlChart.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlChart.Controls.Add(this.lblChartPlaceholder);
            this.pnlChart.Location = new System.Drawing.Point(20, 55);
            this.pnlChart.Name = "pnlChart";
            this.pnlChart.Size = new System.Drawing.Size(629, 200);
            this.pnlChart.TabIndex = 1;
            // 
            // lblChartPlaceholder
            // 
            this.lblChartPlaceholder.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lblChartPlaceholder.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(195)))));
            this.lblChartPlaceholder.Location = new System.Drawing.Point(-1, 2);
            this.lblChartPlaceholder.Name = "lblChartPlaceholder";
            this.lblChartPlaceholder.Size = new System.Drawing.Size(630, 198);
            this.lblChartPlaceholder.TabIndex = 0;
            this.lblChartPlaceholder.Text = "Nema podataka za prikaz";
            this.lblChartPlaceholder.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblChartPlaceholder.Click += new System.EventHandler(this.lblChartPlaceholder_Click);
            // 
            // pnlKlikInfo
            // 
            this.pnlKlikInfo.BackColor = System.Drawing.Color.White;
            this.pnlKlikInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlKlikInfo.Controls.Add(this.lblKlikNaInfo);
            this.pnlKlikInfo.Location = new System.Drawing.Point(20, 215);
            this.pnlKlikInfo.Name = "pnlKlikInfo";
            this.pnlKlikInfo.Size = new System.Drawing.Size(620, 36);
            this.pnlKlikInfo.TabIndex = 2;
            // 
            // lblKlikNaInfo
            // 
            this.lblKlikNaInfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblKlikNaInfo.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblKlikNaInfo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(27)))), ((int)(((byte)(50)))));
            this.lblKlikNaInfo.Location = new System.Drawing.Point(0, 0);
            this.lblKlikNaInfo.Name = "lblKlikNaInfo";
            this.lblKlikNaInfo.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.lblKlikNaInfo.Size = new System.Drawing.Size(618, 34);
            this.lblKlikNaInfo.TabIndex = 0;
            this.lblKlikNaInfo.Text = "Klikni na trening sa lijeve strane:";
            this.lblKlikNaInfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // dgvDetalji
            // 
            this.dgvDetalji.AllowUserToAddRows = false;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(248)))), ((int)(((byte)(252)))));
            this.dgvDetalji.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle7;
            this.dgvDetalji.BackgroundColor = System.Drawing.Color.White;
            this.dgvDetalji.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(31)))), ((int)(((byte)(53)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDetalji.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.dgvDetalji.ColumnHeadersHeight = 36;
            this.dgvDetalji.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvDetalji.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colVjezba,
            this.colSerije,
            this.colPonavljanja,
            this.colMaxKilaza,
            this.colVolumen,
            this.colUradjeno,
            this.colPrthVolumen,
            this.colDelta});
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(86)))), ((int)(((byte)(214)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvDetalji.DefaultCellStyle = dataGridViewCellStyle9;
            this.dgvDetalji.EnableHeadersVisualStyles = false;
            this.dgvDetalji.Location = new System.Drawing.Point(20, 255);
            this.dgvDetalji.Name = "dgvDetalji";
            this.dgvDetalji.ReadOnly = true;
            this.dgvDetalji.RowHeadersVisible = false;
            this.dgvDetalji.RowTemplate.Height = 30;
            this.dgvDetalji.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDetalji.Size = new System.Drawing.Size(630, 258);
            this.dgvDetalji.TabIndex = 3;
            // 
            // colVjezba
            // 
            this.colVjezba.HeaderText = "Vjezba";
            this.colVjezba.Name = "colVjezba";
            this.colVjezba.ReadOnly = true;
            this.colVjezba.Width = 160;
            // 
            // colSerije
            // 
            this.colSerije.HeaderText = "Serije";
            this.colSerije.Name = "colSerije";
            this.colSerije.ReadOnly = true;
            this.colSerije.Width = 65;
            // 
            // colPonavljanja
            // 
            this.colPonavljanja.HeaderText = "Ponavljanja";
            this.colPonavljanja.Name = "colPonavljanja";
            this.colPonavljanja.ReadOnly = true;
            this.colPonavljanja.Width = 90;
            // 
            // colMaxKilaza
            // 
            this.colMaxKilaza.HeaderText = "Max kilaza";
            this.colMaxKilaza.Name = "colMaxKilaza";
            this.colMaxKilaza.ReadOnly = true;
            this.colMaxKilaza.Width = 90;
            // 
            // colVolumen
            // 
            this.colVolumen.HeaderText = "Volumen";
            this.colVolumen.Name = "colVolumen";
            this.colVolumen.ReadOnly = true;
            this.colVolumen.Width = 80;
            // 
            // colUradjeno
            // 
            this.colUradjeno.HeaderText = "Uradjeno";
            this.colUradjeno.Name = "colUradjeno";
            this.colUradjeno.ReadOnly = true;
            this.colUradjeno.Width = 80;
            // 
            // colPrthVolumen
            // 
            this.colPrthVolumen.HeaderText = "Preth. volumen";
            this.colPrthVolumen.Name = "colPrthVolumen";
            this.colPrthVolumen.ReadOnly = true;
            // 
            // colDelta
            // 
            this.colDelta.HeaderText = "Delta";
            this.colDelta.Name = "colDelta";
            this.colDelta.ReadOnly = true;
            this.colDelta.Width = 65;
            // 
            // FrmEvidencija
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.ClientSize = new System.Drawing.Size(899, 560);
            this.Controls.Add(this.pnlDesno);
            this.Controls.Add(this.pnlLijevo);
            this.MinimumSize = new System.Drawing.Size(900, 560);
            this.Name = "FrmEvidencija";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Evidencija i Napredak";
            this.Load += new System.EventHandler(this.FrmEvidencija_Load);
            this.pnlLijevo.ResumeLayout(false);
            this.pnlLijevo.PerformLayout();
            this.pnlDesno.ResumeLayout(false);
            this.pnlDesno.PerformLayout();
            this.pnlChart.ResumeLayout(false);
            this.pnlKlikInfo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetalji)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlLijevo;
        private System.Windows.Forms.Label lblEvidencija;
        private System.Windows.Forms.Panel pnlSep1;
        private System.Windows.Forms.Label lblNapredakLbl;
        private System.Windows.Forms.ComboBox cmbVjezba;
        private System.Windows.Forms.Label lblPrikazCharta;
        private System.Windows.Forms.ComboBox cmbPrikazCharta;
        private System.Windows.Forms.Panel pnlSep2;
        private System.Windows.Forms.Label lblHistorijaLbl;
        private System.Windows.Forms.ListBox lstHistorija;
        private System.Windows.Forms.Label lblUkupnoTreninga;
        private System.Windows.Forms.Panel pnlDesno;
        private System.Windows.Forms.Label lblChartTitle;
        private System.Windows.Forms.Panel pnlChart;
        private System.Windows.Forms.Label lblChartPlaceholder;
        private System.Windows.Forms.Panel pnlKlikInfo;
        private System.Windows.Forms.Label lblKlikNaInfo;
        private System.Windows.Forms.DataGridView dgvDetalji;
        private System.Windows.Forms.DataGridViewTextBoxColumn colVjezba;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSerije;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPonavljanja;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMaxKilaza;
        private System.Windows.Forms.DataGridViewTextBoxColumn colVolumen;
        private System.Windows.Forms.DataGridViewTextBoxColumn colUradjeno;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPrthVolumen;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDelta;
    }
}
