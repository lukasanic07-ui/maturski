﻿namespace WindowsFormsApplication1
{
    partial class FrmEvidencija
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.pnlLijevo = new System.Windows.Forms.Panel();
            this.lblEvidencija = new System.Windows.Forms.Label();
            this.pnlSep1 = new System.Windows.Forms.Panel();
            this.lblNapredakLbl = new System.Windows.Forms.Label();
            this.cmbVjezba = new System.Windows.Forms.ComboBox();
            this.lblPrikazCharta = new System.Windows.Forms.Label();
            this.cmbPrikazCharta = new System.Windows.Forms.ComboBox();
            this.pnlSep2 = new System.Windows.Forms.Panel();
            this.lblHistorijaLbl = new System.Windows.Forms.Label();
            this.lstHistorija = new System.Windows.Forms.ListBox();
            this.lblUkupnoTreninga = new System.Windows.Forms.Label();
            this.pnlDesno = new System.Windows.Forms.Panel();
            this.lblChartTitle = new System.Windows.Forms.Label();
            this.pnlChart = new System.Windows.Forms.Panel();
            this.lblChartPlaceholder = new System.Windows.Forms.Label();
            this.pnlKlikInfo = new System.Windows.Forms.Panel();
            this.lblKlikNaInfo = new System.Windows.Forms.Label();
            this.dgvDetalji = new System.Windows.Forms.DataGridView();
            this.colVjezba = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSerije = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPonavljanja = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMaxKilaza = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colVolumen = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colUradjeno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPrthVolumen = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDelta = new System.Windows.Forms.DataGridViewTextBoxColumn();

            this.pnlLijevo.SuspendLayout();
            this.pnlDesno.SuspendLayout();
            this.pnlChart.SuspendLayout();
            this.pnlKlikInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetalji)).BeginInit();
            this.SuspendLayout();

            // ── LEFT SIDEBAR ─────────────────────────────────────────────
            this.pnlLijevo.BackColor = System.Drawing.Color.FromArgb(28, 25, 45);
            this.pnlLijevo.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlLijevo.Width = 250;
            this.pnlLijevo.Controls.AddRange(new System.Windows.Forms.Control[] {
                this.lblEvidencija, this.pnlSep1,
                this.lblNapredakLbl, this.cmbVjezba,
                this.lblPrikazCharta, this.cmbPrikazCharta,
                this.pnlSep2, this.lblHistorijaLbl,
                this.lstHistorija, this.lblUkupnoTreninga });

            this.lblEvidencija.Text = "Evidencija";
            this.lblEvidencija.Font = new System.Drawing.Font("Segoe UI", 16f, System.Drawing.FontStyle.Bold);
            this.lblEvidencija.ForeColor = System.Drawing.Color.White;
            this.lblEvidencija.Location = new System.Drawing.Point(14, 18);
            this.lblEvidencija.AutoSize = true;

            this.pnlSep1.BackColor = System.Drawing.Color.FromArgb(55, 52, 80);
            this.pnlSep1.Location = new System.Drawing.Point(10, 58);
            this.pnlSep1.Size = new System.Drawing.Size(228, 1);

            // Napredak po vjezbi
            this.lblNapredakLbl.Text = "Napredak po vjezbi:";
            this.lblNapredakLbl.Font = new System.Drawing.Font("Segoe UI", 8.5f, System.Drawing.FontStyle.Bold);
            this.lblNapredakLbl.ForeColor = System.Drawing.Color.FromArgb(180, 176, 220);
            this.lblNapredakLbl.Location = new System.Drawing.Point(14, 70);
            this.lblNapredakLbl.AutoSize = true;

            this.cmbVjezba.Font = new System.Drawing.Font("Segoe UI", 9f);
            this.cmbVjezba.BackColor = System.Drawing.Color.FromArgb(50, 47, 75);
            this.cmbVjezba.ForeColor = System.Drawing.Color.White;
            this.cmbVjezba.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbVjezba.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbVjezba.Location = new System.Drawing.Point(14, 90);
            this.cmbVjezba.Size = new System.Drawing.Size(222, 24);
            this.cmbVjezba.SelectedIndexChanged += new System.EventHandler(this.cmbVjezba_SelectedIndexChanged);

            this.lblPrikazCharta.Text = "Prikaz charta:";
            this.lblPrikazCharta.Font = new System.Drawing.Font("Segoe UI", 8.5f, System.Drawing.FontStyle.Bold);
            this.lblPrikazCharta.ForeColor = System.Drawing.Color.FromArgb(180, 176, 220);
            this.lblPrikazCharta.Location = new System.Drawing.Point(14, 124);
            this.lblPrikazCharta.AutoSize = true;

            this.cmbPrikazCharta.Font = new System.Drawing.Font("Segoe UI", 9f);
            this.cmbPrikazCharta.BackColor = System.Drawing.Color.FromArgb(50, 47, 75);
            this.cmbPrikazCharta.ForeColor = System.Drawing.Color.White;
            this.cmbPrikazCharta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbPrikazCharta.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPrikazCharta.Location = new System.Drawing.Point(14, 144);
            this.cmbPrikazCharta.Size = new System.Drawing.Size(222, 24);
            this.cmbPrikazCharta.Items.AddRange(new object[] {
                "Max kilaza (kg)", "Ukupni volumen", "Broj ponavljanja" });
            this.cmbPrikazCharta.SelectedIndexChanged += new System.EventHandler(this.cmbPrikazCharta_SelectedIndexChanged);

            this.pnlSep2.BackColor = System.Drawing.Color.FromArgb(55, 52, 80);
            this.pnlSep2.Location = new System.Drawing.Point(10, 182);
            this.pnlSep2.Size = new System.Drawing.Size(228, 1);

            this.lblHistorijaLbl.Text = "Historija treninga:";
            this.lblHistorijaLbl.Font = new System.Drawing.Font("Segoe UI", 8.5f, System.Drawing.FontStyle.Bold);
            this.lblHistorijaLbl.ForeColor = System.Drawing.Color.FromArgb(180, 176, 220);
            this.lblHistorijaLbl.Location = new System.Drawing.Point(14, 192);
            this.lblHistorijaLbl.AutoSize = true;

            this.lstHistorija.BackColor = System.Drawing.Color.FromArgb(40, 37, 62);
            this.lstHistorija.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lstHistorija.Font = new System.Drawing.Font("Segoe UI", 9f);
            this.lstHistorija.ForeColor = System.Drawing.Color.FromArgb(200, 196, 230);
            this.lstHistorija.ItemHeight = 26;
            this.lstHistorija.Location = new System.Drawing.Point(0, 215);
            this.lstHistorija.Size = new System.Drawing.Size(250, 390);
            this.lstHistorija.SelectedIndexChanged += new System.EventHandler(this.lstHistorija_SelectedIndexChanged);

            this.lblUkupnoTreninga.Text = "Ukupno treninga: 0";
            this.lblUkupnoTreninga.Font = new System.Drawing.Font("Segoe UI", 8.5f, System.Drawing.FontStyle.Bold);
            this.lblUkupnoTreninga.ForeColor = System.Drawing.Color.FromArgb(120, 116, 160);
            this.lblUkupnoTreninga.Location = new System.Drawing.Point(14, 614);
            this.lblUkupnoTreninga.AutoSize = true;

            // ── RIGHT CONTENT ─────────────────────────────────────────────
            this.pnlDesno.BackColor = System.Drawing.Color.FromArgb(245, 247, 252);
            this.pnlDesno.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlDesno.Controls.AddRange(new System.Windows.Forms.Control[] {
                this.lblChartTitle, this.pnlChart, this.pnlKlikInfo, this.dgvDetalji });

            this.lblChartTitle.Text = "Odaberi vjezbu da vidis napredak";
            this.lblChartTitle.Font = new System.Drawing.Font("Segoe UI", 13f, System.Drawing.FontStyle.Bold);
            this.lblChartTitle.ForeColor = System.Drawing.Color.FromArgb(30, 27, 50);
            this.lblChartTitle.Location = new System.Drawing.Point(20, 18);
            this.lblChartTitle.AutoSize = true;

            // Chart placeholder panel (where the chart control will be added at runtime)
            this.pnlChart.BackColor = System.Drawing.Color.White;
            this.pnlChart.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlChart.Location = new System.Drawing.Point(20, 55);
            this.pnlChart.Size = new System.Drawing.Size(620, 200);
            this.pnlChart.Controls.Add(this.lblChartPlaceholder);

            this.lblChartPlaceholder.Text = "Nema podataka za prikaz";
            this.lblChartPlaceholder.Font = new System.Drawing.Font("Segoe UI", 11f);
            this.lblChartPlaceholder.ForeColor = System.Drawing.Color.FromArgb(180, 180, 195);
            this.lblChartPlaceholder.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblChartPlaceholder.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // "Klikni na trening" info bar
            this.pnlKlikInfo.BackColor = System.Drawing.Color.White;
            this.pnlKlikInfo.Location = new System.Drawing.Point(20, 215);
            this.pnlKlikInfo.Size = new System.Drawing.Size(620, 36);
            this.pnlKlikInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlKlikInfo.Controls.Add(this.lblKlikNaInfo);

            this.lblKlikNaInfo.Text = "Klikni na trening sa lijeve strane:";
            this.lblKlikNaInfo.Font = new System.Drawing.Font("Segoe UI", 9f, System.Drawing.FontStyle.Bold);
            this.lblKlikNaInfo.ForeColor = System.Drawing.Color.FromArgb(30, 27, 50);
            this.lblKlikNaInfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblKlikNaInfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblKlikNaInfo.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);

            // DataGridView
            this.dgvDetalji.Location = new System.Drawing.Point(20, 255);
            this.dgvDetalji.Size = new System.Drawing.Size(630, 258);
            this.dgvDetalji.ReadOnly = true;
            this.dgvDetalji.AllowUserToAddRows = false;
            this.dgvDetalji.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDetalji.AutoGenerateColumns = false;
            this.dgvDetalji.BackgroundColor = System.Drawing.Color.White;
            this.dgvDetalji.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvDetalji.RowHeadersVisible = false;
            this.dgvDetalji.EnableHeadersVisualStyles = false;
            this.dgvDetalji.ColumnHeadersHeight = 36;
            this.dgvDetalji.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvDetalji.RowTemplate.Height = 30;
            this.dgvDetalji.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(34, 31, 53);
            this.dgvDetalji.ColumnHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.White;
            this.dgvDetalji.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9f, System.Drawing.FontStyle.Bold);
            this.dgvDetalji.DefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9f);
            this.dgvDetalji.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(88, 86, 214);
            this.dgvDetalji.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.White;
            this.dgvDetalji.AlternatingRowsDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(248, 248, 252);

            this.colVjezba.HeaderText = "Vjezba"; this.colVjezba.Name = "colVjezba"; this.colVjezba.Width = 160;
            this.colSerije.HeaderText = "Serije"; this.colSerije.Name = "colSerije"; this.colSerije.Width = 65;
            this.colPonavljanja.HeaderText = "Ponavljanja"; this.colPonavljanja.Name = "colPonavljanja"; this.colPonavljanja.Width = 90;
            this.colMaxKilaza.HeaderText = "Max kilaza"; this.colMaxKilaza.Name = "colMaxKilaza"; this.colMaxKilaza.Width = 90;
            this.colVolumen.HeaderText = "Volumen"; this.colVolumen.Name = "colVolumen"; this.colVolumen.Width = 80;
            this.colUradjeno.HeaderText = "Uradjeno"; this.colUradjeno.Name = "colUradjeno"; this.colUradjeno.Width = 80;
            this.colPrthVolumen.HeaderText = "Preth. volumen"; this.colPrthVolumen.Name = "colPrthVolumen"; this.colPrthVolumen.Width = 100;
            this.colDelta.HeaderText = "Delta"; this.colDelta.Name = "colDelta"; this.colDelta.Width = 65;
            this.dgvDetalji.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
                this.colVjezba, this.colSerije, this.colPonavljanja, this.colMaxKilaza,
                this.colVolumen, this.colUradjeno, this.colPrthVolumen, this.colDelta });

            // ── FrmEvidencija ─────────────────────────────────────────────
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(900, 560);
            this.MinimumSize = new System.Drawing.Size(900, 560);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Evidencija i Napredak";
            this.BackColor = System.Drawing.Color.FromArgb(245, 247, 252);
            this.Controls.Add(this.pnlDesno);
            this.Controls.Add(this.pnlLijevo);

            this.pnlLijevo.ResumeLayout(false);
            this.pnlLijevo.PerformLayout();
            this.pnlDesno.ResumeLayout(false);
            this.pnlDesno.PerformLayout();
            this.pnlChart.ResumeLayout(false);
            this.pnlKlikInfo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetalji)).EndInit();
            this.ResumeLayout(false);

            this.Load += new System.EventHandler(this.FrmEvidencija_Load);
        }

        #endregion

        private System.Windows.Forms.Panel pnlLijevo;
        private System.Windows.Forms.Label lblEvidencija;
        private System.Windows.Forms.Panel pnlSep1;
        private System.Windows.Forms.Label lblNapredakLbl;
        private System.Windows.Forms.ComboBox cmbVjezba;
        private System.Windows.Forms.Label lblPrikazCharta;
        private System.Windows.Forms.ComboBox cmbPrikazCharta;
        private System.Windows.Forms.Panel pnlSep2;
        private System.Windows.Forms.Label lblHistorijaLbl;
        private System.Windows.Forms.ListBox lstHistorija;
        private System.Windows.Forms.Label lblUkupnoTreninga;
        private System.Windows.Forms.Panel pnlDesno;
        private System.Windows.Forms.Label lblChartTitle;
        private System.Windows.Forms.Panel pnlChart;
        private System.Windows.Forms.Label lblChartPlaceholder;
        private System.Windows.Forms.Panel pnlKlikInfo;
        private System.Windows.Forms.Label lblKlikNaInfo;
        private System.Windows.Forms.DataGridView dgvDetalji;
        private System.Windows.Forms.DataGridViewTextBoxColumn colVjezba;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSerije;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPonavljanja;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMaxKilaza;
        private System.Windows.Forms.DataGridViewTextBoxColumn colVolumen;
        private System.Windows.Forms.DataGridViewTextBoxColumn colUradjeno;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPrthVolumen;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDelta;
    }
}
