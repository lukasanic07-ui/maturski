namespace WindowsFormsApplication1
{
    partial class FrmDashboard
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.pnlHeader       = new System.Windows.Forms.Panel();
            this.lblNaslov       = new System.Windows.Forms.Label();
            this.lblUsername     = new System.Windows.Forms.Label();
            this.pnlNav          = new System.Windows.Forms.Panel();
            this.btnVjezbe       = new System.Windows.Forms.Button();
            this.btnProfil       = new System.Windows.Forms.Button();
            this.pnlMain         = new System.Windows.Forms.Panel();
            this.lblStatus       = new System.Windows.Forms.Label();
            this.btnStartTrening = new System.Windows.Forms.Button();
            this.pnlUnos         = new System.Windows.Forms.Panel();
            this.lblVjezbaLbl    = new System.Windows.Forms.Label();
            this.cmbVjezba       = new System.Windows.Forms.ComboBox();
            this.lblSerijeLbl    = new System.Windows.Forms.Label();
            this.txtSerije       = new System.Windows.Forms.TextBox();
            this.lblPonavljanjaLbl = new System.Windows.Forms.Label();
            this.txtPonavljanja  = new System.Windows.Forms.TextBox();
            this.lblKilazaLbl    = new System.Windows.Forms.Label();
            this.txtKilaza       = new System.Windows.Forms.TextBox();
            this.btnDodajVjezbu  = new System.Windows.Forms.Button();
            this.btnUkloni       = new System.Windows.Forms.Button();
            this.dgvVjezbe       = new System.Windows.Forms.DataGridView();
            this.colVjezba       = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSerije       = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPonavljanja  = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colKilaza       = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colVolumen      = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblVjezbeUkupno = new System.Windows.Forms.Label();

            this.pnlHeader.SuspendLayout();
            this.pnlNav.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.pnlUnos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVjezbe)).BeginInit();
            this.SuspendLayout();

            // ── pnlHeader ────────────────────────────────────────────────
            this.pnlHeader.BackColor = System.Drawing.Color.FromArgb(88, 86, 214);
            this.pnlHeader.Dock      = System.Windows.Forms.DockStyle.Top;
            this.pnlHeader.Height    = 60;
            this.pnlHeader.Controls.AddRange(new System.Windows.Forms.Control[] {
                this.lblNaslov, this.lblUsername });

            this.lblNaslov.Text      = "FitTracker  —  Dashboard";
            this.lblNaslov.Location  = new System.Drawing.Point(20, 16);
            this.lblNaslov.Font      = new System.Drawing.Font("Segoe UI", 14f, System.Drawing.FontStyle.Bold);
            this.lblNaslov.ForeColor = System.Drawing.Color.White;
            this.lblNaslov.AutoSize  = true;

            this.lblUsername.Text      = "";
            this.lblUsername.Location  = new System.Drawing.Point(700, 20);
            this.lblUsername.Font      = new System.Drawing.Font("Segoe UI", 10f);
            this.lblUsername.ForeColor = System.Drawing.Color.FromArgb(200, 200, 255);
            this.lblUsername.AutoSize  = true;

            // ── pnlNav ───────────────────────────────────────────────────
            this.pnlNav.BackColor = System.Drawing.Color.FromArgb(70, 68, 190);
            this.pnlNav.Dock      = System.Windows.Forms.DockStyle.Left;
            this.pnlNav.Width     = 160;
            this.pnlNav.Controls.AddRange(new System.Windows.Forms.Control[] {
                this.btnVjezbe, this.btnProfil });

            // btnVjezbe
            this.btnVjezbe.Text      = "Evidencija";
            this.btnVjezbe.Location  = new System.Drawing.Point(0, 20);
            this.btnVjezbe.Size      = new System.Drawing.Size(160, 48);
            this.btnVjezbe.Font      = new System.Drawing.Font("Segoe UI", 10f);
            this.btnVjezbe.ForeColor = System.Drawing.Color.White;
            this.btnVjezbe.BackColor = System.Drawing.Color.Transparent;
            this.btnVjezbe.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVjezbe.FlatAppearance.BorderSize = 0;
            this.btnVjezbe.Cursor    = System.Windows.Forms.Cursors.Hand;
            this.btnVjezbe.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnVjezbe.Padding   = new System.Windows.Forms.Padding(16, 0, 0, 0);
            this.btnVjezbe.Click    += new System.EventHandler(this.btnVjezbe_Click);

            // btnProfil
            this.btnProfil.Text      = "Moj profil";
            this.btnProfil.Location  = new System.Drawing.Point(0, 70);
            this.btnProfil.Size      = new System.Drawing.Size(160, 48);
            this.btnProfil.Font      = new System.Drawing.Font("Segoe UI", 10f);
            this.btnProfil.ForeColor = System.Drawing.Color.White;
            this.btnProfil.BackColor = System.Drawing.Color.Transparent;
            this.btnProfil.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProfil.FlatAppearance.BorderSize = 0;
            this.btnProfil.Cursor    = System.Windows.Forms.Cursors.Hand;
            this.btnProfil.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnProfil.Padding   = new System.Windows.Forms.Padding(16, 0, 0, 0);
            this.btnProfil.Click    += new System.EventHandler(this.btnProfil_Click);

            // ── pnlMain ──────────────────────────────────────────────────
            this.pnlMain.BackColor = System.Drawing.Color.FromArgb(245, 247, 250);
            this.pnlMain.Dock      = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Padding   = new System.Windows.Forms.Padding(20);
            this.pnlMain.Controls.AddRange(new System.Windows.Forms.Control[] {
                this.lblStatus,
                this.btnStartTrening,
                this.pnlUnos,
                this.dgvVjezbe,
                this.lblVjezbeUkupno
            });

            // lblStatus
            this.lblStatus.Text      = "Učitavanje...";
            this.lblStatus.Location  = new System.Drawing.Point(20, 14);
            this.lblStatus.Font      = new System.Drawing.Font("Segoe UI", 10f, System.Drawing.FontStyle.Italic);
            this.lblStatus.ForeColor = System.Drawing.Color.Gray;
            this.lblStatus.AutoSize  = true;

            // btnStartTrening
            this.btnStartTrening.Text      = "▶  Start novog treninga";
            this.btnStartTrening.Location  = new System.Drawing.Point(20, 40);
            this.btnStartTrening.Size      = new System.Drawing.Size(220, 40);
            this.btnStartTrening.Font      = new System.Drawing.Font("Segoe UI", 10f, System.Drawing.FontStyle.Bold);
            this.btnStartTrening.BackColor = System.Drawing.Color.FromArgb(40, 167, 69);
            this.btnStartTrening.ForeColor = System.Drawing.Color.White;
            this.btnStartTrening.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStartTrening.FlatAppearance.BorderSize = 0;
            this.btnStartTrening.Cursor    = System.Windows.Forms.Cursors.Hand;
            this.btnStartTrening.Click    += new System.EventHandler(this.btnStartTrening_Click);

            // ── pnlUnos — forma za unos vježbe ───────────────────────────
            this.pnlUnos.BackColor   = System.Drawing.Color.White;
            this.pnlUnos.Location    = new System.Drawing.Point(20, 98);
            this.pnlUnos.Size        = new System.Drawing.Size(820, 80);
            this.pnlUnos.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlUnos.Controls.AddRange(new System.Windows.Forms.Control[] {
                this.lblVjezbaLbl,  this.cmbVjezba,
                this.lblSerijeLbl,  this.txtSerije,
                this.lblPonavljanjaLbl, this.txtPonavljanja,
                this.lblKilazaLbl,  this.txtKilaza,
                this.btnDodajVjezbu, this.btnUkloni
            });

            // Vježba combo
            this.lblVjezbaLbl.Text      = "Vježba";
            this.lblVjezbaLbl.Location  = new System.Drawing.Point(8, 8);
            this.lblVjezbaLbl.Font      = new System.Drawing.Font("Segoe UI", 8f, System.Drawing.FontStyle.Bold);
            this.lblVjezbaLbl.ForeColor = System.Drawing.Color.FromArgb(88, 86, 214);
            this.lblVjezbaLbl.AutoSize  = true;

            this.cmbVjezba.Location       = new System.Drawing.Point(8, 26);
            this.cmbVjezba.Size           = new System.Drawing.Size(220, 24);
            this.cmbVjezba.DropDownStyle  = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbVjezba.Font           = new System.Drawing.Font("Segoe UI", 9f);

            // Serije
            this.lblSerijeLbl.Text      = "Serije";
            this.lblSerijeLbl.Location  = new System.Drawing.Point(240, 8);
            this.lblSerijeLbl.Font      = new System.Drawing.Font("Segoe UI", 8f, System.Drawing.FontStyle.Bold);
            this.lblSerijeLbl.ForeColor = System.Drawing.Color.FromArgb(88, 86, 214);
            this.lblSerijeLbl.AutoSize  = true;

            this.txtSerije.Location    = new System.Drawing.Point(240, 26);
            this.txtSerije.Size        = new System.Drawing.Size(65, 24);
            this.txtSerije.Font        = new System.Drawing.Font("Segoe UI", 10f);
            this.txtSerije.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSerije.TextAlign   = System.Windows.Forms.HorizontalAlignment.Center;

            // Ponavljanja
            this.lblPonavljanjaLbl.Text      = "Ponavljanja";
            this.lblPonavljanjaLbl.Location  = new System.Drawing.Point(316, 8);
            this.lblPonavljanjaLbl.Font      = new System.Drawing.Font("Segoe UI", 8f, System.Drawing.FontStyle.Bold);
            this.lblPonavljanjaLbl.ForeColor = System.Drawing.Color.FromArgb(88, 86, 214);
            this.lblPonavljanjaLbl.AutoSize  = true;

            this.txtPonavljanja.Location    = new System.Drawing.Point(316, 26);
            this.txtPonavljanja.Size        = new System.Drawing.Size(65, 24);
            this.txtPonavljanja.Font        = new System.Drawing.Font("Segoe UI", 10f);
            this.txtPonavljanja.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPonavljanja.TextAlign   = System.Windows.Forms.HorizontalAlignment.Center;

            // Kilaza
            this.lblKilazaLbl.Text      = "Kilaza (kg)";
            this.lblKilazaLbl.Location  = new System.Drawing.Point(392, 8);
            this.lblKilazaLbl.Font      = new System.Drawing.Font("Segoe UI", 8f, System.Drawing.FontStyle.Bold);
            this.lblKilazaLbl.ForeColor = System.Drawing.Color.FromArgb(88, 86, 214);
            this.lblKilazaLbl.AutoSize  = true;

            this.txtKilaza.Location    = new System.Drawing.Point(392, 26);
            this.txtKilaza.Size        = new System.Drawing.Size(80, 24);
            this.txtKilaza.Font        = new System.Drawing.Font("Segoe UI", 10f);
            this.txtKilaza.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtKilaza.TextAlign   = System.Windows.Forms.HorizontalAlignment.Center;

            // Dugme Dodaj
            this.btnDodajVjezbu.Text      = "+ Dodaj";
            this.btnDodajVjezbu.Location  = new System.Drawing.Point(490, 22);
            this.btnDodajVjezbu.Size      = new System.Drawing.Size(100, 32);
            this.btnDodajVjezbu.Font      = new System.Drawing.Font("Segoe UI", 9.5f, System.Drawing.FontStyle.Bold);
            this.btnDodajVjezbu.BackColor = System.Drawing.Color.FromArgb(88, 86, 214);
            this.btnDodajVjezbu.ForeColor = System.Drawing.Color.White;
            this.btnDodajVjezbu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDodajVjezbu.FlatAppearance.BorderSize = 0;
            this.btnDodajVjezbu.Cursor    = System.Windows.Forms.Cursors.Hand;
            this.btnDodajVjezbu.Click    += new System.EventHandler(this.btnDodajVjezbu_Click);

            // Dugme Ukloni
            this.btnUkloni.Text      = "✕ Ukloni";
            this.btnUkloni.Location  = new System.Drawing.Point(602, 22);
            this.btnUkloni.Size      = new System.Drawing.Size(90, 32);
            this.btnUkloni.Font      = new System.Drawing.Font("Segoe UI", 9.5f);
            this.btnUkloni.BackColor = System.Drawing.Color.White;
            this.btnUkloni.ForeColor = System.Drawing.Color.FromArgb(200, 60, 60);
            this.btnUkloni.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUkloni.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(200, 60, 60);
            this.btnUkloni.Cursor    = System.Windows.Forms.Cursors.Hand;
            this.btnUkloni.Click    += new System.EventHandler(this.btnUkloni_Click);

            // ── DataGridView — lista vježbi ───────────────────────────────
            this.dgvVjezbe.Location               = new System.Drawing.Point(20, 192);
            this.dgvVjezbe.Size                   = new System.Drawing.Size(820, 340);
            this.dgvVjezbe.ReadOnly               = true;
            this.dgvVjezbe.AllowUserToAddRows      = false;
            this.dgvVjezbe.SelectionMode          = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvVjezbe.AutoGenerateColumns    = false;
            this.dgvVjezbe.BackgroundColor        = System.Drawing.Color.White;
            this.dgvVjezbe.BorderStyle            = System.Windows.Forms.BorderStyle.None;
            this.dgvVjezbe.CellBorderStyle        = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvVjezbe.GridColor              = System.Drawing.Color.FromArgb(230, 230, 235);
            this.dgvVjezbe.RowHeadersVisible       = false;
            this.dgvVjezbe.EnableHeadersVisualStyles = false;
            this.dgvVjezbe.ColumnHeadersHeightSizeMode =
                System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvVjezbe.ColumnHeadersHeight    = 38;
            this.dgvVjezbe.RowTemplate.Height     = 32;

            // Header stil
            this.dgvVjezbe.ColumnHeadersDefaultCellStyle.BackColor =
                System.Drawing.Color.FromArgb(88, 86, 214);
            this.dgvVjezbe.ColumnHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.White;
            this.dgvVjezbe.ColumnHeadersDefaultCellStyle.Font      =
                new System.Drawing.Font("Segoe UI", 9f, System.Drawing.FontStyle.Bold);
            this.dgvVjezbe.DefaultCellStyle.Font      =
                new System.Drawing.Font("Segoe UI", 9.5f);
            this.dgvVjezbe.DefaultCellStyle.SelectionBackColor =
                System.Drawing.Color.FromArgb(88, 86, 214);
            this.dgvVjezbe.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.White;
            this.dgvVjezbe.AlternatingRowsDefaultCellStyle.BackColor =
                System.Drawing.Color.FromArgb(248, 249, 252);

            // Kolone
            this.colVjezba.HeaderText = "Vježba";
            this.colVjezba.Name       = "colVjezba";
            this.colVjezba.Width      = 280;

            this.colSerije.HeaderText = "Serije";
            this.colSerije.Name       = "colSerije";
            this.colSerije.Width      = 100;
            this.colSerije.DefaultCellStyle.Alignment =
                System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;

            this.colPonavljanja.HeaderText = "Ponavljanja";
            this.colPonavljanja.Name       = "colPonavljanja";
            this.colPonavljanja.Width      = 120;
            this.colPonavljanja.DefaultCellStyle.Alignment =
                System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;

            this.colKilaza.HeaderText = "Kilaza (max)";
            this.colKilaza.Name       = "colKilaza";
            this.colKilaza.Width      = 130;
            this.colKilaza.DefaultCellStyle.Alignment =
                System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;

            this.colVolumen.HeaderText = "Volumen (s×p×kg)";
            this.colVolumen.Name       = "colVolumen";
            this.colVolumen.Width      = 160;
            this.colVolumen.DefaultCellStyle.Alignment =
                System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;

            this.dgvVjezbe.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
                this.colVjezba, this.colSerije, this.colPonavljanja,
                this.colKilaza, this.colVolumen
            });

            // lblVjezbeUkupno
            this.lblVjezbeUkupno.Text      = "";
            this.lblVjezbeUkupno.Location  = new System.Drawing.Point(20, 540);
            this.lblVjezbeUkupno.Font      = new System.Drawing.Font("Segoe UI", 9f, System.Drawing.FontStyle.Bold);
            this.lblVjezbeUkupno.ForeColor = System.Drawing.Color.FromArgb(88, 86, 214);
            this.lblVjezbeUkupno.AutoSize  = true;

            // ── FrmDashboard ─────────────────────────────────────────────
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode       = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize          = new System.Drawing.Size(1020, 640);
            this.MinimumSize         = new System.Drawing.Size(1020, 640);
            this.FormBorderStyle     = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox         = false;
            this.StartPosition       = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text                = "FitTracker — Dashboard";
            this.BackColor           = System.Drawing.Color.FromArgb(245, 247, 250);
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.pnlNav);
            this.Controls.Add(this.pnlHeader);

            this.pnlHeader.ResumeLayout(false);
            this.pnlHeader.PerformLayout();
            this.pnlNav.ResumeLayout(false);
            this.pnlMain.ResumeLayout(false);
            this.pnlMain.PerformLayout();
            this.pnlUnos.ResumeLayout(false);
            this.pnlUnos.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVjezbe)).EndInit();
            this.ResumeLayout(false);

            this.Load += new System.EventHandler(this.FrmDashboard_Load);
        }

        #endregion

        private System.Windows.Forms.Panel    pnlHeader;
        private System.Windows.Forms.Label    lblNaslov;
        private System.Windows.Forms.Label    lblUsername;
        private System.Windows.Forms.Panel    pnlNav;
        private System.Windows.Forms.Button   btnVjezbe;
        private System.Windows.Forms.Button   btnProfil;
        private System.Windows.Forms.Panel    pnlMain;
        private System.Windows.Forms.Label    lblStatus;
        private System.Windows.Forms.Button   btnStartTrening;
        private System.Windows.Forms.Panel    pnlUnos;
        private System.Windows.Forms.Label    lblVjezbaLbl;
        private System.Windows.Forms.ComboBox cmbVjezba;
        private System.Windows.Forms.Label    lblSerijeLbl;
        private System.Windows.Forms.TextBox  txtSerije;
        private System.Windows.Forms.Label    lblPonavljanjaLbl;
        private System.Windows.Forms.TextBox  txtPonavljanja;
        private System.Windows.Forms.Label    lblKilazaLbl;
        private System.Windows.Forms.TextBox  txtKilaza;
        private System.Windows.Forms.Button   btnDodajVjezbu;
        private System.Windows.Forms.Button   btnUkloni;
        private System.Windows.Forms.DataGridView             dgvVjezbe;
        private System.Windows.Forms.DataGridViewTextBoxColumn colVjezba;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSerije;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPonavljanja;
        private System.Windows.Forms.DataGridViewTextBoxColumn colKilaza;
        private System.Windows.Forms.DataGridViewTextBoxColumn colVolumen;
        private System.Windows.Forms.Label    lblVjezbeUkupno;
    }
}
