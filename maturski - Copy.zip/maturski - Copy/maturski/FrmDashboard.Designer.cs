namespace WindowsFormsApplication1
{
    partial class FrmDashboard
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.pnlSidebar = new System.Windows.Forms.Panel();
            this.lblAppName = new System.Windows.Forms.Label();
            this.lblAppSub = new System.Windows.Forms.Label();
            this.pnlNavSep = new System.Windows.Forms.Panel();
            this.btnNavKorisnik = new System.Windows.Forms.Button();
            this.btnNavVjezbe = new System.Windows.Forms.Button();
            this.btnNavPlanovi = new System.Windows.Forms.Button();
            this.btnNavEvidencija = new System.Windows.Forms.Button();
            this.pnlContent = new System.Windows.Forms.Panel();
            this.lblPageTitle = new System.Windows.Forms.Label();
            this.lblUsername = new System.Windows.Forms.Label();
            this.pnlLeft = new System.Windows.Forms.Panel();
            this.lblOdaberiPlan = new System.Windows.Forms.Label();
            this.cmbPlan = new System.Windows.Forms.ComboBox();
            this.lblVjezbeUPlanu = new System.Windows.Forms.Label();
            this.dgvPlanVjezbe = new System.Windows.Forms.DataGridView();
            this.colPVNaziv = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPVTip = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPVGrupa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPVSetovi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlRight = new System.Windows.Forms.Panel();
            this.lblLogujTrening = new System.Windows.Forms.Label();
            this.lblLogSub = new System.Windows.Forms.Label();
            this.dgvLogVjezbe = new System.Windows.Forms.DataGridView();
            this.colLVjezba = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colLPlanirano = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colLSet1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colLSet2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colLSet3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colLPon = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colLGotovo = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.pnlBottomRight = new System.Windows.Forms.Panel();
            this.btnZapocniTrening = new System.Windows.Forms.Button();
            this.btnSpremiTrening = new System.Windows.Forms.Button();

            this.pnlSidebar.SuspendLayout();
            this.pnlContent.SuspendLayout();
            this.pnlLeft.SuspendLayout();
            this.pnlRight.SuspendLayout();
            this.pnlBottomRight.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPlanVjezbe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLogVjezbe)).BeginInit();
            this.SuspendLayout();

            // ── SIDEBAR ──────────────────────────────────────────────────
            this.pnlSidebar.BackColor = System.Drawing.Color.FromArgb(28, 25, 45);
            this.pnlSidebar.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlSidebar.Width = 200;
            this.pnlSidebar.Controls.AddRange(new System.Windows.Forms.Control[] {
                this.lblAppName, this.lblAppSub, this.pnlNavSep,
                this.btnNavKorisnik, this.btnNavVjezbe,
                this.btnNavPlanovi,  this.btnNavEvidencija });

            this.lblAppName.Text = "FitApp";
            this.lblAppName.Font = new System.Drawing.Font("Segoe UI", 15f, System.Drawing.FontStyle.Bold);
            this.lblAppName.ForeColor = System.Drawing.Color.White;
            this.lblAppName.Location = new System.Drawing.Point(0, 20);
            this.lblAppName.Size = new System.Drawing.Size(200, 34);
            this.lblAppName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            this.lblAppSub.Text = "Trening tracker";
            this.lblAppSub.Font = new System.Drawing.Font("Segoe UI", 7.5f);
            this.lblAppSub.ForeColor = System.Drawing.Color.FromArgb(140, 136, 180);
            this.lblAppSub.Location = new System.Drawing.Point(0, 52);
            this.lblAppSub.Size = new System.Drawing.Size(200, 18);
            this.lblAppSub.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            this.pnlNavSep.BackColor = System.Drawing.Color.FromArgb(55, 52, 80);
            this.pnlNavSep.Location = new System.Drawing.Point(14, 78);
            this.pnlNavSep.Size = new System.Drawing.Size(172, 1);

            // Nav button style helper
            System.Action<System.Windows.Forms.Button, string, int> styleNav =
                (btn, txt, y) =>
                {
                    btn.Text = txt;
                    btn.Location = new System.Drawing.Point(0, y);
                    btn.Size = new System.Drawing.Size(200, 48);
                    btn.Font = new System.Drawing.Font("Segoe UI", 9f);
                    btn.ForeColor = System.Drawing.Color.FromArgb(190, 186, 225);
                    btn.BackColor = System.Drawing.Color.Transparent;
                    btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
                    btn.FlatAppearance.BorderSize = 0;
                    btn.FlatAppearance.MouseOverBackColor =
                        System.Drawing.Color.FromArgb(50, 88, 86, 214);
                    btn.FlatAppearance.MouseDownBackColor =
                        System.Drawing.Color.FromArgb(80, 88, 86, 214);
                    btn.Cursor = System.Windows.Forms.Cursors.Hand;
                    btn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
                    btn.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
                };

            styleNav(this.btnNavKorisnik, "  Korisnik", 94);
            styleNav(this.btnNavVjezbe, "  Vjezbe", 146);
            styleNav(this.btnNavPlanovi, "  Planovi", 198);
            styleNav(this.btnNavEvidencija, "  Evidencija", 250);

            this.btnNavKorisnik.Click += new System.EventHandler(this.btnNavKorisnik_Click);
            this.btnNavVjezbe.Click += new System.EventHandler(this.btnNavVjezbe_Click);
            this.btnNavPlanovi.Click += new System.EventHandler(this.btnNavPlanovi_Click);
            this.btnNavEvidencija.Click += new System.EventHandler(this.btnNavEvidencija_Click);

            // ── CONTENT AREA ─────────────────────────────────────────────
            this.pnlContent.BackColor = System.Drawing.Color.FromArgb(240, 242, 248);
            this.pnlContent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlContent.Padding = new System.Windows.Forms.Padding(20, 16, 20, 16);
            this.pnlContent.Controls.AddRange(new System.Windows.Forms.Control[] {
                this.lblPageTitle, this.lblUsername,
                this.pnlLeft, this.pnlRight });

            this.lblPageTitle.Text = "Pocetna stranica";
            this.lblPageTitle.Font = new System.Drawing.Font("Segoe UI", 15f, System.Drawing.FontStyle.Bold);
            this.lblPageTitle.ForeColor = System.Drawing.Color.FromArgb(28, 25, 45);
            this.lblPageTitle.Location = new System.Drawing.Point(20, 14);
            this.lblPageTitle.AutoSize = true;

            this.lblUsername.Text = "Dobrodosli!";
            this.lblUsername.Font = new System.Drawing.Font("Segoe UI", 9f);
            this.lblUsername.ForeColor = System.Drawing.Color.FromArgb(120, 116, 160);
            this.lblUsername.Location = new System.Drawing.Point(22, 42);
            this.lblUsername.AutoSize = true;

            // ── LEFT PANEL ───────────────────────────────────────────────
            this.pnlLeft.BackColor = System.Drawing.Color.White;
            this.pnlLeft.Location = new System.Drawing.Point(20, 68);
            this.pnlLeft.Size = new System.Drawing.Size(390, 490);
            this.pnlLeft.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlLeft.Controls.AddRange(new System.Windows.Forms.Control[] {
                this.lblOdaberiPlan, this.cmbPlan,
                this.lblVjezbeUPlanu, this.dgvPlanVjezbe });

            this.lblOdaberiPlan.Text = "Odaberi plan za danas:";
            this.lblOdaberiPlan.Font = new System.Drawing.Font("Segoe UI", 9f, System.Drawing.FontStyle.Bold);
            this.lblOdaberiPlan.ForeColor = System.Drawing.Color.FromArgb(28, 25, 45);
            this.lblOdaberiPlan.Location = new System.Drawing.Point(12, 12);
            this.lblOdaberiPlan.AutoSize = true;

            this.cmbPlan.Font = new System.Drawing.Font("Segoe UI", 9.5f);
            this.cmbPlan.Location = new System.Drawing.Point(12, 32);
            this.cmbPlan.Size = new System.Drawing.Size(364, 25);
            this.cmbPlan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbPlan.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPlan.SelectedIndexChanged += new System.EventHandler(this.cmbPlan_SelectedIndexChanged);

            this.lblVjezbeUPlanu.Text = "Vjezbe u planu:";
            this.lblVjezbeUPlanu.Font = new System.Drawing.Font("Segoe UI", 8.5f, System.Drawing.FontStyle.Bold);
            this.lblVjezbeUPlanu.ForeColor = System.Drawing.Color.FromArgb(88, 86, 214);
            this.lblVjezbeUPlanu.Location = new System.Drawing.Point(12, 66);
            this.lblVjezbeUPlanu.AutoSize = true;

            this.dgvPlanVjezbe.Location = new System.Drawing.Point(12, 86);
            this.dgvPlanVjezbe.Size = new System.Drawing.Size(364, 394);
            this.dgvPlanVjezbe.ReadOnly = true;
            this.dgvPlanVjezbe.AllowUserToAddRows = false;
            this.dgvPlanVjezbe.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPlanVjezbe.AutoGenerateColumns = false;
            this.dgvPlanVjezbe.BackgroundColor = System.Drawing.Color.White;
            this.dgvPlanVjezbe.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvPlanVjezbe.RowHeadersVisible = false;
            this.dgvPlanVjezbe.EnableHeadersVisualStyles = false;
            this.dgvPlanVjezbe.ColumnHeadersHeight = 34;
            this.dgvPlanVjezbe.ColumnHeadersHeightSizeMode =
                System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvPlanVjezbe.RowTemplate.Height = 28;
            this.dgvPlanVjezbe.ColumnHeadersDefaultCellStyle.BackColor =
                System.Drawing.Color.FromArgb(28, 25, 45);
            this.dgvPlanVjezbe.ColumnHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.White;
            this.dgvPlanVjezbe.ColumnHeadersDefaultCellStyle.Font =
                new System.Drawing.Font("Segoe UI", 8.5f, System.Drawing.FontStyle.Bold);
            this.dgvPlanVjezbe.DefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9f);
            this.dgvPlanVjezbe.DefaultCellStyle.SelectionBackColor =
                System.Drawing.Color.FromArgb(88, 86, 214);
            this.dgvPlanVjezbe.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.White;
            this.dgvPlanVjezbe.AlternatingRowsDefaultCellStyle.BackColor =
                System.Drawing.Color.FromArgb(248, 248, 252);

            this.colPVNaziv.HeaderText = "Naziv vjezbe"; this.colPVNaziv.Name = "colPVNaziv"; this.colPVNaziv.Width = 155;
            this.colPVTip.HeaderText = "Tip"; this.colPVTip.Name = "colPVTip"; this.colPVTip.Width = 68;
            this.colPVGrupa.HeaderText = "Grupa"; this.colPVGrupa.Name = "colPVGrupa"; this.colPVGrupa.Width = 76;
            this.colPVSetovi.HeaderText = "Set x Rep."; this.colPVSetovi.Name = "colPVSetovi"; this.colPVSetovi.Width = 65;
            this.dgvPlanVjezbe.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
                this.colPVNaziv, this.colPVTip, this.colPVGrupa, this.colPVSetovi });

            // ── RIGHT PANEL ──────────────────────────────────────────────
            // pnlBottomRight je Dock=Bottom → automatski se lijepi na dno,
            // nema ručnog y-pozicioniranja i nema sjeckanja.
            this.pnlRight.BackColor = System.Drawing.Color.White;
            this.pnlRight.Location = new System.Drawing.Point(424, 68);
            this.pnlRight.Size = new System.Drawing.Size(530, 490);
            this.pnlRight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlRight.Controls.AddRange(new System.Windows.Forms.Control[] {
                this.lblLogujTrening, this.lblLogSub,
                this.dgvLogVjezbe, this.pnlBottomRight });

            this.lblLogujTrening.Text = "Logiraj danasnji trening:";
            this.lblLogujTrening.Font = new System.Drawing.Font("Segoe UI", 9f, System.Drawing.FontStyle.Bold);
            this.lblLogujTrening.ForeColor = System.Drawing.Color.FromArgb(28, 25, 45);
            this.lblLogujTrening.Location = new System.Drawing.Point(12, 12);
            this.lblLogujTrening.AutoSize = true;

            this.lblLogSub.Text = "Odaberite plan sa lijeve strane.";
            this.lblLogSub.Font = new System.Drawing.Font("Segoe UI", 8.5f);
            this.lblLogSub.ForeColor = System.Drawing.Color.FromArgb(120, 116, 160);
            this.lblLogSub.Location = new System.Drawing.Point(12, 32);
            this.lblLogSub.AutoSize = true;

            // Grid zauzima prostor iznad Dock=Bottom panela
            this.dgvLogVjezbe.Location = new System.Drawing.Point(12, 56);
            this.dgvLogVjezbe.Size = new System.Drawing.Size(504, 374);
            this.dgvLogVjezbe.AllowUserToAddRows = false;
            this.dgvLogVjezbe.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvLogVjezbe.AutoGenerateColumns = false;
            this.dgvLogVjezbe.BackgroundColor = System.Drawing.Color.White;
            this.dgvLogVjezbe.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvLogVjezbe.RowHeadersVisible = false;
            this.dgvLogVjezbe.EnableHeadersVisualStyles = false;
            this.dgvLogVjezbe.ColumnHeadersHeight = 34;
            this.dgvLogVjezbe.ColumnHeadersHeightSizeMode =
                System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvLogVjezbe.RowTemplate.Height = 30;
            this.dgvLogVjezbe.ColumnHeadersDefaultCellStyle.BackColor =
                System.Drawing.Color.FromArgb(28, 25, 45);
            this.dgvLogVjezbe.ColumnHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.White;
            this.dgvLogVjezbe.ColumnHeadersDefaultCellStyle.Font =
                new System.Drawing.Font("Segoe UI", 8.5f, System.Drawing.FontStyle.Bold);
            this.dgvLogVjezbe.DefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9f);
            this.dgvLogVjezbe.DefaultCellStyle.SelectionBackColor =
                System.Drawing.Color.FromArgb(88, 86, 214);
            this.dgvLogVjezbe.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.White;
            this.dgvLogVjezbe.AlternatingRowsDefaultCellStyle.BackColor =
                System.Drawing.Color.FromArgb(248, 248, 252);

            this.colLVjezba.HeaderText = "Vjezba"; this.colLVjezba.Name = "colLVjezba"; this.colLVjezba.Width = 130;
            this.colLPlanirano.HeaderText = "Planirano"; this.colLPlanirano.Name = "colLPlanirano"; this.colLPlanirano.Width = 70;
            this.colLSet1.HeaderText = "Set 1 (kg)"; this.colLSet1.Name = "colLSet1"; this.colLSet1.Width = 68;
            this.colLSet2.HeaderText = "Set 2 (kg)"; this.colLSet2.Name = "colLSet2"; this.colLSet2.Width = 68;
            this.colLSet3.HeaderText = "Set 3 (kg)"; this.colLSet3.Name = "colLSet3"; this.colLSet3.Width = 68;
            this.colLPon.HeaderText = "Pon./set"; this.colLPon.Name = "colLPon"; this.colLPon.Width = 58;
            this.colLGotovo.HeaderText = "OK"; this.colLGotovo.Name = "colLGotovo"; this.colLGotovo.Width = 42;
            this.dgvLogVjezbe.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
                this.colLVjezba, this.colLPlanirano,
                this.colLSet1, this.colLSet2, this.colLSet3,
                this.colLPon, this.colLGotovo });

            // ── BOTTOM BUTTON BAR — Dock = Bottom, nema sjeckanja ─────────
            this.pnlBottomRight.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottomRight.BackColor = System.Drawing.Color.FromArgb(240, 242, 248);
            this.pnlBottomRight.Height = 60;
            this.pnlBottomRight.Controls.AddRange(new System.Windows.Forms.Control[] {
                this.btnZapocniTrening, this.btnSpremiTrening });

            this.btnZapocniTrening.Text = "▶  Zapocni trening";
            this.btnZapocniTrening.Location = new System.Drawing.Point(10, 9);
            this.btnZapocniTrening.Size = new System.Drawing.Size(200, 42);
            this.btnZapocniTrening.Font = new System.Drawing.Font("Segoe UI", 9.5f, System.Drawing.FontStyle.Bold);
            this.btnZapocniTrening.BackColor = System.Drawing.Color.FromArgb(34, 139, 34);
            this.btnZapocniTrening.ForeColor = System.Drawing.Color.White;
            this.btnZapocniTrening.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnZapocniTrening.FlatAppearance.BorderSize = 0;
            this.btnZapocniTrening.FlatAppearance.MouseOverBackColor =
                System.Drawing.Color.FromArgb(40, 160, 40);
            this.btnZapocniTrening.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnZapocniTrening.Click += new System.EventHandler(this.btnZapocniTrening_Click);

            this.btnSpremiTrening.Text = "✔  Spremi trening";
            this.btnSpremiTrening.Location = new System.Drawing.Point(300, 9);
            this.btnSpremiTrening.Size = new System.Drawing.Size(200, 42);
            this.btnSpremiTrening.Font = new System.Drawing.Font("Segoe UI", 9.5f, System.Drawing.FontStyle.Bold);
            this.btnSpremiTrening.BackColor = System.Drawing.Color.FromArgb(88, 86, 214);
            this.btnSpremiTrening.ForeColor = System.Drawing.Color.White;
            this.btnSpremiTrening.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSpremiTrening.FlatAppearance.BorderSize = 0;
            this.btnSpremiTrening.FlatAppearance.MouseOverBackColor =
                System.Drawing.Color.FromArgb(100, 98, 230);
            this.btnSpremiTrening.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSpremiTrening.Click += new System.EventHandler(this.btnSpremiTrening_Click);

            // ── FORMA ─────────────────────────────────────────────────────
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1090, 590);
            this.MinimumSize = new System.Drawing.Size(1090, 590);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FitApp";
            this.BackColor = System.Drawing.Color.FromArgb(240, 242, 248);
            this.Controls.Add(this.pnlContent);
            this.Controls.Add(this.pnlSidebar);

            this.pnlSidebar.ResumeLayout(false);
            this.pnlSidebar.PerformLayout();
            this.pnlContent.ResumeLayout(false);
            this.pnlContent.PerformLayout();
            this.pnlLeft.ResumeLayout(false);
            this.pnlLeft.PerformLayout();
            this.pnlRight.ResumeLayout(false);
            this.pnlRight.PerformLayout();
            this.pnlBottomRight.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPlanVjezbe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLogVjezbe)).EndInit();
            this.ResumeLayout(false);

            this.Load += new System.EventHandler(this.FrmDashboard_Load);
        }

        #endregion

        private System.Windows.Forms.Panel pnlSidebar;
        private System.Windows.Forms.Label lblAppName;
        private System.Windows.Forms.Label lblAppSub;
        private System.Windows.Forms.Panel pnlNavSep;
        private System.Windows.Forms.Button btnNavKorisnik;
        private System.Windows.Forms.Button btnNavVjezbe;
        private System.Windows.Forms.Button btnNavPlanovi;
        private System.Windows.Forms.Button btnNavEvidencija;
        private System.Windows.Forms.Panel pnlContent;
        private System.Windows.Forms.Label lblPageTitle;
        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.Panel pnlLeft;
        private System.Windows.Forms.Label lblOdaberiPlan;
        private System.Windows.Forms.ComboBox cmbPlan;
        private System.Windows.Forms.Label lblVjezbeUPlanu;
        private System.Windows.Forms.DataGridView dgvPlanVjezbe;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPVNaziv;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPVTip;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPVGrupa;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPVSetovi;
        private System.Windows.Forms.Panel pnlRight;
        private System.Windows.Forms.Label lblLogujTrening;
        private System.Windows.Forms.Label lblLogSub;
        private System.Windows.Forms.DataGridView dgvLogVjezbe;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLVjezba;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLPlanirano;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLSet1;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLSet2;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLSet3;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLPon;
        private System.Windows.Forms.DataGridViewCheckBoxColumn colLGotovo;
        private System.Windows.Forms.Panel pnlBottomRight;
        private System.Windows.Forms.Button btnZapocniTrening;
        private System.Windows.Forms.Button btnSpremiTrening;
    }
}