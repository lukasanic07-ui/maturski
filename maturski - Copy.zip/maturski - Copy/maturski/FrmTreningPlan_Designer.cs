namespace WindowsFormsApplication1
{
    partial class FrmTreningPlan
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.pnlLijevo      = new System.Windows.Forms.Panel();
            this.lblPlanovi     = new System.Windows.Forms.Label();
            this.lstbPlanovi    = new System.Windows.Forms.ListBox();
            this.btnNoviPlan    = new System.Windows.Forms.Button();
            this.btnObrisiPlan  = new System.Windows.Forms.Button();
            this.pnlDesno       = new System.Windows.Forms.Panel();
            this.lblNaziv       = new System.Windows.Forms.Label();
            this.txtNazivPlana  = new System.Windows.Forms.TextBox();
            this.dgvVjezbeZaDan = new System.Windows.Forms.DataGridView();
            this.btnDodajVjezbu = new System.Windows.Forms.Button();
            this.btnObrisiVjezbu= new System.Windows.Forms.Button();
            this.btnSpremiPlan  = new System.Windows.Forms.Button();
            this.lblStatus      = new System.Windows.Forms.Label();
            this.pnlLijevo.SuspendLayout();
            this.pnlDesno.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVjezbeZaDan)).BeginInit();
            this.SuspendLayout();

            // pnlLijevo
            this.pnlLijevo.Controls.Add(this.lblPlanovi);
            this.pnlLijevo.Controls.Add(this.lstbPlanovi);
            this.pnlLijevo.Controls.Add(this.btnNoviPlan);
            this.pnlLijevo.Controls.Add(this.btnObrisiPlan);
            this.pnlLijevo.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlLijevo.Location = new System.Drawing.Point(0, 0);
            this.pnlLijevo.Name = "pnlLijevo";
            this.pnlLijevo.Size = new System.Drawing.Size(200, 530);
            this.pnlLijevo.TabIndex = 0;

            // lblPlanovi
            this.lblPlanovi.AutoSize = false;
            this.lblPlanovi.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblPlanovi.Location = new System.Drawing.Point(0, 0);
            this.lblPlanovi.Name = "lblPlanovi";
            this.lblPlanovi.Size = new System.Drawing.Size(200, 40);
            this.lblPlanovi.TabIndex = 0;
            this.lblPlanovi.Text = "  Moji planovi";
            this.lblPlanovi.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

            // lstbPlanovi
            this.lstbPlanovi.Location = new System.Drawing.Point(0, 40);
            this.lstbPlanovi.Name = "lstbPlanovi";
            this.lstbPlanovi.Size = new System.Drawing.Size(200, 390);
            this.lstbPlanovi.TabIndex = 1;
            this.lstbPlanovi.SelectedIndexChanged += new System.EventHandler(this.lstbPlanovi_SelectedIndexChanged);

            // btnNoviPlan
            this.btnNoviPlan.Location = new System.Drawing.Point(4, 440);
            this.btnNoviPlan.Name = "btnNoviPlan";
            this.btnNoviPlan.Size = new System.Drawing.Size(92, 34);
            this.btnNoviPlan.TabIndex = 2;
            this.btnNoviPlan.Text = "+ Novi plan";
            this.btnNoviPlan.Click += new System.EventHandler(this.btnNoviPlan_Click);

            // btnObrisiPlan
            this.btnObrisiPlan.Location = new System.Drawing.Point(102, 440);
            this.btnObrisiPlan.Name = "btnObrisiPlan";
            this.btnObrisiPlan.Size = new System.Drawing.Size(92, 34);
            this.btnObrisiPlan.TabIndex = 3;
            this.btnObrisiPlan.Text = "Obrisi plan";
            this.btnObrisiPlan.Click += new System.EventHandler(this.btnObrisiPlan_Click);

            // pnlDesno
            this.pnlDesno.Controls.Add(this.lblNaziv);
            this.pnlDesno.Controls.Add(this.txtNazivPlana);
            this.pnlDesno.Controls.Add(this.dgvVjezbeZaDan);
            this.pnlDesno.Controls.Add(this.btnDodajVjezbu);
            this.pnlDesno.Controls.Add(this.btnObrisiVjezbu);
            this.pnlDesno.Controls.Add(this.btnSpremiPlan);
            this.pnlDesno.Controls.Add(this.lblStatus);
            this.pnlDesno.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlDesno.Location = new System.Drawing.Point(200, 0);
            this.pnlDesno.Name = "pnlDesno";
            this.pnlDesno.Padding = new System.Windows.Forms.Padding(12);
            this.pnlDesno.Size = new System.Drawing.Size(680, 530);
            this.pnlDesno.TabIndex = 1;

            // lblNaziv
            this.lblNaziv.AutoSize = true;
            this.lblNaziv.Location = new System.Drawing.Point(12, 20);
            this.lblNaziv.Name = "lblNaziv";
            this.lblNaziv.Size = new System.Drawing.Size(45, 15);
            this.lblNaziv.TabIndex = 0;
            this.lblNaziv.Text = "Naziv plana:";

            // txtNazivPlana
            this.txtNazivPlana.Location = new System.Drawing.Point(110, 17);
            this.txtNazivPlana.Name = "txtNazivPlana";
            this.txtNazivPlana.Size = new System.Drawing.Size(280, 22);
            this.txtNazivPlana.TabIndex = 1;

            // dgvVjezbeZaDan
            this.dgvVjezbeZaDan.Location = new System.Drawing.Point(12, 55);
            this.dgvVjezbeZaDan.Name = "dgvVjezbeZaDan";
            this.dgvVjezbeZaDan.Size = new System.Drawing.Size(648, 380);
            this.dgvVjezbeZaDan.TabIndex = 2;
            this.dgvVjezbeZaDan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;

            // btnDodajVjezbu
            this.btnDodajVjezbu.Location = new System.Drawing.Point(12, 448);
            this.btnDodajVjezbu.Name = "btnDodajVjezbu";
            this.btnDodajVjezbu.Size = new System.Drawing.Size(120, 34);
            this.btnDodajVjezbu.TabIndex = 3;
            this.btnDodajVjezbu.Text = "+ Dodaj vjezbu";
            this.btnDodajVjezbu.Click += new System.EventHandler(this.btnDodajVjezbu_Click);

            // btnObrisiVjezbu
            this.btnObrisiVjezbu.Location = new System.Drawing.Point(142, 448);
            this.btnObrisiVjezbu.Name = "btnObrisiVjezbu";
            this.btnObrisiVjezbu.Size = new System.Drawing.Size(120, 34);
            this.btnObrisiVjezbu.TabIndex = 4;
            this.btnObrisiVjezbu.Text = "Obrisi vjezbu";
            this.btnObrisiVjezbu.Click += new System.EventHandler(this.btnObrisiVjezbu_Click);

            // btnSpremiPlan
            this.btnSpremiPlan.Location = new System.Drawing.Point(540, 448);
            this.btnSpremiPlan.Name = "btnSpremiPlan";
            this.btnSpremiPlan.Size = new System.Drawing.Size(120, 34);
            this.btnSpremiPlan.TabIndex = 5;
            this.btnSpremiPlan.Text = "Spremi plan";
            this.btnSpremiPlan.Click += new System.EventHandler(this.btnSpremiPlan_Click);

            // lblStatus
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(12, 490);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(300, 13);
            this.lblStatus.TabIndex = 6;
            this.lblStatus.Text = "Odaberite plan sa lijeve strane ili kreirajte novi.";

            // FrmTreningPlan
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(880, 530);
            this.Controls.Add(this.pnlDesno);
            this.Controls.Add(this.pnlLijevo);
            this.Name = "FrmTreningPlan";
            this.Text = "Trening Planovi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.FrmTreningPlan_Load);
            this.pnlLijevo.ResumeLayout(false);
            this.pnlDesno.ResumeLayout(false);
            this.pnlDesno.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVjezbeZaDan)).EndInit();
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Panel   pnlLijevo;
        private System.Windows.Forms.Label   lblPlanovi;
        private System.Windows.Forms.ListBox lstbPlanovi;
        private System.Windows.Forms.Button  btnNoviPlan;
        private System.Windows.Forms.Button  btnObrisiPlan;
        private System.Windows.Forms.Panel   pnlDesno;
        private System.Windows.Forms.Label   lblNaziv;
        private System.Windows.Forms.TextBox txtNazivPlana;
        private System.Windows.Forms.DataGridView dgvVjezbeZaDan;
        private System.Windows.Forms.Button  btnDodajVjezbu;
        private System.Windows.Forms.Button  btnObrisiVjezbu;
        private System.Windows.Forms.Button  btnSpremiPlan;
        private System.Windows.Forms.Label   lblStatus;
    }
}
