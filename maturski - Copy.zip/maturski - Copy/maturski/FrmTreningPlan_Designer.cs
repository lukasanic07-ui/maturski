namespace WindowsFormsApplication1
{
    partial class FrmTreningPlan
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.pnlLijevo       = new System.Windows.Forms.Panel();
            this.pnlLogoArea     = new System.Windows.Forms.Panel();
            this.lblLogo         = new System.Windows.Forms.Label();
            this.lblPlanovi      = new System.Windows.Forms.Label();
            this.lstbPlanovi     = new System.Windows.Forms.ListBox();
            this.pnlPlanBtns     = new System.Windows.Forms.Panel();
            this.btnNoviPlan     = new System.Windows.Forms.Button();
            this.btnObrisiPlan   = new System.Windows.Forms.Button();
            this.pnlDesno        = new System.Windows.Forms.Panel();
            this.pnlDesnoTop     = new System.Windows.Forms.Panel();
            this.lblNaziv        = new System.Windows.Forms.Label();
            this.txtNazivPlana   = new System.Windows.Forms.TextBox();
            this.pnlTipFilteri   = new System.Windows.Forms.Panel();
            this.lblFilterSnaga  = new System.Windows.Forms.Label();
            this.lblFilterKardio = new System.Windows.Forms.Label();
            this.lblFilterMob    = new System.Windows.Forms.Label();
            this.lblFilterIzdrz  = new System.Windows.Forms.Label();
            this.dgvVjezbeZaDan  = new System.Windows.Forms.DataGridView();
            this.colTip          = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNazivVjezbe  = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMisicnaGrupa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSetovi       = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPonavljanja  = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlDesnoBottom  = new System.Windows.Forms.Panel();
            this.btnDodajVjezbu  = new System.Windows.Forms.Button();
            this.btnObrisiVjezbu = new System.Windows.Forms.Button();
            this.btnSpremiPlan   = new System.Windows.Forms.Button();
            this.lblStatus       = new System.Windows.Forms.Label();

            this.pnlLijevo.SuspendLayout();
            this.pnlLogoArea.SuspendLayout();
            this.pnlPlanBtns.SuspendLayout();
            this.pnlDesno.SuspendLayout();
            this.pnlDesnoTop.SuspendLayout();
            this.pnlTipFilteri.SuspendLayout();
            this.pnlDesnoBottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVjezbeZaDan)).BeginInit();
            this.SuspendLayout();

            // ── LEFT SIDEBAR ─────────────────────────────────────────────
            this.pnlLijevo.BackColor = System.Drawing.Color.FromArgb(28, 25, 45);
            this.pnlLijevo.Dock      = System.Windows.Forms.DockStyle.Left;
            this.pnlLijevo.Width     = 220;
            this.pnlLijevo.Controls.AddRange(new System.Windows.Forms.Control[] {
                this.pnlLogoArea, this.lblPlanovi, this.lstbPlanovi, this.pnlPlanBtns });

            // Logo area
            this.pnlLogoArea.BackColor = System.Drawing.Color.FromArgb(34, 31, 53);
            this.pnlLogoArea.Dock      = System.Windows.Forms.DockStyle.Top;
            this.pnlLogoArea.Height    = 90;
            this.pnlLogoArea.Controls.Add(this.lblLogo);

            this.lblLogo.Text      = "🏋 Moji planovi";
            this.lblLogo.Font      = new System.Drawing.Font("Segoe UI", 11f, System.Drawing.FontStyle.Bold);
            this.lblLogo.ForeColor = System.Drawing.Color.White;
            this.lblLogo.Dock      = System.Windows.Forms.DockStyle.Fill;
            this.lblLogo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // "Moji planovi" label under logo
            this.lblPlanovi.AutoSize  = false;
            this.lblPlanovi.Location  = new System.Drawing.Point(0, 90);
            this.lblPlanovi.Size      = new System.Drawing.Size(220, 0); // zero height - label merged into logo
            this.lblPlanovi.Visible   = false; // merged above

            // List box
            this.lstbPlanovi.BackColor    = System.Drawing.Color.FromArgb(40, 37, 62);
            this.lstbPlanovi.BorderStyle  = System.Windows.Forms.BorderStyle.None;
            this.lstbPlanovi.Font         = new System.Drawing.Font("Segoe UI", 9.5f);
            this.lstbPlanovi.ForeColor    = System.Drawing.Color.FromArgb(200, 196, 230);
            this.lstbPlanovi.ItemHeight   = 28;
            this.lstbPlanovi.Location     = new System.Drawing.Point(0, 90);
            this.lstbPlanovi.Size         = new System.Drawing.Size(220, 400);
            this.lstbPlanovi.DrawMode     = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.lstbPlanovi.DrawItem    += new System.Windows.Forms.DrawItemEventHandler(this.lstbPlanovi_DrawItem);
            this.lstbPlanovi.SelectedIndexChanged += new System.EventHandler(this.lstbPlanovi_SelectedIndexChanged);

            // Bottom buttons
            this.pnlPlanBtns.BackColor = System.Drawing.Color.FromArgb(28, 25, 45);
            this.pnlPlanBtns.Location  = new System.Drawing.Point(0, 492);
            this.pnlPlanBtns.Size      = new System.Drawing.Size(220, 48);
            this.pnlPlanBtns.Controls.AddRange(new System.Windows.Forms.Control[] {
                this.btnNoviPlan, this.btnObrisiPlan });

            this.btnNoviPlan.Text      = "+ Novi plan";
            this.btnNoviPlan.Location  = new System.Drawing.Point(8, 6);
            this.btnNoviPlan.Size      = new System.Drawing.Size(96, 36);
            this.btnNoviPlan.Font      = new System.Drawing.Font("Segoe UI", 8.5f, System.Drawing.FontStyle.Bold);
            this.btnNoviPlan.ForeColor = System.Drawing.Color.White;
            this.btnNoviPlan.BackColor = System.Drawing.Color.FromArgb(88, 86, 214);
            this.btnNoviPlan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNoviPlan.FlatAppearance.BorderSize = 0;
            this.btnNoviPlan.Cursor    = System.Windows.Forms.Cursors.Hand;
            this.btnNoviPlan.Click    += new System.EventHandler(this.btnNoviPlan_Click);

            this.btnObrisiPlan.Text      = "🗑 Obriši";
            this.btnObrisiPlan.Location  = new System.Drawing.Point(112, 6);
            this.btnObrisiPlan.Size      = new System.Drawing.Size(100, 36);
            this.btnObrisiPlan.Font      = new System.Drawing.Font("Segoe UI", 8.5f, System.Drawing.FontStyle.Bold);
            this.btnObrisiPlan.ForeColor = System.Drawing.Color.White;
            this.btnObrisiPlan.BackColor = System.Drawing.Color.FromArgb(180, 50, 50);
            this.btnObrisiPlan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnObrisiPlan.FlatAppearance.BorderSize = 0;
            this.btnObrisiPlan.Cursor    = System.Windows.Forms.Cursors.Hand;
            this.btnObrisiPlan.Click    += new System.EventHandler(this.btnObrisiPlan_Click);

            // ── RIGHT PANEL ──────────────────────────────────────────────
            this.pnlDesno.BackColor = System.Drawing.Color.FromArgb(245, 247, 252);
            this.pnlDesno.Dock      = System.Windows.Forms.DockStyle.Fill;
            this.pnlDesno.Controls.AddRange(new System.Windows.Forms.Control[] {
                this.pnlDesnoTop, this.dgvVjezbeZaDan, this.pnlDesnoBottom });

            // Top bar (naziv + filter ikone)
            this.pnlDesnoTop.BackColor = System.Drawing.Color.White;
            this.pnlDesnoTop.Dock      = System.Windows.Forms.DockStyle.Top;
            this.pnlDesnoTop.Height    = 52;
            this.pnlDesnoTop.Padding   = new System.Windows.Forms.Padding(12, 0, 12, 0);
            this.pnlDesnoTop.Controls.AddRange(new System.Windows.Forms.Control[] {
                this.lblNaziv, this.txtNazivPlana, this.pnlTipFilteri });

            this.lblNaziv.Text      = "Naziv:";
            this.lblNaziv.Font      = new System.Drawing.Font("Segoe UI", 9f, System.Drawing.FontStyle.Bold);
            this.lblNaziv.ForeColor = System.Drawing.Color.FromArgb(88, 86, 214);
            this.lblNaziv.Location  = new System.Drawing.Point(12, 16);
            this.lblNaziv.AutoSize  = true;

            this.txtNazivPlana.Font     = new System.Drawing.Font("Segoe UI", 10f);
            this.txtNazivPlana.Location = new System.Drawing.Point(60, 13);
            this.txtNazivPlana.Size     = new System.Drawing.Size(260, 25);
            this.txtNazivPlana.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;

            // Tip filter badges (top right)
            this.pnlTipFilteri.BackColor = System.Drawing.Color.Transparent;
            this.pnlTipFilteri.Location  = new System.Drawing.Point(340, 10);
            this.pnlTipFilteri.Size      = new System.Drawing.Size(500, 32);
            this.pnlTipFilteri.Controls.AddRange(new System.Windows.Forms.Control[] {
                this.lblFilterSnaga, this.lblFilterKardio, this.lblFilterMob, this.lblFilterIzdrz });

            System.Action<System.Windows.Forms.Label, string, int, System.Drawing.Color> styleBadge =
                (lbl, txt, x, col) => {
                    lbl.Text      = txt;
                    lbl.Font      = new System.Drawing.Font("Segoe UI", 8f, System.Drawing.FontStyle.Bold);
                    lbl.ForeColor = col;
                    lbl.Location  = new System.Drawing.Point(x, 6);
                    lbl.AutoSize  = true;
                    lbl.Cursor    = System.Windows.Forms.Cursors.Hand;
                };

            styleBadge(this.lblFilterSnaga,  "✖ Snaga",      0,   System.Drawing.Color.FromArgb(180, 50, 50));
            styleBadge(this.lblFilterKardio, "⬅ Kardio",    80,   System.Drawing.Color.FromArgb(34, 139, 34));
            styleBadge(this.lblFilterMob,    "⬅ Mobilnost", 165,  System.Drawing.Color.FromArgb(88, 86, 214));
            styleBadge(this.lblFilterIzdrz,  "⬅ Izdrzljivost",265, System.Drawing.Color.FromArgb(200, 130, 0));

            // DataGridView
            this.dgvVjezbeZaDan.BackgroundColor = System.Drawing.Color.White;
            this.dgvVjezbeZaDan.Dock            = System.Windows.Forms.DockStyle.Fill;
            this.dgvVjezbeZaDan.AllowUserToAddRows = false;
            this.dgvVjezbeZaDan.SelectionMode   = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvVjezbeZaDan.AutoGenerateColumns = false;
            this.dgvVjezbeZaDan.BorderStyle     = System.Windows.Forms.BorderStyle.None;
            this.dgvVjezbeZaDan.RowHeadersVisible = false;
            this.dgvVjezbeZaDan.EnableHeadersVisualStyles = false;
            this.dgvVjezbeZaDan.ColumnHeadersHeight = 38;
            this.dgvVjezbeZaDan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvVjezbeZaDan.RowTemplate.Height = 30;
            this.dgvVjezbeZaDan.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(34, 31, 53);
            this.dgvVjezbeZaDan.ColumnHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.White;
            this.dgvVjezbeZaDan.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9f, System.Drawing.FontStyle.Bold);
            this.dgvVjezbeZaDan.DefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9f);
            this.dgvVjezbeZaDan.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(88, 86, 214);
            this.dgvVjezbeZaDan.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.White;
            this.dgvVjezbeZaDan.AlternatingRowsDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(248, 248, 252);

            this.colTip.HeaderText         = "Tip";           this.colTip.Name         = "colTip";         this.colTip.Width         = 90;
            this.colNazivVjezbe.HeaderText = "Naziv vježbe";  this.colNazivVjezbe.Name = "colNazivVjezbe"; this.colNazivVjezbe.Width = 200;
            this.colMisicnaGrupa.HeaderText= "Mišićna grupa"; this.colMisicnaGrupa.Name= "colMisicnaGrupa";this.colMisicnaGrupa.Width= 130;
            this.colSetovi.HeaderText      = "Setovi";        this.colSetovi.Name      = "colSetovi";       this.colSetovi.Width      = 70;
            this.colPonavljanja.HeaderText = "Ponavljanja";   this.colPonavljanja.Name = "colPonavljanja";  this.colPonavljanja.Width = 90;
            this.dgvVjezbeZaDan.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
                this.colTip, this.colNazivVjezbe, this.colMisicnaGrupa, this.colSetovi, this.colPonavljanja });

            // Bottom action bar
            this.pnlDesnoBottom.BackColor = System.Drawing.Color.White;
            this.pnlDesnoBottom.Dock      = System.Windows.Forms.DockStyle.Bottom;
            this.pnlDesnoBottom.Height    = 68;
            this.pnlDesnoBottom.Controls.AddRange(new System.Windows.Forms.Control[] {
                this.btnDodajVjezbu, this.btnObrisiVjezbu, this.btnSpremiPlan, this.lblStatus });

            this.btnDodajVjezbu.Text      = "+ Dodaj vježbu";
            this.btnDodajVjezbu.Location  = new System.Drawing.Point(14, 14);
            this.btnDodajVjezbu.Size      = new System.Drawing.Size(168, 40);
            this.btnDodajVjezbu.Font      = new System.Drawing.Font("Segoe UI", 9.5f, System.Drawing.FontStyle.Bold);
            this.btnDodajVjezbu.ForeColor = System.Drawing.Color.White;
            this.btnDodajVjezbu.BackColor = System.Drawing.Color.FromArgb(34, 139, 34);
            this.btnDodajVjezbu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDodajVjezbu.FlatAppearance.BorderSize = 0;
            this.btnDodajVjezbu.Cursor    = System.Windows.Forms.Cursors.Hand;
            this.btnDodajVjezbu.Click    += new System.EventHandler(this.btnDodajVjezbu_Click);

            this.btnObrisiVjezbu.Text      = "🗑 Obriši vježbu";
            this.btnObrisiVjezbu.Location  = new System.Drawing.Point(190, 14);
            this.btnObrisiVjezbu.Size      = new System.Drawing.Size(168, 40);
            this.btnObrisiVjezbu.Font      = new System.Drawing.Font("Segoe UI", 9.5f, System.Drawing.FontStyle.Bold);
            this.btnObrisiVjezbu.ForeColor = System.Drawing.Color.White;
            this.btnObrisiVjezbu.BackColor = System.Drawing.Color.FromArgb(180, 50, 50);
            this.btnObrisiVjezbu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnObrisiVjezbu.FlatAppearance.BorderSize = 0;
            this.btnObrisiVjezbu.Cursor    = System.Windows.Forms.Cursors.Hand;
            this.btnObrisiVjezbu.Click    += new System.EventHandler(this.btnObrisiVjezbu_Click);

            this.btnSpremiPlan.Text      = "🖫 Spremi plan";
            this.btnSpremiPlan.Location  = new System.Drawing.Point(490, 14);
            this.btnSpremiPlan.Size      = new System.Drawing.Size(168, 40);
            this.btnSpremiPlan.Font      = new System.Drawing.Font("Segoe UI", 9.5f, System.Drawing.FontStyle.Bold);
            this.btnSpremiPlan.ForeColor = System.Drawing.Color.White;
            this.btnSpremiPlan.BackColor = System.Drawing.Color.FromArgb(88, 86, 214);
            this.btnSpremiPlan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSpremiPlan.FlatAppearance.BorderSize = 0;
            this.btnSpremiPlan.Cursor    = System.Windows.Forms.Cursors.Hand;
            this.btnSpremiPlan.Click    += new System.EventHandler(this.btnSpremiPlan_Click);

            this.lblStatus.AutoSize  = true;
            this.lblStatus.Font      = new System.Drawing.Font("Segoe UI", 8.5f, System.Drawing.FontStyle.Italic);
            this.lblStatus.ForeColor = System.Drawing.Color.Gray;
            this.lblStatus.Location  = new System.Drawing.Point(14, 56);
            this.lblStatus.Text      = "Odaberite plan sa lijeve strane ili kreirajte novi.";

            // ── FrmTreningPlan ────────────────────────────────────────────
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode       = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize          = new System.Drawing.Size(960, 560);
            this.MinimumSize         = new System.Drawing.Size(960, 560);
            this.StartPosition       = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text                = "Trening Planovi";
            this.BackColor           = System.Drawing.Color.FromArgb(245, 247, 252);
            this.Controls.Add(this.pnlDesno);
            this.Controls.Add(this.pnlLijevo);

            this.pnlLijevo.ResumeLayout(false);
            this.pnlLogoArea.ResumeLayout(false);
            this.pnlPlanBtns.ResumeLayout(false);
            this.pnlDesno.ResumeLayout(false);
            this.pnlDesnoTop.ResumeLayout(false);
            this.pnlDesnoTop.PerformLayout();
            this.pnlTipFilteri.ResumeLayout(false);
            this.pnlTipFilteri.PerformLayout();
            this.pnlDesnoBottom.ResumeLayout(false);
            this.pnlDesnoBottom.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVjezbeZaDan)).EndInit();
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Panel    pnlLijevo;
        private System.Windows.Forms.Panel    pnlLogoArea;
        private System.Windows.Forms.Label    lblLogo;
        private System.Windows.Forms.Label    lblPlanovi;
        private System.Windows.Forms.ListBox  lstbPlanovi;
        private System.Windows.Forms.Panel    pnlPlanBtns;
        private System.Windows.Forms.Button   btnNoviPlan;
        private System.Windows.Forms.Button   btnObrisiPlan;
        private System.Windows.Forms.Panel    pnlDesno;
        private System.Windows.Forms.Panel    pnlDesnoTop;
        private System.Windows.Forms.Label    lblNaziv;
        private System.Windows.Forms.TextBox  txtNazivPlana;
        private System.Windows.Forms.Panel    pnlTipFilteri;
        private System.Windows.Forms.Label    lblFilterSnaga;
        private System.Windows.Forms.Label    lblFilterKardio;
        private System.Windows.Forms.Label    lblFilterMob;
        private System.Windows.Forms.Label    lblFilterIzdrz;
        private System.Windows.Forms.DataGridView dgvVjezbeZaDan;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTip;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNazivVjezbe;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMisicnaGrupa;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSetovi;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPonavljanja;
        private System.Windows.Forms.Panel    pnlDesnoBottom;
        private System.Windows.Forms.Button   btnDodajVjezbu;
        private System.Windows.Forms.Button   btnObrisiVjezbu;
        private System.Windows.Forms.Button   btnSpremiPlan;
        private System.Windows.Forms.Label    lblStatus;
    }
}
