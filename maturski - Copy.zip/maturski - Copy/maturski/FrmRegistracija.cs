using System;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApplication1
{
    public partial class FrmRegistracija : Form
    {
        public FrmRegistracija()
        {
            InitializeComponent();
        }

      
        private string HashSHA256(string input)
        {
            using (System.Security.Cryptography.SHA256 sha = System.Security.Cryptography.SHA256.Create())
            {
                byte[] bytes = sha.ComputeHash(System.Text.Encoding.UTF8.GetBytes(input));
                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                foreach (byte b in bytes)
                    sb.Append(b.ToString("x2"));
                return sb.ToString();
            }
        }

        private void btnRegistruj_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string lozinka  = txtLozinka.Text;
            string potvrda  = txtPotvrdaLozinke.Text;
            string ime      = txtIme.Text.Trim();
            string prezime  = txtPrezime.Text.Trim();

            
            if (username == "" || lozinka == "")
            {
                MessageBox.Show("Username i lozinka su obavezni!", "Greška",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (lozinka != potvrda)
            {
                MessageBox.Show("Lozinke se ne poklapaju!", "Greška",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPotvrdaLozinke.Clear();
                txtPotvrdaLozinke.Focus();
                return;
            }

            if (lozinka.Length < 6)
            {
                MessageBox.Show("Lozinka mora imati najmanje 6 karaktera!", "Greška",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int?    godine = null;
            double? tezina = null;
            double? visina = null;

            if (txtGodine.Text.Trim() != "")
            {
                int g;
                if (!int.TryParse(txtGodine.Text.Trim(), out g) || g < 1 || g > 120)
                {
                    MessageBox.Show("Godine moraju biti broj između 1 i 120!", "Greška",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtGodine.Focus();
                    return;
                }
                godine = g;
            }

            if (txtTezina.Text.Trim() != "")
            {
                double t;
                if (!double.TryParse(txtTezina.Text.Trim().Replace(",", "."),
                    System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture, out t)
                    || t < 1 || t > 500)
                {
                    MessageBox.Show("Težina mora biti broj (npr. 75.5)!", "Greška",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtTezina.Focus();
                    return;
                }
                tezina = t;
            }

            if (txtVisina.Text.Trim() != "")
            {
                double v;
                if (!double.TryParse(txtVisina.Text.Trim().Replace(",", "."),
                    System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture, out v)
                    || v < 50 || v > 300)
                {
                    MessageBox.Show("Visina mora biti broj (npr. 180.0)!", "Greška",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtVisina.Focus();
                    return;
                }
                visina = v;
            }

            // postoji li username 
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                {
                    using (MySqlCommand chk = new MySqlCommand(
                        "SELECT COUNT(*) FROM korisnik WHERE Username=@u", conn))
                    {
                        chk.Parameters.AddWithValue("@u", username);
                        int cnt = Convert.ToInt32(chk.ExecuteScalar());
                        if (cnt > 0)
                        {
                            MessageBox.Show("Taj username je već zauzet!", "Greška",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            txtUsername.Focus();
                            return;
                        }
                    }

                    string sql = "INSERT INTO korisnik (Username, PasswordHash, Ime, Prezime, " +
                                 "Godine, Tezina, Visina) " +
                                 "VALUES (@u, @l, @ime, @prez, @god, @tez, @vis)";

                    using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@u",    username);
                        cmd.Parameters.AddWithValue("@l",    HashSHA256(lozinka));
                        cmd.Parameters.AddWithValue("@ime",  ime);
                        cmd.Parameters.AddWithValue("@prez", prezime);
                        cmd.Parameters.AddWithValue("@god",  (object)godine ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@tez",  (object)tezina ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@vis",  (object)visina ?? DBNull.Value);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Registracija uspješna! Možete se prijaviti.", "Dobrodošli",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška pri registraciji: " + ex.Message, "Greška",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnOtkazi_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        // Hover 
        private void BtnHoverEnter(object sender, EventArgs e)
        {
            var b = sender as System.Windows.Forms.Button;
            if (b != null && b.Name == "btnRegistruj")
                b.BackColor = System.Drawing.Color.FromArgb(70, 68, 190);
        }

        private void BtnHoverLeave(object sender, EventArgs e)
        {
            var b = sender as System.Windows.Forms.Button;
            if (b != null && b.Name == "btnRegistruj")
                b.BackColor = System.Drawing.Color.FromArgb(88, 86, 214);
        }

        private void FrmRegistracija_Load(object sender, EventArgs e)
        {

        }
    }
}
