namespace WindowsFormsApplication1
{
    partial class FrmLogin
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.pnlLijevo      = new System.Windows.Forms.Panel();
            this.lblLogo        = new System.Windows.Forms.Label();
            this.lblWelcome     = new System.Windows.Forms.Label();
            this.pnlDesno       = new System.Windows.Forms.Panel();
            this.lblNaslov      = new System.Windows.Forms.Label();
            this.label1         = new System.Windows.Forms.Label();
            this.txtUsername    = new System.Windows.Forms.TextBox();
            this.label2         = new System.Windows.Forms.Label();
            this.txtLozinka     = new System.Windows.Forms.TextBox();
            this.lblStatus      = new System.Windows.Forms.Label();
            this.btnLogin       = new System.Windows.Forms.Button();
            this.pnlLinija      = new System.Windows.Forms.Panel();
            this.lblNemaAcc     = new System.Windows.Forms.Label();
            this.btnRegistracija = new System.Windows.Forms.Button();
            this.pnlLijevo.SuspendLayout();
            this.pnlDesno.SuspendLayout();
            this.SuspendLayout();

            // ── pnlLijevo ────────────────────────────────────────────────
            this.pnlLijevo.BackColor = System.Drawing.Color.FromArgb(30, 58, 95);
            this.pnlLijevo.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlLijevo.Width = 200;
            this.pnlLijevo.Name = "pnlLijevo";
            this.pnlLijevo.TabIndex = 0;
            this.pnlLijevo.Controls.Add(this.lblLogo);
            this.pnlLijevo.Controls.Add(this.lblWelcome);

            this.lblLogo.AutoSize = false;
            this.lblLogo.Font = new System.Drawing.Font("Segoe UI", 36F, System.Drawing.FontStyle.Bold);
            this.lblLogo.ForeColor = System.Drawing.Color.White;
            this.lblLogo.Location = new System.Drawing.Point(0, 100);
            this.lblLogo.Name = "lblLogo";
            this.lblLogo.Size = new System.Drawing.Size(200, 70);
            this.lblLogo.Text = "FitApp";
            this.lblLogo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            this.lblWelcome.AutoSize = false;
            this.lblWelcome.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblWelcome.ForeColor = System.Drawing.Color.FromArgb(160, 190, 220);
            this.lblWelcome.Location = new System.Drawing.Point(10, 170);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(180, 40);
            this.lblWelcome.Text = "Tvoj personalni trening asistent";
            this.lblWelcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // ── pnlDesno ─────────────────────────────────────────────────
            this.pnlDesno.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlDesno.BackColor = System.Drawing.Color.White;
            this.pnlDesno.Name = "pnlDesno";
            this.pnlDesno.TabIndex = 1;
            this.pnlDesno.Controls.Add(this.lblNaslov);
            this.pnlDesno.Controls.Add(this.label1);
            this.pnlDesno.Controls.Add(this.txtUsername);
            this.pnlDesno.Controls.Add(this.label2);
            this.pnlDesno.Controls.Add(this.txtLozinka);
            this.pnlDesno.Controls.Add(this.lblStatus);
            this.pnlDesno.Controls.Add(this.btnLogin);
            this.pnlDesno.Controls.Add(this.pnlLinija);
            this.pnlDesno.Controls.Add(this.lblNemaAcc);
            this.pnlDesno.Controls.Add(this.btnRegistracija);

            int rx = 40, rw = 240;

            this.lblNaslov.AutoSize = true;
            this.lblNaslov.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblNaslov.ForeColor = System.Drawing.Color.FromArgb(30, 58, 95);
            this.lblNaslov.Location = new System.Drawing.Point(rx, 50);
            this.lblNaslov.Name = "lblNaslov";
            this.lblNaslov.Text = "Dobrodosli";
            this.lblNaslov.TabIndex = 0;

            // label1 "Username"
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(70, 80, 100);
            this.label1.Location = new System.Drawing.Point(rx, 110);
            this.label1.Name = "label1";
            this.label1.Text = "Username";
            this.label1.TabIndex = 1;

            this.txtUsername.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUsername.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.txtUsername.Location = new System.Drawing.Point(rx, 128);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(rw, 28);
            this.txtUsername.TabIndex = 0;

            // label2 "Lozinka"
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(70, 80, 100);
            this.label2.Location = new System.Drawing.Point(rx, 166);
            this.label2.Name = "label2";
            this.label2.Text = "Lozinka";
            this.label2.TabIndex = 2;

            this.txtLozinka.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtLozinka.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.txtLozinka.Location = new System.Drawing.Point(rx, 184);
            this.txtLozinka.Name = "txtLozinka";
            this.txtLozinka.Size = new System.Drawing.Size(rw, 28);
            this.txtLozinka.TabIndex = 1;

            // lblStatus
            this.lblStatus.AutoSize = false;
            this.lblStatus.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblStatus.ForeColor = System.Drawing.Color.FromArgb(220, 53, 69);
            this.lblStatus.Location = new System.Drawing.Point(rx, 220);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(rw, 16);
            this.lblStatus.Text = "";
            this.lblStatus.TabIndex = 3;

            // btnLogin
            this.btnLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogin.FlatAppearance.BorderSize = 0;
            this.btnLogin.BackColor = System.Drawing.Color.FromArgb(30, 58, 95);
            this.btnLogin.ForeColor = System.Drawing.Color.White;
            this.btnLogin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLogin.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnLogin.Location = new System.Drawing.Point(rx, 242);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(rw, 42);
            this.btnLogin.TabIndex = 2;
            this.btnLogin.Text = "Prijava";
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);

            // pnlLinija
            this.pnlLinija.BackColor = System.Drawing.Color.FromArgb(225, 228, 235);
            this.pnlLinija.Location = new System.Drawing.Point(rx, 294);
            this.pnlLinija.Name = "pnlLinija";
            this.pnlLinija.Size = new System.Drawing.Size(rw, 1);

            // lblNemaAcc
            this.lblNemaAcc.AutoSize = true;
            this.lblNemaAcc.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblNemaAcc.ForeColor = System.Drawing.Color.FromArgb(130, 140, 160);
            this.lblNemaAcc.Location = new System.Drawing.Point(rx, 304);
            this.lblNemaAcc.Name = "lblNemaAcc";
            this.lblNemaAcc.Text = "Nemas nalog?";
            this.lblNemaAcc.TabIndex = 5;

            // btnRegistracija (link style)
            this.btnRegistracija.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegistracija.FlatAppearance.BorderSize = 0;
            this.btnRegistracija.BackColor = System.Drawing.Color.White;
            this.btnRegistracija.ForeColor = System.Drawing.Color.FromArgb(30, 58, 95);
            this.btnRegistracija.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRegistracija.Font = new System.Drawing.Font("Segoe UI", 9F,
                System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline);
            this.btnRegistracija.Location = new System.Drawing.Point(rx + 110, 300);
            this.btnRegistracija.Name = "btnRegistracija";
            this.btnRegistracija.Size = new System.Drawing.Size(120, 24);
            this.btnRegistracija.TabIndex = 3;
            this.btnRegistracija.Text = "Registruj se";
            this.btnRegistracija.Click += new System.EventHandler(this.btnRegistracija_Click);

            // ── FrmLogin ─────────────────────────────────────────────────
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(530, 370);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "FrmLogin";
            this.Text = "FitApp - Prijava";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;

            this.Controls.Add(this.pnlDesno);
            this.Controls.Add(this.pnlLijevo);

            this.pnlLijevo.ResumeLayout(false);
            this.pnlDesno.ResumeLayout(false);
            this.pnlDesno.PerformLayout();
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Panel    pnlLijevo;
        private System.Windows.Forms.Label    lblLogo;
        private System.Windows.Forms.Label    lblWelcome;
        private System.Windows.Forms.Panel    pnlDesno;
        private System.Windows.Forms.Label    lblNaslov;
        private System.Windows.Forms.Label    label1;
        private System.Windows.Forms.TextBox  txtUsername;
        private System.Windows.Forms.Label    label2;
        private System.Windows.Forms.TextBox  txtLozinka;
        private System.Windows.Forms.Label    lblStatus;
        private System.Windows.Forms.Button   btnLogin;
        private System.Windows.Forms.Panel    pnlLinija;
        private System.Windows.Forms.Label    lblNemaAcc;
        private System.Windows.Forms.Button   btnRegistracija;
    }
}
