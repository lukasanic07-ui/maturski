using System;
using MySql.Data.MySqlClient;

namespace WindowsFormsApplication1
{
    public static class DbHelper
    {
        // Promijeni lozinku ako tvoj MySQL root ima lozinku
        private const string ConnStr =
            "Server=localhost;Database=fitapp;Uid=root;Pwd=;CharSet=utf8mb4;";

        public static MySqlConnection GetConnection()
        {
            var conn = new MySqlConnection(ConnStr);
            conn.Open();
            return conn;
        }
    }
}
