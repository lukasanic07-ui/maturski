namespace WindowsFormsApplication1
{
    partial class FrmKorisnik
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // FrmKorisnik
            // 
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Name = "FrmKorisnik";
            this.Load += new System.EventHandler(this.FrmKorisnik_Load_1);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel      pnlLijevo;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button     btnDodajSliku;
        private System.Windows.Forms.Label      lblImePrezime;
        private System.Windows.Forms.Label      lblUsername;
        private System.Windows.Forms.Label      lblTreninziLbl;
        private System.Windows.Forms.Label      lblUkupnoTreninga;
        private System.Windows.Forms.Panel      pnlDesno;
        private System.Windows.Forms.Label      label1;
        private System.Windows.Forms.Label      label2;
        private System.Windows.Forms.Label      Prezime;
        private System.Windows.Forms.Label      label4;
        private System.Windows.Forms.Label      label5;
        private System.Windows.Forms.Label      label6;
        private System.Windows.Forms.Label      label7;
        private System.Windows.Forms.TextBox    textBox1;
        private System.Windows.Forms.TextBox    textBox2;
        private System.Windows.Forms.TextBox    textBox3;
        private System.Windows.Forms.TextBox    textBox4;
        private System.Windows.Forms.TextBox    textBox5;
        private System.Windows.Forms.TextBox    textBox6;
        private System.Windows.Forms.Button     btnSpremi;
        private System.Windows.Forms.Button     btnOdjava;
    }
}
