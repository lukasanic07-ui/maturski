namespace WindowsFormsApplication1
{
    partial class FrmNaslovna
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.pnlSidebar          = new System.Windows.Forms.Panel();
            this.lblFit              = new System.Windows.Forms.Label();
            this.btnHome             = new System.Windows.Forms.Button();
            this.btnVjezbe           = new System.Windows.Forms.Button();
            this.btnPlanovi          = new System.Windows.Forms.Button();
            this.btnEvidencija       = new System.Windows.Forms.Button();
            this.pnlTop              = new System.Windows.Forms.Panel();
            this.lblTopNaslov        = new System.Windows.Forms.Label();
            this.lblTopKorisnik      = new System.Windows.Forms.Label();
            this.pnlRecap            = new System.Windows.Forms.Panel();
            this.lblOdaberiPlan      = new System.Windows.Forms.Label();
            this.cmbPlanovi          = new System.Windows.Forms.ComboBox();
            this.lblPlanVjezbe       = new System.Windows.Forms.Label();
            this.dgvPlanVjezbe       = new System.Windows.Forms.DataGridView();
            this.colNaziv            = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTip              = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colGrupa            = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSetovi           = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlToday            = new System.Windows.Forms.Panel();
            this.lblDanasnji         = new System.Windows.Forms.Label();
            this.lblUputstvo         = new System.Windows.Forms.Label();
            this.dgvLog              = new System.Windows.Forms.DataGridView();
            this.colLogNaziv         = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colLogPlan          = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colLogUradjeno      = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colLogTezina        = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colLogCheck         = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.btnZapocniTrening   = new System.Windows.Forms.Button();
            this.btnSpremiTrening    = new System.Windows.Forms.Button();

            this.pnlSidebar.SuspendLayout();
            this.pnlTop.SuspendLayout();
            this.pnlRecap.SuspendLayout();
            this.pnlToday.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPlanVjezbe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLog)).BeginInit();
            this.SuspendLayout();

            // ── pnlSidebar ──────────────────────────────────────────────
            this.pnlSidebar.Controls.Add(this.btnEvidencija);
            this.pnlSidebar.Controls.Add(this.btnPlanovi);
            this.pnlSidebar.Controls.Add(this.btnVjezbe);
            this.pnlSidebar.Controls.Add(this.btnHome);
            this.pnlSidebar.Controls.Add(this.lblFit);
            this.pnlSidebar.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlSidebar.Location = new System.Drawing.Point(0, 0);
            this.pnlSidebar.Name = "pnlSidebar";
            this.pnlSidebar.Size = new System.Drawing.Size(110, 680);
            this.pnlSidebar.TabIndex = 0;

            this.lblFit.AutoSize = false;
            this.lblFit.Location = new System.Drawing.Point(0, 10);
            this.lblFit.Name = "lblFit";
            this.lblFit.Size = new System.Drawing.Size(110, 80);
            this.lblFit.TabIndex = 0;
            this.lblFit.Text = "Fit";
            this.lblFit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblFit.Click += new System.EventHandler(this.label1_Click);

            BtnSidebar(this.btnHome,       "Korisnik",   100, this.btnHome_Click);
            BtnSidebar(this.btnVjezbe,     "Vjezbe",     175, this.btnVjezbe_Click);
            BtnSidebar(this.btnPlanovi,    "Planovi",    250, this.btnPlanovi_Click);
            BtnSidebar(this.btnEvidencija, "Evidencija", 325, null);

            // ── pnlTop ──────────────────────────────────────────────────
            this.pnlTop.Controls.Add(this.lblTopKorisnik);
            this.pnlTop.Controls.Add(this.lblTopNaslov);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(110, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Padding = new System.Windows.Forms.Padding(16, 0, 16, 0);
            this.pnlTop.Size = new System.Drawing.Size(970, 70);
            this.pnlTop.TabIndex = 1;

            this.lblTopNaslov.AutoSize = true;
            this.lblTopNaslov.Location = new System.Drawing.Point(16, 14);
            this.lblTopNaslov.Name = "lblTopNaslov";
            this.lblTopNaslov.Size = new System.Drawing.Size(200, 25);
            this.lblTopNaslov.TabIndex = 0;
            this.lblTopNaslov.Text = "Pocetna stranica";

            this.lblTopKorisnik.AutoSize = true;
            this.lblTopKorisnik.Location = new System.Drawing.Point(16, 42);
            this.lblTopKorisnik.Name = "lblTopKorisnik";
            this.lblTopKorisnik.Size = new System.Drawing.Size(200, 15);
            this.lblTopKorisnik.TabIndex = 1;
            this.lblTopKorisnik.Text = "";

            // ── pnlRecap (lijevo - pregled plana) ───────────────────────
            this.pnlRecap.Controls.Add(this.dgvPlanVjezbe);
            this.pnlRecap.Controls.Add(this.lblPlanVjezbe);
            this.pnlRecap.Controls.Add(this.cmbPlanovi);
            this.pnlRecap.Controls.Add(this.lblOdaberiPlan);
            this.pnlRecap.Location = new System.Drawing.Point(120, 80);
            this.pnlRecap.Name = "pnlRecap";
            this.pnlRecap.Padding = new System.Windows.Forms.Padding(12);
            this.pnlRecap.Size = new System.Drawing.Size(460, 590);
            this.pnlRecap.TabIndex = 2;

            this.lblOdaberiPlan.AutoSize = true;
            this.lblOdaberiPlan.Location = new System.Drawing.Point(12, 14);
            this.lblOdaberiPlan.Name = "lblOdaberiPlan";
            this.lblOdaberiPlan.Size = new System.Drawing.Size(150, 20);
            this.lblOdaberiPlan.TabIndex = 0;
            this.lblOdaberiPlan.Text = "Odaberi plan za danas:";

            this.cmbPlanovi.Location = new System.Drawing.Point(12, 40);
            this.cmbPlanovi.Name = "cmbPlanovi";
            this.cmbPlanovi.Size = new System.Drawing.Size(430, 24);
            this.cmbPlanovi.TabIndex = 1;
            this.cmbPlanovi.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPlanovi.SelectedIndexChanged += new System.EventHandler(this.cmbPlanovi_SelectedIndexChanged);

            this.lblPlanVjezbe.AutoSize = true;
            this.lblPlanVjezbe.Location = new System.Drawing.Point(12, 74);
            this.lblPlanVjezbe.Name = "lblPlanVjezbe";
            this.lblPlanVjezbe.Size = new System.Drawing.Size(120, 16);
            this.lblPlanVjezbe.TabIndex = 2;
            this.lblPlanVjezbe.Text = "Vjezbe u planu:";

            this.dgvPlanVjezbe.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
                this.colNaziv, this.colTip, this.colGrupa, this.colSetovi });
            this.dgvPlanVjezbe.Location = new System.Drawing.Point(12, 96);
            this.dgvPlanVjezbe.Name = "dgvPlanVjezbe";
            this.dgvPlanVjezbe.ReadOnly = true;
            this.dgvPlanVjezbe.Size = new System.Drawing.Size(430, 480);
            this.dgvPlanVjezbe.TabIndex = 3;
            this.dgvPlanVjezbe.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;

            SetCol(this.colNaziv,  "colNaziv",  "Naziv vjezbe",  160);
            SetCol(this.colTip,    "colTip",    "Tip",           80);
            SetCol(this.colGrupa,  "colGrupa",  "Grupa",         90);
            SetCol(this.colSetovi, "colSetovi", "Setovi x Rep.", 90);

            // ── pnlToday (desno - logovanje) ─────────────────────────────
            this.pnlToday.Controls.Add(this.btnSpremiTrening);
            this.pnlToday.Controls.Add(this.btnZapocniTrening);
            this.pnlToday.Controls.Add(this.dgvLog);
            this.pnlToday.Controls.Add(this.lblUputstvo);
            this.pnlToday.Controls.Add(this.lblDanasnji);
            this.pnlToday.Location = new System.Drawing.Point(590, 80);
            this.pnlToday.Name = "pnlToday";
            this.pnlToday.Padding = new System.Windows.Forms.Padding(12);
            this.pnlToday.Size = new System.Drawing.Size(490, 590);
            this.pnlToday.TabIndex = 3;

            this.lblDanasnji.AutoSize = true;
            this.lblDanasnji.Location = new System.Drawing.Point(12, 14);
            this.lblDanasnji.Name = "lblDanasnji";
            this.lblDanasnji.Size = new System.Drawing.Size(200, 20);
            this.lblDanasnji.TabIndex = 0;
            this.lblDanasnji.Text = "Loguj danasnji trening:";

            this.lblUputstvo.AutoSize = false;
            this.lblUputstvo.Location = new System.Drawing.Point(12, 40);
            this.lblUputstvo.Name = "lblUputstvo";
            this.lblUputstvo.Size = new System.Drawing.Size(460, 34);
            this.lblUputstvo.TabIndex = 1;
            this.lblUputstvo.Text = "Odaberite plan sa lijeve strane.";

            this.dgvLog.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
                this.colLogNaziv, this.colLogPlan, this.colLogUradjeno,
                this.colLogTezina, this.colLogCheck });
            this.dgvLog.Location = new System.Drawing.Point(12, 82);
            this.dgvLog.Name = "dgvLog";
            this.dgvLog.ReadOnly = false;
            this.dgvLog.Size = new System.Drawing.Size(462, 440);
            this.dgvLog.TabIndex = 2;
            this.dgvLog.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;

            SetCol(this.colLogNaziv,    "colLogNaziv",    "Vjezba",         130);
            SetCol(this.colLogPlan,     "colLogPlan",     "Plan.setovi",     80);
            SetCol(this.colLogUradjeno, "colLogUradjeno", "Uradjeni setovi", 100);
            SetCol(this.colLogTezina,   "colLogTezina",   "Max tezina(kg)",  100);
            this.colLogNaziv.ReadOnly  = true;
            this.colLogPlan.ReadOnly   = true;

            this.colLogCheck.HeaderText = "Uradjeno";
            this.colLogCheck.Name       = "colLogCheck";
            this.colLogCheck.Width      = 70;

            this.btnZapocniTrening.Location = new System.Drawing.Point(12, 534);
            this.btnZapocniTrening.Name = "btnZapocniTrening";
            this.btnZapocniTrening.Size = new System.Drawing.Size(160, 36);
            this.btnZapocniTrening.TabIndex = 3;
            this.btnZapocniTrening.Text = "Zapocni trening";
            this.btnZapocniTrening.Click += new System.EventHandler(this.btnZapocniTrening_Click);

            this.btnSpremiTrening.Location = new System.Drawing.Point(300, 534);
            this.btnSpremiTrening.Name = "btnSpremiTrening";
            this.btnSpremiTrening.Size = new System.Drawing.Size(160, 36);
            this.btnSpremiTrening.TabIndex = 4;
            this.btnSpremiTrening.Text = "Spremi trening";
            this.btnSpremiTrening.Click += new System.EventHandler(this.btnSpremiTrening_Click);

            // ── FrmNaslovna ──────────────────────────────────────────────
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1080, 680);
            this.Controls.Add(this.pnlToday);
            this.Controls.Add(this.pnlRecap);
            this.Controls.Add(this.pnlTop);
            this.Controls.Add(this.pnlSidebar);
            this.MinimumSize = new System.Drawing.Size(1080, 680);
            this.Name = "FrmNaslovna";
            this.Text = "FitApp";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.FrmNaslovna_Load);

            this.pnlSidebar.ResumeLayout(false);
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.pnlRecap.ResumeLayout(false);
            this.pnlRecap.PerformLayout();
            this.pnlToday.ResumeLayout(false);
            this.pnlToday.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPlanVjezbe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLog)).EndInit();
            this.ResumeLayout(false);
        }

        // Helper za sidebar button
        private void BtnSidebar(System.Windows.Forms.Button b, string text, int top,
                                 System.EventHandler handler)
        {
            b.Location = new System.Drawing.Point(5, top);
            b.Name     = b.Name;
            b.Size     = new System.Drawing.Size(100, 60);
            b.TabIndex = 0;
            b.Text     = text;
            if (handler != null) b.Click += handler;
        }

        private void SetCol(System.Windows.Forms.DataGridViewTextBoxColumn col,
                            string name, string header, int width)
        {
            col.HeaderText = header;
            col.Name       = name;
            col.Width      = width;
        }

        #endregion

        private System.Windows.Forms.Panel   pnlSidebar;
        private System.Windows.Forms.Label   lblFit;
        private System.Windows.Forms.Button  btnHome;
        private System.Windows.Forms.Button  btnVjezbe;
        private System.Windows.Forms.Button  btnPlanovi;
        private System.Windows.Forms.Button  btnEvidencija;
        private System.Windows.Forms.Panel   pnlTop;
        private System.Windows.Forms.Label   lblTopNaslov;
        private System.Windows.Forms.Label   lblTopKorisnik;
        private System.Windows.Forms.Panel   pnlRecap;
        private System.Windows.Forms.Label   lblOdaberiPlan;
        private System.Windows.Forms.ComboBox cmbPlanovi;
        private System.Windows.Forms.Label   lblPlanVjezbe;
        private System.Windows.Forms.DataGridView dgvPlanVjezbe;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNaziv;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTip;
        private System.Windows.Forms.DataGridViewTextBoxColumn colGrupa;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSetovi;
        private System.Windows.Forms.Panel   pnlToday;
        private System.Windows.Forms.Label   lblDanasnji;
        private System.Windows.Forms.Label   lblUputstvo;
        private System.Windows.Forms.DataGridView dgvLog;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLogNaziv;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLogPlan;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLogUradjeno;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLogTezina;
        private System.Windows.Forms.DataGridViewCheckBoxColumn colLogCheck;
        private System.Windows.Forms.Button  btnZapocniTrening;
        private System.Windows.Forms.Button  btnSpremiTrening;
    }
}
