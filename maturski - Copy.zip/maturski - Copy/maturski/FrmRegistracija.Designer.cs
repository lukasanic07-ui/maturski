namespace WindowsFormsApplication1
{
    partial class FrmRegistracija
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.pnlLijevo = new System.Windows.Forms.Panel();
            this.lblAppNaziv = new System.Windows.Forms.Label();
            this.lblPodnaslov = new System.Windows.Forms.Label();
            this.pnlDesno = new System.Windows.Forms.Panel();
            this.lblNaslov = new System.Windows.Forms.Label();
            this.lblUsername = new System.Windows.Forms.Label();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.lblLozinka = new System.Windows.Forms.Label();
            this.txtLozinka = new System.Windows.Forms.TextBox();
            this.lblPotvrdaLoz = new System.Windows.Forms.Label();
            this.txtPotvrdaLozinke = new System.Windows.Forms.TextBox();
            this.lblIme = new System.Windows.Forms.Label();
            this.txtIme = new System.Windows.Forms.TextBox();
            this.lblPrezime = new System.Windows.Forms.Label();
            this.txtPrezime = new System.Windows.Forms.TextBox();
            this.lblOpcije = new System.Windows.Forms.Label();
            this.lblGodine = new System.Windows.Forms.Label();
            this.txtGodine = new System.Windows.Forms.TextBox();
            this.lblTezina = new System.Windows.Forms.Label();
            this.txtTezina = new System.Windows.Forms.TextBox();
            this.lblVisina = new System.Windows.Forms.Label();
            this.txtVisina = new System.Windows.Forms.TextBox();
            this.btnRegistruj = new System.Windows.Forms.Button();
            this.btnOtkazi = new System.Windows.Forms.Button();
            this.pnlLijevo.SuspendLayout();
            this.pnlDesno.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlLijevo
            // 
            this.pnlLijevo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.pnlLijevo.Controls.Add(this.lblAppNaziv);
            this.pnlLijevo.Controls.Add(this.lblPodnaslov);
            this.pnlLijevo.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlLijevo.Location = new System.Drawing.Point(0, 0);
            this.pnlLijevo.Name = "pnlLijevo";
            this.pnlLijevo.Size = new System.Drawing.Size(190, 403);
            this.pnlLijevo.TabIndex = 1;
            // 
            // lblAppNaziv
            // 
            this.lblAppNaziv.AutoSize = true;
            this.lblAppNaziv.Font = new System.Drawing.Font("Segoe UI", 22F, System.Drawing.FontStyle.Bold);
            this.lblAppNaziv.ForeColor = System.Drawing.Color.White;
            this.lblAppNaziv.Location = new System.Drawing.Point(12, 162);
            this.lblAppNaziv.Name = "lblAppNaziv";
            this.lblAppNaziv.Size = new System.Drawing.Size(158, 41);
            this.lblAppNaziv.TabIndex = 0;
            this.lblAppNaziv.Text = "FitTracker";
            // 
            // lblPodnaslov
            // 
            this.lblPodnaslov.AutoSize = true;
            this.lblPodnaslov.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblPodnaslov.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(220)))));
            this.lblPodnaslov.Location = new System.Drawing.Point(15, 212);
            this.lblPodnaslov.Name = "lblPodnaslov";
            this.lblPodnaslov.Size = new System.Drawing.Size(66, 38);
            this.lblPodnaslov.TabIndex = 1;
            this.lblPodnaslov.Text = "Prati svoj\nnapredak";
            // 
            // pnlDesno
            // 
            this.pnlDesno.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(245)))), ((int)(((byte)(250)))));
            this.pnlDesno.Controls.Add(this.lblNaslov);
            this.pnlDesno.Controls.Add(this.lblUsername);
            this.pnlDesno.Controls.Add(this.txtUsername);
            this.pnlDesno.Controls.Add(this.lblLozinka);
            this.pnlDesno.Controls.Add(this.txtLozinka);
            this.pnlDesno.Controls.Add(this.lblPotvrdaLoz);
            this.pnlDesno.Controls.Add(this.txtPotvrdaLozinke);
            this.pnlDesno.Controls.Add(this.lblIme);
            this.pnlDesno.Controls.Add(this.txtIme);
            this.pnlDesno.Controls.Add(this.lblPrezime);
            this.pnlDesno.Controls.Add(this.txtPrezime);
            this.pnlDesno.Controls.Add(this.lblOpcije);
            this.pnlDesno.Controls.Add(this.lblGodine);
            this.pnlDesno.Controls.Add(this.txtGodine);
            this.pnlDesno.Controls.Add(this.lblTezina);
            this.pnlDesno.Controls.Add(this.txtTezina);
            this.pnlDesno.Controls.Add(this.lblVisina);
            this.pnlDesno.Controls.Add(this.txtVisina);
            this.pnlDesno.Controls.Add(this.btnRegistruj);
            this.pnlDesno.Controls.Add(this.btnOtkazi);
            this.pnlDesno.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlDesno.Location = new System.Drawing.Point(190, 0);
            this.pnlDesno.Name = "pnlDesno";
            this.pnlDesno.Padding = new System.Windows.Forms.Padding(25, 15, 25, 15);
            this.pnlDesno.Size = new System.Drawing.Size(299, 403);
            this.pnlDesno.TabIndex = 0;
            // 
            // lblNaslov
            // 
            this.lblNaslov.AutoSize = true;
            this.lblNaslov.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblNaslov.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.lblNaslov.Location = new System.Drawing.Point(25, 15);
            this.lblNaslov.Name = "lblNaslov";
            this.lblNaslov.Size = new System.Drawing.Size(145, 30);
            this.lblNaslov.TabIndex = 0;
            this.lblNaslov.Text = "Kreiraj nalog";
            // 
            // lblUsername
            // 
            this.lblUsername.AutoSize = true;
            this.lblUsername.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblUsername.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(80)))));
            this.lblUsername.Location = new System.Drawing.Point(25, 58);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(72, 15);
            this.lblUsername.TabIndex = 1;
            this.lblUsername.Text = "Username *";
            // 
            // txtUsername
            // 
            this.txtUsername.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUsername.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtUsername.Location = new System.Drawing.Point(25, 75);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(250, 25);
            this.txtUsername.TabIndex = 2;
            // 
            // lblLozinka
            // 
            this.lblLozinka.AutoSize = true;
            this.lblLozinka.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblLozinka.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(80)))));
            this.lblLozinka.Location = new System.Drawing.Point(25, 110);
            this.lblLozinka.Name = "lblLozinka";
            this.lblLozinka.Size = new System.Drawing.Size(57, 15);
            this.lblLozinka.TabIndex = 3;
            this.lblLozinka.Text = "Lozinka *";
            // 
            // txtLozinka
            // 
            this.txtLozinka.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtLozinka.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtLozinka.Location = new System.Drawing.Point(25, 127);
            this.txtLozinka.Name = "txtLozinka";
            this.txtLozinka.Size = new System.Drawing.Size(250, 25);
            this.txtLozinka.TabIndex = 4;
            this.txtLozinka.UseSystemPasswordChar = true;
            // 
            // lblPotvrdaLoz
            // 
            this.lblPotvrdaLoz.AutoSize = true;
            this.lblPotvrdaLoz.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblPotvrdaLoz.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(80)))));
            this.lblPotvrdaLoz.Location = new System.Drawing.Point(25, 162);
            this.lblPotvrdaLoz.Name = "lblPotvrdaLoz";
            this.lblPotvrdaLoz.Size = new System.Drawing.Size(102, 15);
            this.lblPotvrdaLoz.TabIndex = 5;
            this.lblPotvrdaLoz.Text = "Potvrda lozinke *";
            // 
            // txtPotvrdaLozinke
            // 
            this.txtPotvrdaLozinke.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPotvrdaLozinke.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtPotvrdaLozinke.Location = new System.Drawing.Point(25, 179);
            this.txtPotvrdaLozinke.Name = "txtPotvrdaLozinke";
            this.txtPotvrdaLozinke.Size = new System.Drawing.Size(250, 25);
            this.txtPotvrdaLozinke.TabIndex = 6;
            this.txtPotvrdaLozinke.UseSystemPasswordChar = true;
            // 
            // lblIme
            // 
            this.lblIme.AutoSize = true;
            this.lblIme.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblIme.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(80)))));
            this.lblIme.Location = new System.Drawing.Point(25, 214);
            this.lblIme.Name = "lblIme";
            this.lblIme.Size = new System.Drawing.Size(29, 15);
            this.lblIme.TabIndex = 7;
            this.lblIme.Text = "Ime";
            // 
            // txtIme
            // 
            this.txtIme.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtIme.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtIme.Location = new System.Drawing.Point(25, 231);
            this.txtIme.Name = "txtIme";
            this.txtIme.Size = new System.Drawing.Size(115, 25);
            this.txtIme.TabIndex = 8;
            // 
            // lblPrezime
            // 
            this.lblPrezime.AutoSize = true;
            this.lblPrezime.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblPrezime.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(80)))));
            this.lblPrezime.Location = new System.Drawing.Point(150, 214);
            this.lblPrezime.Name = "lblPrezime";
            this.lblPrezime.Size = new System.Drawing.Size(53, 15);
            this.lblPrezime.TabIndex = 9;
            this.lblPrezime.Text = "Prezime";
            // 
            // txtPrezime
            // 
            this.txtPrezime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPrezime.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtPrezime.Location = new System.Drawing.Point(150, 231);
            this.txtPrezime.Name = "txtPrezime";
            this.txtPrezime.Size = new System.Drawing.Size(125, 25);
            this.txtPrezime.TabIndex = 10;
            // 
            // lblOpcije
            // 
            this.lblOpcije.AutoSize = true;
            this.lblOpcije.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Italic);
            this.lblOpcije.ForeColor = System.Drawing.Color.Gray;
            this.lblOpcije.Location = new System.Drawing.Point(25, 267);
            this.lblOpcije.Name = "lblOpcije";
            this.lblOpcije.Size = new System.Drawing.Size(201, 13);
            this.lblOpcije.TabIndex = 11;
            this.lblOpcije.Text = "Opcioni podaci (možeš popuniti i kasnije)";
            // 
            // lblGodine
            // 
            this.lblGodine.AutoSize = true;
            this.lblGodine.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblGodine.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(80)))));
            this.lblGodine.Location = new System.Drawing.Point(25, 288);
            this.lblGodine.Name = "lblGodine";
            this.lblGodine.Size = new System.Drawing.Size(47, 15);
            this.lblGodine.TabIndex = 12;
            this.lblGodine.Text = "Godine";
            // 
            // txtGodine
            // 
            this.txtGodine.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtGodine.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtGodine.Location = new System.Drawing.Point(25, 305);
            this.txtGodine.Name = "txtGodine";
            this.txtGodine.Size = new System.Drawing.Size(75, 25);
            this.txtGodine.TabIndex = 13;
            // 
            // lblTezina
            // 
            this.lblTezina.AutoSize = true;
            this.lblTezina.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblTezina.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(80)))));
            this.lblTezina.Location = new System.Drawing.Point(112, 288);
            this.lblTezina.Name = "lblTezina";
            this.lblTezina.Size = new System.Drawing.Size(67, 15);
            this.lblTezina.TabIndex = 14;
            this.lblTezina.Text = "Težina (kg)";
            // 
            // txtTezina
            // 
            this.txtTezina.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTezina.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtTezina.Location = new System.Drawing.Point(112, 305);
            this.txtTezina.Name = "txtTezina";
            this.txtTezina.Size = new System.Drawing.Size(75, 25);
            this.txtTezina.TabIndex = 15;
            // 
            // lblVisina
            // 
            this.lblVisina.AutoSize = true;
            this.lblVisina.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblVisina.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(80)))));
            this.lblVisina.Location = new System.Drawing.Point(200, 288);
            this.lblVisina.Name = "lblVisina";
            this.lblVisina.Size = new System.Drawing.Size(67, 15);
            this.lblVisina.TabIndex = 16;
            this.lblVisina.Text = "Visina (cm)";
            // 
            // txtVisina
            // 
            this.txtVisina.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtVisina.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtVisina.Location = new System.Drawing.Point(200, 305);
            this.txtVisina.Name = "txtVisina";
            this.txtVisina.Size = new System.Drawing.Size(75, 25);
            this.txtVisina.TabIndex = 17;
            // 
            // btnRegistruj
            // 
            this.btnRegistruj.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.btnRegistruj.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRegistruj.FlatAppearance.BorderSize = 0;
            this.btnRegistruj.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegistruj.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnRegistruj.ForeColor = System.Drawing.Color.White;
            this.btnRegistruj.Location = new System.Drawing.Point(25, 350);
            this.btnRegistruj.Name = "btnRegistruj";
            this.btnRegistruj.Size = new System.Drawing.Size(115, 38);
            this.btnRegistruj.TabIndex = 18;
            this.btnRegistruj.Text = "Registruj se";
            this.btnRegistruj.UseVisualStyleBackColor = false;
            this.btnRegistruj.MouseLeave += new System.EventHandler(this.BtnHoverLeave);
            this.btnRegistruj.Click += new System.EventHandler(this.btnRegistruj_Click);
            this.btnRegistruj.MouseEnter += new System.EventHandler(this.BtnHoverEnter);
            // 
            // btnOtkazi
            // 
            this.btnOtkazi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(245)))), ((int)(((byte)(250)))));
            this.btnOtkazi.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnOtkazi.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.btnOtkazi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOtkazi.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnOtkazi.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.btnOtkazi.Location = new System.Drawing.Point(153, 350);
            this.btnOtkazi.Name = "btnOtkazi";
            this.btnOtkazi.Size = new System.Drawing.Size(122, 38);
            this.btnOtkazi.TabIndex = 19;
            this.btnOtkazi.Text = "Odustani";
            this.btnOtkazi.UseVisualStyleBackColor = false;
            this.btnOtkazi.Click += new System.EventHandler(this.btnOtkazi_Click);
            // 
            // FrmRegistracija
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(245)))), ((int)(((byte)(250)))));
            this.ClientSize = new System.Drawing.Size(489, 403);
            this.Controls.Add(this.pnlDesno);
            this.Controls.Add(this.pnlLijevo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmRegistracija";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Registracija";
            this.Load += new System.EventHandler(this.FrmRegistracija_Load);
            this.pnlLijevo.ResumeLayout(false);
            this.pnlLijevo.PerformLayout();
            this.pnlDesno.ResumeLayout(false);
            this.pnlDesno.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlLijevo;
        private System.Windows.Forms.Label lblAppNaziv;
        private System.Windows.Forms.Label lblPodnaslov;
        private System.Windows.Forms.Panel pnlDesno;
        private System.Windows.Forms.Label lblNaslov;
        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.Label lblLozinka;
        private System.Windows.Forms.TextBox txtLozinka;
        private System.Windows.Forms.Label lblPotvrdaLoz;
        private System.Windows.Forms.TextBox txtPotvrdaLozinke;
        private System.Windows.Forms.Label lblIme;
        private System.Windows.Forms.TextBox txtIme;
        private System.Windows.Forms.Label lblPrezime;
        private System.Windows.Forms.TextBox txtPrezime;
        private System.Windows.Forms.Label lblOpcije;
        private System.Windows.Forms.Label lblGodine;
        private System.Windows.Forms.TextBox txtGodine;
        private System.Windows.Forms.Label lblTezina;
        private System.Windows.Forms.TextBox txtTezina;
        private System.Windows.Forms.Label lblVisina;
        private System.Windows.Forms.TextBox txtVisina;
        private System.Windows.Forms.Button btnRegistruj;
        private System.Windows.Forms.Button btnOtkazi;
    }
}