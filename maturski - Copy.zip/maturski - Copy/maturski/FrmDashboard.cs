using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApplication1
{
    public partial class FrmDashboard : Form
    {
        private int aktivniTreningID = -1;
        private List<PlanVjezbaRed> planVjezbe = new List<PlanVjezbaRed>();

        private class PlanVjezbaRed
        {
            public int VjezbaID;
            public string Naziv;
            public string Tip;
            public string Grupa;
            public int Setovi;
            public int Ponavljanja;
        }

        private class PlanItem
        {
            public int PlanID;
            public string Naziv;
            public override string ToString() { return Naziv; }
        }

        public FrmDashboard()
        {
            InitializeComponent();

            // ── Tamna tema za lijevi panel — ovdje VS nikad ne dira ────────
            pnlLeft.BackColor = Color.FromArgb(28, 25, 45);
            pnlLeft.BorderStyle = BorderStyle.None;

            lblOdaberiPlan.ForeColor = Color.FromArgb(180, 176, 220);
            lblVjezbeUPlanu.ForeColor = Color.FromArgb(88, 86, 214);

            cmbPlan.BackColor = Color.FromArgb(50, 47, 75);
            cmbPlan.ForeColor = Color.White;

            dgvPlanVjezbe.BackgroundColor = Color.FromArgb(28, 25, 45);
            dgvPlanVjezbe.BorderStyle = BorderStyle.None;
            dgvPlanVjezbe.GridColor = Color.FromArgb(45, 42, 68);

            dgvPlanVjezbe.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(20, 17, 35);
            dgvPlanVjezbe.ColumnHeadersDefaultCellStyle.ForeColor = Color.FromArgb(180, 176, 220);

            dgvPlanVjezbe.DefaultCellStyle.BackColor = Color.FromArgb(34, 31, 53);
            dgvPlanVjezbe.DefaultCellStyle.ForeColor = Color.FromArgb(210, 207, 240);
            dgvPlanVjezbe.DefaultCellStyle.SelectionBackColor = Color.FromArgb(88, 86, 214);
            dgvPlanVjezbe.DefaultCellStyle.SelectionForeColor = Color.White;

            dgvPlanVjezbe.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(40, 37, 62);
            dgvPlanVjezbe.AlternatingRowsDefaultCellStyle.ForeColor = Color.FromArgb(210, 207, 240);
        }

        private void FrmDashboard_Load(object sender, EventArgs e)
        {
            lblUsername.Text = "Dobrodosli, " + KorisnikManager.TrenutniUsername + "!";
            UcitajPlanoviUCombo();
            ProvjeriAktivniTrening();
        }

        // ── NAVIGATION ────────────────────────────────────────────────────
        private void btnNavKorisnik_Click(object sender, EventArgs e) { new FrmKorisnik().ShowDialog(); }
        private void btnNavVjezbe_Click(object sender, EventArgs e) { new FrmVjezbe().ShowDialog(); }
        private void btnNavPlanovi_Click(object sender, EventArgs e) { new FrmTreningPlan().ShowDialog(); UcitajPlanoviUCombo(); }
        private void btnNavEvidencija_Click(object sender, EventArgs e) { new FrmEvidencija().ShowDialog(); }

        // ── PLANS COMBO ───────────────────────────────────────────────────
        private void UcitajPlanoviUCombo()
        {
            cmbPlan.Items.Clear();
            cmbPlan.Items.Add(new PlanItem { PlanID = -1, Naziv = "-- Odaberi plan --" });
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                using (MySqlCommand cmd = new MySqlCommand(
                    "SELECT PlanID, Naziv FROM treningplan WHERE KorisnikID=@kid ORDER BY Naziv", conn))
                {
                    cmd.Parameters.AddWithValue("@kid", KorisnikManager.TrenutniKorisnikID);
                    using (MySqlDataReader r = cmd.ExecuteReader())
                        while (r.Read())
                            cmbPlan.Items.Add(new PlanItem { PlanID = r.GetInt32(0), Naziv = r.GetString(1) });
                }
            }
            catch (Exception ex) { MessageBox.Show("Greška: " + ex.Message); }
            cmbPlan.SelectedIndex = 0;
        }

        private void cmbPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            dgvPlanVjezbe.Rows.Clear();
            planVjezbe.Clear();

            var sel = cmbPlan.SelectedItem as PlanItem;
            if (sel == null || sel.PlanID == -1) { lblVjezbeUPlanu.Text = "Vjezbe u planu:"; return; }

            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                using (MySqlCommand cmd = new MySqlCommand(
                    "SELECT v.VjezbaID, v.Naziv, v.Tip, v.MisicnaGrupa, pv.BrojSetova, pv.BrojPonavljanja " +
                    "FROM planvjezba pv JOIN vjezba v ON v.VjezbaID=pv.VjezbaID " +
                    "WHERE pv.PlanID=@pid ORDER BY v.Naziv", conn))
                {
                    cmd.Parameters.AddWithValue("@pid", sel.PlanID);
                    using (MySqlDataReader r = cmd.ExecuteReader())
                        while (r.Read())
                        {
                            var red = new PlanVjezbaRed
                            {
                                VjezbaID = r.GetInt32(0),
                                Naziv = r.GetString(1),
                                Tip = r.IsDBNull(2) ? "" : r.GetString(2),
                                Grupa = r.IsDBNull(3) ? "" : r.GetString(3),
                                Setovi = r.IsDBNull(4) ? 0 : r.GetInt32(4),
                                Ponavljanja = r.IsDBNull(5) ? 0 : r.GetInt32(5)
                            };
                            planVjezbe.Add(red);
                            dgvPlanVjezbe.Rows.Add(red.Naziv, red.Tip, red.Grupa,
                                red.Setovi + " x " + red.Ponavljanja);
                        }
                }
            }
            catch (Exception ex) { MessageBox.Show("Greška: " + ex.Message); }
            lblVjezbeUPlanu.Text = "Vjezbe u planu: " + dgvPlanVjezbe.Rows.Count;
        }

        // ── TRAINING LOG ──────────────────────────────────────────────────
        private void ProvjeriAktivniTrening()
        {
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                using (MySqlCommand cmd = new MySqlCommand(
                    "SELECT TreningID FROM trening WHERE KorisnikID=@kid AND DATE(Datum)=CURDATE() " +
                    "ORDER BY TreningID DESC LIMIT 1", conn))
                {
                    cmd.Parameters.AddWithValue("@kid", KorisnikManager.TrenutniKorisnikID);
                    object res = cmd.ExecuteScalar();
                    if (res != null && res != DBNull.Value)
                    {
                        aktivniTreningID = Convert.ToInt32(res);
                        UcitajLogTreninga();
                        lblLogSub.Text = "Nastavak treninga od danas (" + DateTime.Now.ToString("dd.MM.yyyy") + ")";
                        lblLogSub.ForeColor = Color.FromArgb(88, 86, 214);
                    }
                    else
                    {
                        lblLogSub.Text = "Trening nije pokrenut. Pritisni ▶ za start.";
                        lblLogSub.ForeColor = Color.Gray;
                    }
                }
            }
            catch { }
        }

        private void btnZapocniTrening_Click(object sender, EventArgs e)
        {
            if (aktivniTreningID != -1)
            {
                MessageBox.Show("Trening je vec aktivan!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                using (MySqlCommand cmd = new MySqlCommand(
                    "INSERT INTO trening (KorisnikID, Datum) VALUES (@kid, NOW())", conn))
                {
                    cmd.Parameters.AddWithValue("@kid", KorisnikManager.TrenutniKorisnikID);
                    cmd.ExecuteNonQuery();
                    aktivniTreningID = Convert.ToInt32(cmd.LastInsertedId);
                }
                lblLogSub.Text = "▶  Trening u toku  —  " + DateTime.Now.ToString("dd.MM.yyyy HH:mm");
                lblLogSub.ForeColor = Color.FromArgb(40, 160, 80);

                dgvLogVjezbe.Rows.Clear();
                foreach (var pv in planVjezbe)
                {
                    // Kolone: Vjezba | Pl.set. | Pl.pon. | Set1 | Set2 | Set3 | Pon./set | OK
                    int idx = dgvLogVjezbe.Rows.Add(
                        pv.Naziv, pv.Setovi, pv.Ponavljanja,
                        "", "", "", pv.Ponavljanja, false);
                    dgvLogVjezbe.Rows[idx].Tag = pv.VjezbaID;
                }
            }
            catch (Exception ex) { MessageBox.Show("Greška: " + ex.Message); }
        }

        private void btnSpremiTrening_Click(object sender, EventArgs e)
        {
            if (aktivniTreningID == -1)
            {
                MessageBox.Show("Nema aktivnog treninga.", "Upozorenje", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                    foreach (DataGridViewRow row in dgvLogVjezbe.Rows)
                    {
                        if (!(row.Tag is int)) continue;
                        int vid = (int)row.Tag;
                        double set1 = ParseCell(row, "colLSet1");
                        double set2 = ParseCell(row, "colLSet2");
                        double set3 = ParseCell(row, "colLSet3");
                        int pon = (int)ParseCell(row, "colLPon");
                        double maxKg = Math.Max(set1, Math.Max(set2, set3));
                        int setovi = (set1 > 0 ? 1 : 0) + (set2 > 0 ? 1 : 0) + (set3 > 0 ? 1 : 0);
                        if (setovi == 0) setovi = 1;

                        using (MySqlCommand cmd = new MySqlCommand(
                            "INSERT INTO treningvjezba " +
                            "(TreningID,VjezbaID,OdradjeniSetovi,OdradjenaPonavlajnja,MaxTezina,Uradjeno) " +
                            "VALUES (@tid,@vid,@ser,@pon,@kg,1) " +
                            "ON DUPLICATE KEY UPDATE OdradjeniSetovi=@ser,OdradjenaPonavlajnja=@pon,MaxTezina=@kg,Uradjeno=1", conn))
                        {
                            cmd.Parameters.AddWithValue("@tid", aktivniTreningID);
                            cmd.Parameters.AddWithValue("@vid", vid);
                            cmd.Parameters.AddWithValue("@ser", setovi);
                            cmd.Parameters.AddWithValue("@pon", pon);
                            cmd.Parameters.AddWithValue("@kg", maxKg > 0 ? (object)maxKg : DBNull.Value);
                            cmd.ExecuteNonQuery();
                        }
                    }

                MessageBox.Show("Trening uspjesno snimljen!", "Uspjeh", MessageBoxButtons.OK, MessageBoxIcon.Information);
                lblLogSub.Text = "✔  Snimljeno  —  " + DateTime.Now.ToString("dd.MM.yyyy HH:mm");
                lblLogSub.ForeColor = Color.FromArgb(88, 86, 214);
            }
            catch (Exception ex) { MessageBox.Show("Greška: " + ex.Message); }
        }

        private void UcitajLogTreninga()
        {
            dgvLogVjezbe.Rows.Clear();
            if (aktivniTreningID == -1) return;
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                using (MySqlCommand cmd = new MySqlCommand(
                    "SELECT tv.VjezbaID, v.Naziv, tv.OdradjeniSetovi, tv.OdradjenaPonavlajnja, tv.MaxTezina, tv.Uradjeno " +
                    "FROM treningvjezba tv JOIN vjezba v ON v.VjezbaID=tv.VjezbaID " +
                    "WHERE tv.TreningID=@tid ORDER BY v.Naziv", conn))
                {
                    cmd.Parameters.AddWithValue("@tid", aktivniTreningID);
                    using (MySqlDataReader r = cmd.ExecuteReader())
                        while (r.Read())
                        {
                            int vid = r.GetInt32(0);
                            string naz = r.GetString(1);
                            int ser = r.IsDBNull(2) ? 0 : r.GetInt32(2);
                            int pon = r.IsDBNull(3) ? 0 : r.GetInt32(3);
                            double kg = r.IsDBNull(4) ? 0 : r.GetDouble(4);
                            bool ura = !r.IsDBNull(5) && r.GetInt32(5) == 1;
                            string kgStr = kg > 0 ? kg.ToString("0.##") : "";
                            // Kolone: Vjezba | Pl.set. | Pl.pon. | Set1 | Set2 | Set3 | Pon./set | OK
                            int idx = dgvLogVjezbe.Rows.Add(naz, ser, pon, kgStr, kgStr, kgStr, pon, ura);
                            dgvLogVjezbe.Rows[idx].Tag = vid;
                        }
                }
            }
            catch (Exception ex) { MessageBox.Show("Greška: " + ex.Message); }
        }

        private double ParseCell(DataGridViewRow row, string col)
        {
            try
            {
                var v = row.Cells[col].Value;
                if (v == null || v.ToString().Trim() == "") return 0;
                double d;
                double.TryParse(v.ToString().Replace(",", "."),
                    System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture, out d);
                return d;
            }
            catch { return 0; }
        }
    }
}