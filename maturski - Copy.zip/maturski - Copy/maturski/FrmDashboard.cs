using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApplication1
{
    public partial class FrmDashboard : Form
    {
        private int aktivniTreningID = -1;
        private List<PlanVjezbaRed> planVjezbe = new List<PlanVjezbaRed>();

        private class PlanVjezbaRed
        {
            public int VjezbaID;
            public string Naziv;
            public string Tip;
            public string Grupa;
            public int Setovi;
            public int Ponavljanja;
        }

        private class PlanItem
        {
            public int PlanID;
            public string Naziv;
            public override string ToString() { return Naziv; }
        }

        public FrmDashboard()
        {
            InitializeComponent();
        }

        // ══════════════════════════════════════════════════════════════════
        //  LOAD — SVE stilove primjenjujemo ovdje jer VS Designer.cs
        //         prepisuje sve što je u Designer fajlu kad ga otvoriš.
        //         Ovaj fajl VS nikad ne dira automatski.
        // ══════════════════════════════════════════════════════════════════
        private void FrmDashboard_Load(object sender, EventArgs e)
        {
            PrimijeniStilove();
            UcitajPlanoviUCombo();
            ProvjeriAktivniTrening();
        }

        private void PrimijeniStilove()
        {
            // ── Forma ─────────────────────────────────────────────────────
            this.Text = "FitApp";
            this.BackColor = Color.FromArgb(240, 242, 248);

            // ── Sidebar ───────────────────────────────────────────────────
            pnlSidebar.BackColor = Color.FromArgb(28, 25, 45);
            pnlSidebar.Dock = DockStyle.Left;
            pnlSidebar.Width = 200;

            lblAppName.Text = "FitApp";
            lblAppName.Font = new Font("Segoe UI", 15f, FontStyle.Bold);
            lblAppName.ForeColor = Color.White;
            lblAppName.Location = new Point(0, 20);
            lblAppName.Size = new Size(200, 34);
            lblAppName.TextAlign = ContentAlignment.MiddleCenter;

            lblAppSub.Text = "Trening tracker";
            lblAppSub.Font = new Font("Segoe UI", 7.5f);
            lblAppSub.ForeColor = Color.FromArgb(140, 136, 180);
            lblAppSub.Location = new Point(0, 52);
            lblAppSub.Size = new Size(200, 18);
            lblAppSub.TextAlign = ContentAlignment.MiddleCenter;

            pnlNavSep.BackColor = Color.FromArgb(55, 52, 80);
            pnlNavSep.Location = new Point(14, 78);
            pnlNavSep.Size = new Size(172, 1);

            StilujNavBtn(btnNavKorisnik, "  Korisnik", 94);
            StilujNavBtn(btnNavVjezbe, "  Vjezbe", 146);
            StilujNavBtn(btnNavPlanovi, "  Planovi", 198);
            StilujNavBtn(btnNavEvidencija, "  Evidencija", 250);

            // ── Content ───────────────────────────────────────────────────
            pnlContent.BackColor = Color.FromArgb(240, 242, 248);
            pnlContent.Dock = DockStyle.Fill;

            lblPageTitle.Text = "Početna stranica";
            lblPageTitle.Font = new Font("Segoe UI", 15f, FontStyle.Bold);
            lblPageTitle.ForeColor = Color.FromArgb(28, 25, 45);
            lblPageTitle.Location = new Point(20, 14);
            lblPageTitle.AutoSize = true;

            lblUsername.Font = new Font("Segoe UI", 9f);
            lblUsername.ForeColor = Color.FromArgb(120, 116, 160);
            lblUsername.Location = new Point(22, 42);
            lblUsername.AutoSize = true;
            lblUsername.Text = "Dobrodošli, " + KorisnikManager.TrenutniUsername + "!";

            // ── Left panel ────────────────────────────────────────────────
            pnlLeft.BackColor = Color.White;
            pnlLeft.Location = new Point(20, 68);
            pnlLeft.Size = new Size(390, 490);
            pnlLeft.BorderStyle = BorderStyle.FixedSingle;

            lblOdaberiPlan.Text = "Odaberi plan za danas:";
            lblOdaberiPlan.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
            lblOdaberiPlan.ForeColor = Color.FromArgb(28, 25, 45);
            lblOdaberiPlan.Location = new Point(12, 12);
            lblOdaberiPlan.AutoSize = true;

            cmbPlan.Font = new Font("Segoe UI", 9.5f);
            cmbPlan.Location = new Point(12, 32);
            cmbPlan.Size = new Size(364, 25);
            cmbPlan.FlatStyle = FlatStyle.Flat;
            cmbPlan.DropDownStyle = ComboBoxStyle.DropDownList;

            lblVjezbeUPlanu.Text = "Vježbe u planu:";
            lblVjezbeUPlanu.Font = new Font("Segoe UI", 8.5f, FontStyle.Bold);
            lblVjezbeUPlanu.ForeColor = Color.FromArgb(88, 86, 214);
            lblVjezbeUPlanu.Location = new Point(12, 66);
            lblVjezbeUPlanu.AutoSize = true;

            StilujGrid(dgvPlanVjezbe, new Point(12, 86), new Size(364, 394), 28);

            // ── Right panel ───────────────────────────────────────────────
            pnlRight.BackColor = Color.White;
            pnlRight.Location = new Point(424, 68);
            pnlRight.Size = new Size(530, 490);
            pnlRight.BorderStyle = BorderStyle.FixedSingle;

            lblLogujTrening.Text = "Logiraj današnji trening:";
            lblLogujTrening.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
            lblLogujTrening.ForeColor = Color.FromArgb(28, 25, 45);
            lblLogujTrening.Location = new Point(12, 12);
            lblLogujTrening.AutoSize = true;

            lblLogSub.Text = "Odaberite plan sa lijeve strane.";
            lblLogSub.Font = new Font("Segoe UI", 8.5f);
            lblLogSub.ForeColor = Color.FromArgb(120, 116, 160);
            lblLogSub.Location = new Point(12, 32);
            lblLogSub.AutoSize = true;

            StilujGrid(dgvLogVjezbe, new Point(12, 56), new Size(504, 374), 30);

            // ── Bottom button bar (Dock=Bottom → nema sjeckanja) ──────────
            pnlBottomRight.Dock = DockStyle.Bottom;
            pnlBottomRight.BackColor = Color.White;
            pnlBottomRight.Height = 60;

            StilujBtn(btnZapocniTrening, "▶  Zapocni trening",
                new Point(10, 9), new Size(200, 42),
                Color.FromArgb(34, 139, 34), Color.FromArgb(40, 160, 40));

            StilujBtn(btnSpremiTrening, "✔  Spremi trening",
                new Point(300, 9), new Size(200, 42),
                Color.FromArgb(88, 86, 214), Color.FromArgb(100, 98, 230));
        }

        // ── Helpers ────────────────────────────────────────────────────────
        private void StilujNavBtn(Button btn, string tekst, int y)
        {
            btn.Text = tekst;
            btn.Location = new Point(0, y);
            btn.Size = new Size(200, 48);
            btn.Font = new Font("Segoe UI", 9f);
            btn.ForeColor = Color.FromArgb(190, 186, 225);
            // Eksplicitna sidebar boja — Transparent ne radi ispravno u WinForms
            btn.BackColor = Color.FromArgb(28, 25, 45);
            btn.UseVisualStyleBackColor = false;
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            btn.FlatAppearance.MouseOverBackColor = Color.FromArgb(55, 52, 80);
            btn.FlatAppearance.MouseDownBackColor = Color.FromArgb(70, 66, 100);
            btn.Cursor = Cursors.Hand;
            btn.TextAlign = ContentAlignment.MiddleLeft;
            btn.Padding = new Padding(18, 0, 0, 0);
        }

        private void StilujBtn(Button btn, string tekst,
                               Point loc, Size size, Color bg, Color hover)
        {
            btn.Text = tekst;
            btn.Location = loc;
            btn.Size = size;
            btn.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold);
            btn.BackColor = bg;
            btn.ForeColor = Color.White;
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            btn.FlatAppearance.MouseOverBackColor = hover;
            btn.Cursor = Cursors.Hand;
        }

        private void StilujGrid(DataGridView dgv, Point loc, Size size, int rowH)
        {
            dgv.Location = loc;
            dgv.Size = size;
            dgv.BorderStyle = BorderStyle.None;
            dgv.BackgroundColor = Color.White;
            dgv.RowHeadersVisible = false;
            dgv.EnableHeadersVisualStyles = false;
            dgv.AllowUserToAddRows = false;
            dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgv.AutoGenerateColumns = false;
            dgv.ColumnHeadersHeight = 34;
            dgv.ColumnHeadersHeightSizeMode =
                DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgv.RowTemplate.Height = rowH;
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(28, 25, 45);
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgv.ColumnHeadersDefaultCellStyle.Font =
                new Font("Segoe UI", 8.5f, FontStyle.Bold);
            dgv.DefaultCellStyle.Font = new Font("Segoe UI", 9f);
            dgv.DefaultCellStyle.SelectionBackColor = Color.FromArgb(88, 86, 214);
            dgv.DefaultCellStyle.SelectionForeColor = Color.White;
            dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 248, 252);
        }

        // ══════════════════════════════════════════════════════════════════
        //  NAVIGATION
        // ══════════════════════════════════════════════════════════════════
        private void btnNavKorisnik_Click(object sender, EventArgs e)
        {
            new FrmKorisnik().ShowDialog();
        }

        private void btnNavVjezbe_Click(object sender, EventArgs e)
        {
            new FrmVjezbe().ShowDialog();
        }

        private void btnNavPlanovi_Click(object sender, EventArgs e)
        {
            new FrmTreningPlan().ShowDialog();
            UcitajPlanoviUCombo();
        }

        private void btnNavEvidencija_Click(object sender, EventArgs e)
        {
            new FrmEvidencija().ShowDialog();
        }

        // ══════════════════════════════════════════════════════════════════
        //  PLANS COMBO
        // ══════════════════════════════════════════════════════════════════
        private void UcitajPlanoviUCombo()
        {
            cmbPlan.Items.Clear();
            cmbPlan.Items.Add(new PlanItem { PlanID = -1, Naziv = "-- Odaberi plan --" });
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                using (MySqlCommand cmd = new MySqlCommand(
                    "SELECT PlanID, Naziv FROM treningplan " +
                    "WHERE KorisnikID=@kid ORDER BY Naziv", conn))
                {
                    cmd.Parameters.AddWithValue("@kid", KorisnikManager.TrenutniKorisnikID);
                    using (MySqlDataReader r = cmd.ExecuteReader())
                        while (r.Read())
                            cmbPlan.Items.Add(new PlanItem { PlanID = r.GetInt32(0), Naziv = r.GetString(1) });
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška pri učitavanju planova: " + ex.Message);
            }
            cmbPlan.SelectedIndex = 0;
        }

        private void cmbPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            dgvPlanVjezbe.Rows.Clear();
            planVjezbe.Clear();

            var sel = cmbPlan.SelectedItem as PlanItem;
            if (sel == null || sel.PlanID == -1)
            {
                lblVjezbeUPlanu.Text = "Vježbe u planu:";
                return;
            }

            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                using (MySqlCommand cmd = new MySqlCommand(
                    "SELECT v.VjezbaID, v.Naziv, v.Tip, v.MisicnaGrupa, " +
                    "pv.BrojSetova, pv.BrojPonavljanja " +
                    "FROM planvjezba pv " +
                    "JOIN vjezba v ON v.VjezbaID = pv.VjezbaID " +
                    "WHERE pv.PlanID = @pid ORDER BY v.Naziv", conn))
                {
                    cmd.Parameters.AddWithValue("@pid", sel.PlanID);
                    using (MySqlDataReader r = cmd.ExecuteReader())
                    {
                        while (r.Read())
                        {
                            var red = new PlanVjezbaRed
                            {
                                VjezbaID = r.GetInt32(0),
                                Naziv = r.GetString(1),
                                Tip = r.IsDBNull(2) ? "" : r.GetString(2),
                                Grupa = r.IsDBNull(3) ? "" : r.GetString(3),
                                Setovi = r.IsDBNull(4) ? 0 : r.GetInt32(4),
                                Ponavljanja = r.IsDBNull(5) ? 0 : r.GetInt32(5)
                            };
                            planVjezbe.Add(red);
                            dgvPlanVjezbe.Rows.Add(
                                red.Naziv, red.Tip, red.Grupa,
                                red.Setovi + " x " + red.Ponavljanja);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška: " + ex.Message);
            }
            lblVjezbeUPlanu.Text = "Vježbe u planu: " + dgvPlanVjezbe.Rows.Count;
        }

        // ══════════════════════════════════════════════════════════════════
        //  TRAINING LOG
        // ══════════════════════════════════════════════════════════════════
        private void ProvjeriAktivniTrening()
        {
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                using (MySqlCommand cmd = new MySqlCommand(
                    "SELECT TreningID FROM trening " +
                    "WHERE KorisnikID=@kid AND DATE(Datum)=CURDATE() " +
                    "ORDER BY TreningID DESC LIMIT 1", conn))
                {
                    cmd.Parameters.AddWithValue("@kid", KorisnikManager.TrenutniKorisnikID);
                    object res = cmd.ExecuteScalar();
                    if (res != null && res != DBNull.Value)
                    {
                        aktivniTreningID = Convert.ToInt32(res);
                        UcitajLogTreninga();
                        lblLogSub.Text = "Nastavak treninga od danas  (" +
                            DateTime.Now.ToString("dd.MM.yyyy") + ")";
                        lblLogSub.ForeColor = Color.FromArgb(88, 86, 214);
                    }
                    else
                    {
                        lblLogSub.Text = "Trening nije još pokrenut. Pritisni ▶ za start.";
                        lblLogSub.ForeColor = Color.Gray;
                    }
                }
            }
            catch { }
        }

        private void btnZapocniTrening_Click(object sender, EventArgs e)
        {
            if (aktivniTreningID != -1)
            {
                MessageBox.Show("Trening je već aktivan!", "Info",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                using (MySqlCommand cmd = new MySqlCommand(
                    "INSERT INTO trening (KorisnikID, Datum) VALUES (@kid, NOW())", conn))
                {
                    cmd.Parameters.AddWithValue("@kid", KorisnikManager.TrenutniKorisnikID);
                    cmd.ExecuteNonQuery();
                    aktivniTreningID = Convert.ToInt32(cmd.LastInsertedId);
                }
                lblLogSub.Text = "▶  Trening u toku  —  " +
                    DateTime.Now.ToString("dd.MM.yyyy HH:mm");
                lblLogSub.ForeColor = Color.FromArgb(40, 160, 80);

                dgvLogVjezbe.Rows.Clear();
                foreach (var pv in planVjezbe)
                {
                    int idx = dgvLogVjezbe.Rows.Add(
                        pv.Naziv, pv.Setovi + " x " + pv.Ponavljanja,
                        "", "", "", pv.Ponavljanja, false);
                    dgvLogVjezbe.Rows[idx].Tag = pv.VjezbaID;
                }
            }
            catch (Exception ex) { MessageBox.Show("Greška: " + ex.Message); }
        }

        private void btnSpremiTrening_Click(object sender, EventArgs e)
        {
            if (aktivniTreningID == -1)
            {
                MessageBox.Show("Nema aktivnog treninga za snimanje.", "Upozorenje",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                {
                    foreach (DataGridViewRow row in dgvLogVjezbe.Rows)
                    {
                        if (!(row.Tag is int)) continue;
                        int vid = (int)row.Tag;
                        double set1 = ParseCell(row, "colLSet1");
                        double set2 = ParseCell(row, "colLSet2");
                        double set3 = ParseCell(row, "colLSet3");
                        int pon = (int)ParseCell(row, "colLPon");
                        double maxKg = Math.Max(set1, Math.Max(set2, set3));
                        int setovi = (set1 > 0 ? 1 : 0) + (set2 > 0 ? 1 : 0) + (set3 > 0 ? 1 : 0);
                        if (setovi == 0) setovi = 1;

                        using (MySqlCommand cmd = new MySqlCommand(
                            "INSERT INTO treningvjezba " +
                            "(TreningID,VjezbaID,OdradjeniSetovi,OdradjenaPonavlajnja,MaxTezina,Uradjeno) " +
                            "VALUES (@tid,@vid,@ser,@pon,@kg,1) " +
                            "ON DUPLICATE KEY UPDATE OdradjeniSetovi=@ser," +
                            "OdradjenaPonavlajnja=@pon,MaxTezina=@kg,Uradjeno=1", conn))
                        {
                            cmd.Parameters.AddWithValue("@tid", aktivniTreningID);
                            cmd.Parameters.AddWithValue("@vid", vid);
                            cmd.Parameters.AddWithValue("@ser", setovi);
                            cmd.Parameters.AddWithValue("@pon", pon);
                            cmd.Parameters.AddWithValue("@kg",
                                maxKg > 0 ? (object)maxKg : DBNull.Value);
                            cmd.ExecuteNonQuery();
                        }
                    }
                }
                MessageBox.Show("Trening uspješno snimljen!", "Uspjeh",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                lblLogSub.Text = "✔  Snimljeno  —  " +
                    DateTime.Now.ToString("dd.MM.yyyy HH:mm");
                lblLogSub.ForeColor = Color.FromArgb(88, 86, 214);
            }
            catch (Exception ex) { MessageBox.Show("Greška: " + ex.Message); }
        }

        private void UcitajLogTreninga()
        {
            dgvLogVjezbe.Rows.Clear();
            if (aktivniTreningID == -1) return;
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                using (MySqlCommand cmd = new MySqlCommand(
                    "SELECT tv.VjezbaID, v.Naziv, tv.OdradjeniSetovi, " +
                    "tv.OdradjenaPonavlajnja, tv.MaxTezina, tv.Uradjeno " +
                    "FROM treningvjezba tv " +
                    "JOIN vjezba v ON v.VjezbaID = tv.VjezbaID " +
                    "WHERE tv.TreningID = @tid ORDER BY v.Naziv", conn))
                {
                    cmd.Parameters.AddWithValue("@tid", aktivniTreningID);
                    using (MySqlDataReader r = cmd.ExecuteReader())
                    {
                        while (r.Read())
                        {
                            int vid = r.GetInt32(0);
                            string naz = r.GetString(1);
                            int ser = r.IsDBNull(2) ? 0 : r.GetInt32(2);
                            int pon = r.IsDBNull(3) ? 0 : r.GetInt32(3);
                            double kg = r.IsDBNull(4) ? 0 : r.GetDouble(4);
                            bool ura = !r.IsDBNull(5) && r.GetInt32(5) == 1;
                            string kgStr = kg > 0 ? kg.ToString("0.##") : "";
                            int idx = dgvLogVjezbe.Rows.Add(
                                naz, ser + " x " + pon,
                                kgStr, kgStr, kgStr, pon, ura);
                            dgvLogVjezbe.Rows[idx].Tag = vid;
                        }
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show("Greška: " + ex.Message); }
        }

        private double ParseCell(DataGridViewRow row, string col)
        {
            try
            {
                var v = row.Cells[col].Value;
                if (v == null || v.ToString().Trim() == "") return 0;
                double d;
                double.TryParse(v.ToString().Replace(",", "."),
                    System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture, out d);
                return d;
            }
            catch { return 0; }
        }
    }
}