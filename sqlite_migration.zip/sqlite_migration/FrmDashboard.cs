using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Data.SQLite;

namespace WindowsFormsApplication1
{
    public partial class FrmDashboard : Form
    {
        private int aktivniTreningID = -1;

        private class TabelaRed
        {
            public int    VjezbaID;
            public string Vjezbanaziv;
            public int    Serije;
            public int    Ponavljanja;
            public double MaxKilaza;
        }

        public FrmDashboard()
        {
            InitializeComponent();
        }

        private void FrmDashboard_Load(object sender, EventArgs e)
        {
            UcitajVjezbeUCombo();
            ProvjeriAktivniTrening();
        }

        private void UcitajVjezbeUCombo()
        {
            cmbVjezba.Items.Clear();
            cmbVjezba.Items.Add(new VjezbaItem { VjezbaID = -1, Naziv = "-- Odaberi vježbu --" });
            try
            {
                using (SQLiteConnection conn = DbHelper.GetConnection())
                using (SQLiteCommand cmd = new SQLiteCommand(
                    "SELECT VjezbaID, Naziv FROM vjezba ORDER BY Naziv", conn))
                using (SQLiteDataReader r = cmd.ExecuteReader())
                    while (r.Read())
                        cmbVjezba.Items.Add(new VjezbaItem
                            { VjezbaID = r.GetInt32(0), Naziv = r.GetString(1) });
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška pri učitavanju vježbi: " + ex.Message);
            }
            cmbVjezba.SelectedIndex = 0;
        }

        private void ProvjeriAktivniTrening()
        {
            try
            {
                using (SQLiteConnection conn = DbHelper.GetConnection())
                using (SQLiteCommand cmd = new SQLiteCommand(
                    "SELECT TreningID FROM trening " +
                    "WHERE KorisnikID=@kid AND date(Datum)=date('now') " +
                    "ORDER BY TreningID DESC LIMIT 1", conn))
                {
                    cmd.Parameters.AddWithValue("@kid", KorisnikManager.TrenutniKorisnikID);
                    object res = cmd.ExecuteScalar();
                    if (res != null && res != DBNull.Value)
                    {
                        aktivniTreningID = Convert.ToInt32(res);
                        UcitajStavkeTreninga();
                        lblStatus.Text      = "Nastavak treninga od danas  (" + DateTime.Now.ToString("dd.MM.yyyy") + ")";
                        lblStatus.ForeColor = Color.FromArgb(88, 86, 214);
                    }
                    else
                    {
                        lblStatus.Text      = "Novi trening nije još pokrenut. Pritisni  ▶  za start.";
                        lblStatus.ForeColor = Color.Gray;
                    }
                }
            }
            catch { }
        }

        private void btnStartTrening_Click(object sender, EventArgs e)
        {
            if (aktivniTreningID != -1)
            {
                MessageBox.Show("Trening je već aktivan!", "Info",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                using (SQLiteConnection conn = DbHelper.GetConnection())
                using (SQLiteCommand cmd = new SQLiteCommand(
                    "INSERT INTO trening (KorisnikID, Datum) VALUES (@kid, datetime('now'))", conn))
                {
                    cmd.Parameters.AddWithValue("@kid", KorisnikManager.TrenutniKorisnikID);
                    cmd.ExecuteNonQuery();
                    aktivniTreningID = (int)conn.LastInsertRowId;
                }

                lblStatus.Text      = "▶  Trening u toku  —  " + DateTime.Now.ToString("dd.MM.yyyy HH:mm");
                lblStatus.ForeColor = Color.FromArgb(40, 160, 80);
                dgvVjezbe.Rows.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška: " + ex.Message);
            }
        }

        private void btnDodajVjezbu_Click(object sender, EventArgs e)
        {
            if (aktivniTreningID == -1)
            {
                MessageBox.Show("Najpre pokreni trening pritiskom na ▶ Start trening!", "Upozorenje",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var sel = cmbVjezba.SelectedItem as VjezbaItem;
            if (sel == null || sel.VjezbaID == -1)
            {
                MessageBox.Show("Odaberi vježbu!", "Upozorenje",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int serije;
            if (!int.TryParse(txtSerije.Text.Trim(), out serije) || serije < 1 || serije > 99)
            {
                MessageBox.Show("Upiši broj serija (1-99)!", "Upozorenje",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtSerije.Focus(); return;
            }

            int ponavljanja;
            if (!int.TryParse(txtPonavljanja.Text.Trim(), out ponavljanja)
                || ponavljanja < 1 || ponavljanja > 999)
            {
                MessageBox.Show("Upiši broj ponavljanja (1-999)!", "Upozorenje",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPonavljanja.Focus(); return;
            }

            double kilaza = 0;
            if (txtKilaza.Text.Trim() != "")
            {
                if (!double.TryParse(txtKilaza.Text.Trim().Replace(",", "."),
                    System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture, out kilaza)
                    || kilaza < 0)
                {
                    MessageBox.Show("Kilaza mora biti pozitivan broj!", "Upozorenje",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtKilaza.Focus(); return;
                }
            }

            try
            {
                using (SQLiteConnection conn = DbHelper.GetConnection())
                using (SQLiteCommand cmd = new SQLiteCommand(
                    // INSERT OR REPLACE zamjenjuje MySQL-ov ON DUPLICATE KEY UPDATE
                    "INSERT OR REPLACE INTO treningvjezba " +
                    "(TreningID, VjezbaID, OdradjeniSetovi, OdradjenaPonavlajnja, MaxTezina, Uradjeno) " +
                    "VALUES (@tid, @vid, @ser, @pon, @kg, 1)", conn))
                {
                    cmd.Parameters.AddWithValue("@tid", aktivniTreningID);
                    cmd.Parameters.AddWithValue("@vid", sel.VjezbaID);
                    cmd.Parameters.AddWithValue("@ser", serije);
                    cmd.Parameters.AddWithValue("@pon", ponavljanja);
                    cmd.Parameters.AddWithValue("@kg",  kilaza > 0 ? (object)kilaza : DBNull.Value);
                    cmd.ExecuteNonQuery();
                }

                bool pronadjen = false;
                foreach (DataGridViewRow row in dgvVjezbe.Rows)
                {
                    if (row.Tag is int && (int)row.Tag == sel.VjezbaID)
                    {
                        row.Cells["colSerije"].Value      = serije;
                        row.Cells["colPonavljanja"].Value = ponavljanja;
                        row.Cells["colKilaza"].Value      = kilaza > 0 ? kilaza.ToString("0.##") + " kg" : "-";
                        row.Cells["colVolumen"].Value     = (serije * ponavljanja * kilaza).ToString("0.#");
                        pronadjen = true;
                        break;
                    }
                }

                if (!pronadjen)
                {
                    int idx = dgvVjezbe.Rows.Add(
                        sel.Naziv, serije, ponavljanja,
                        kilaza > 0 ? kilaza.ToString("0.##") + " kg" : "-",
                        (serije * ponavljanja * kilaza).ToString("0.#")
                    );
                    dgvVjezbe.Rows[idx].Tag = sel.VjezbaID;
                }

                cmbVjezba.SelectedIndex = 0;
                txtSerije.Clear();
                txtPonavljanja.Clear();
                txtKilaza.Clear();

                lblVjezbeUkupno.Text = "Vježbi danas: " + dgvVjezbe.Rows.Count;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška pri dodavanju: " + ex.Message);
            }
        }

        private void UcitajStavkeTreninga()
        {
            dgvVjezbe.Rows.Clear();
            if (aktivniTreningID == -1) return;
            try
            {
                using (SQLiteConnection conn = DbHelper.GetConnection())
                using (SQLiteCommand cmd = new SQLiteCommand(
                    "SELECT tv.VjezbaID, v.Naziv, tv.OdradjeniSetovi, " +
                    "tv.OdradjenaPonavlajnja, tv.MaxTezina " +
                    "FROM treningvjezba tv " +
                    "JOIN vjezba v ON v.VjezbaID=tv.VjezbaID " +
                    "WHERE tv.TreningID=@tid ORDER BY v.Naziv", conn))
                {
                    cmd.Parameters.AddWithValue("@tid", aktivniTreningID);
                    using (SQLiteDataReader r = cmd.ExecuteReader())
                    {
                        while (r.Read())
                        {
                            int    vid  = r.GetInt32(0);
                            string naz  = r.GetString(1);
                            int    ser  = r.IsDBNull(2) ? 0 : r.GetInt32(2);
                            int    pon  = r.IsDBNull(3) ? 0 : r.GetInt32(3);
                            double kg   = r.IsDBNull(4) ? 0 : r.GetDouble(4);
                            double vol  = ser * pon * kg;

                            int idx = dgvVjezbe.Rows.Add(
                                naz, ser, pon,
                                kg > 0 ? kg.ToString("0.##") + " kg" : "-",
                                vol > 0 ? vol.ToString("0.#") : "-"
                            );
                            dgvVjezbe.Rows[idx].Tag = vid;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška pri učitavanju: " + ex.Message);
            }

            lblVjezbeUkupno.Text = "Vježbi danas: " + dgvVjezbe.Rows.Count;
        }

        private void btnVjezbe_Click(object sender, EventArgs e)
        {
            FrmEvidencija frm = new FrmEvidencija();
            frm.ShowDialog();
        }

        private void btnProfil_Click(object sender, EventArgs e)
        {
            FrmKorisnik frm = new FrmKorisnik();
            frm.ShowDialog();
        }

        private void btnUkloni_Click(object sender, EventArgs e)
        {
            if (dgvVjezbe.SelectedRows.Count == 0)
            {
                MessageBox.Show("Odaberi vježbu za uklanjanje.", "Upozorenje",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var row = dgvVjezbe.SelectedRows[0];
            int vid = row.Tag is int ? (int)row.Tag : -1;

            if (MessageBox.Show("Obrisati ovu vježbu iz treninga?", "Potvrda",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;

            try
            {
                if (aktivniTreningID != -1 && vid != -1)
                {
                    using (SQLiteConnection conn = DbHelper.GetConnection())
                    using (SQLiteCommand cmd = new SQLiteCommand(
                        "DELETE FROM treningvjezba WHERE TreningID=@tid AND VjezbaID=@vid", conn))
                    {
                        cmd.Parameters.AddWithValue("@tid", aktivniTreningID);
                        cmd.Parameters.AddWithValue("@vid", vid);
                        cmd.ExecuteNonQuery();
                    }
                }
                dgvVjezbe.Rows.Remove(row);
                lblVjezbeUkupno.Text = "Vježbi danas: " + dgvVjezbe.Rows.Count;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška: " + ex.Message);
            }
        }

        private class VjezbaItem
        {
            public int    VjezbaID;
            public string Naziv;
            public override string ToString() { return Naziv; }
        }
    }
}
