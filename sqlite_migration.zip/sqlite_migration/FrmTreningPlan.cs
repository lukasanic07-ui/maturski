using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Data.SQLite;

namespace WindowsFormsApplication1
{
    public class FrmTreningPlan : Form
    {
        private Panel        pnlLijevo;
        private Panel        pnlLijevoHeader;
        private Label        lblGymLogo;
        private Label        lblPlanovi;
        private ListBox      lstbPlanovi;
        private Button       btnNoviPlan;
        private Button       btnObrisiPlan;
        private Panel        pnlDesno;
        private Panel        pnlDesnoHeader;
        private Label        lblDesnoNaslov;
        private Label        lblNaziv;
        private TextBox      txtNazivPlana;
        private DataGridView dgvVjezbeZaDan;
        private Button       btnDodajVjezbu;
        private Button       btnObrisiVjezbu;
        private Button       btnSpremiPlan;
        private Label        lblStatus;
        private Panel        pnlLegenda;

        private List<TreningVjezba> vjezbeZaDan = new List<TreningVjezba>();
        private int  odabraniPlanID = -1;
        private bool noviPlanMode   = false;

        private class TreningVjezba
        {
            public int    VjezbaID;
            public string Naziv;
            public string Opis;
            public string Tip;
            public string MisicnaGrupa;
            public int    BrojSetova      = 3;
            public int    BrojPonavljanja = 10;
        }

        public class PlanItem
        {
            public int    PlanID;
            public string Naziv;
            public override string ToString() { return Naziv; }
        }

        private static string TipIkona(string tip)
        {
            if (tip == null) return "❓";
            switch (tip.Trim())
            {
                case "Snaga":        return "🏋️ Snaga";
                case "Kardio":       return "🏃 Kardio";
                case "Mobilnost":    return "🧘 Mobilnost";
                case "Izdrzljivost": return "💪 Izdržljivost";
                default:             return "🏅 " + tip;
            }
        }

        private static Color TipBoja(string tip)
        {
            if (tip == null) return Color.FromArgb(245, 245, 245);
            switch (tip.Trim())
            {
                case "Snaga":        return Color.FromArgb(255, 228, 218);
                case "Kardio":       return Color.FromArgb(212, 245, 212);
                case "Mobilnost":    return Color.FromArgb(210, 232, 255);
                case "Izdrzljivost": return Color.FromArgb(235, 218, 255);
                default:             return Color.FromArgb(242, 242, 242);
            }
        }

        private static Color TipBojaTamna(string tip)
        {
            if (tip == null) return Color.Gray;
            switch (tip.Trim())
            {
                case "Snaga":        return Color.FromArgb(180, 50,  10);
                case "Kardio":       return Color.FromArgb(20,  120, 50);
                case "Mobilnost":    return Color.FromArgb(20,  80,  180);
                case "Izdrzljivost": return Color.FromArgb(100, 30,  180);
                default:             return Color.FromArgb(60, 60, 60);
            }
        }

        public FrmTreningPlan()
        {
            GradiForme();
            PrimijeniStil();
            UcitajPlanove();
        }

        private void GradiForme()
        {
            this.SuspendLayout();
            this.Text          = "Trening Planovi";
            this.ClientSize    = new Size(980, 600);
            this.MinimumSize   = new Size(980, 600);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Font          = new Font("Segoe UI", 9f);
            this.BackColor     = Color.FromArgb(245, 247, 250);

            pnlLijevo = new Panel { Dock = DockStyle.Left, Size = new Size(215, 600), Padding = new Padding(0) };
            pnlLijevoHeader = new Panel { Dock = DockStyle.Top, Height = 90 };
            lblGymLogo = new Label { Text = "🏋️", Location = new Point(20, 10), AutoSize = true, Font = new Font("Segoe UI", 28f) };
            lblPlanovi = new Label { Text = "Moji planovi", Location = new Point(12, 60), AutoSize = true };
            pnlLijevoHeader.Controls.Add(lblGymLogo);
            pnlLijevoHeader.Controls.Add(lblPlanovi);

            lstbPlanovi = new ListBox
            {
                Location    = new Point(0, 98),
                Size        = new Size(215, 400),
                BorderStyle = BorderStyle.None,
                DrawMode    = DrawMode.OwnerDrawFixed,
                ItemHeight  = 38
            };
            lstbPlanovi.DrawItem             += lstbPlanovi_DrawItem;
            lstbPlanovi.SelectedIndexChanged += lstbPlanovi_SelectedIndexChanged;

            btnNoviPlan   = new Button { Text = "+ Novi plan",   Location = new Point(4,   508), Size = new Size(100, 36) };
            btnObrisiPlan = new Button { Text = "🗑 Obriši plan", Location = new Point(110, 508), Size = new Size(100, 36) };
            btnNoviPlan.Click   += btnNoviPlan_Click;
            btnObrisiPlan.Click += btnObrisiPlan_Click;

            pnlLijevo.Controls.Add(pnlLijevoHeader);
            pnlLijevo.Controls.Add(lstbPlanovi);
            pnlLijevo.Controls.Add(btnNoviPlan);
            pnlLijevo.Controls.Add(btnObrisiPlan);

            pnlDesno      = new Panel { Dock = DockStyle.Fill, Padding = new Padding(16) };
            pnlDesnoHeader= new Panel { Location = new Point(16, 10), Size = new Size(720, 44), BackColor = Color.Transparent };
            lblDesnoNaslov= new Label { Text = "Plan treninga", Location = new Point(0, 8),  AutoSize = true };
            lblNaziv      = new Label { Text = "Naziv:",        Location = new Point(0, 58), AutoSize = true };
            txtNazivPlana = new TextBox { Location = new Point(70, 55), Size = new Size(300, 26), ReadOnly = true };

            pnlLegenda = new Panel { Location = new Point(380, 50), Size = new Size(340, 32), BackColor = Color.Transparent };
            KreirajLegendU(pnlLegenda);

            dgvVjezbeZaDan = new DataGridView
            {
                Location            = new Point(16, 100),
                Size                = new Size(720, 380),
                ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing,
                ReadOnly            = true,
                AllowUserToAddRows  = false,
                SelectionMode       = DataGridViewSelectionMode.FullRowSelect,
                AutoGenerateColumns = false,
                ColumnHeadersHeight = 40
            };
            dgvVjezbeZaDan.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Tip",           Name = "cTipIkona", Width = 130 });
            dgvVjezbeZaDan.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Naziv vježbe",  Name = "cNaziv",    Width = 200 });
            dgvVjezbeZaDan.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Mišićna grupa", Name = "cGrupa",    Width = 130 });
            dgvVjezbeZaDan.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Setovi",         Name = "cSetovi",   Width = 75  });
            dgvVjezbeZaDan.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Ponavljanja",    Name = "cPon",      Width = 100 });
            dgvVjezbeZaDan.CellFormatting += dgvVjezbeZaDan_CellFormatting;
            dgvVjezbeZaDan.RowPrePaint    += dgvVjezbeZaDan_RowPrePaint;

            btnDodajVjezbu  = new Button { Text = "➕  Dodaj vježbu",  Location = new Point(16,  492), Size = new Size(150, 38) };
            btnObrisiVjezbu = new Button { Text = "🗑  Obriši vježbu", Location = new Point(176, 492), Size = new Size(150, 38) };
            btnSpremiPlan   = new Button { Text = "💾  Spremi plan",   Location = new Point(586, 492), Size = new Size(150, 38) };
            btnDodajVjezbu.Click  += btnDodajVjezbu_Click;
            btnObrisiVjezbu.Click += btnObrisiVjezbu_Click;
            btnSpremiPlan.Click   += btnSpremiPlan_Click;

            lblStatus = new Label { Text = "Odaberite plan sa lijeve strane ili kreirajte novi.", Location = new Point(16, 545), Size = new Size(650, 20), AutoSize = false };

            pnlDesno.Controls.Add(pnlDesnoHeader);
            pnlDesno.Controls.Add(lblDesnoNaslov);
            pnlDesno.Controls.Add(lblNaziv);
            pnlDesno.Controls.Add(txtNazivPlana);
            pnlDesno.Controls.Add(pnlLegenda);
            pnlDesno.Controls.Add(dgvVjezbeZaDan);
            pnlDesno.Controls.Add(btnDodajVjezbu);
            pnlDesno.Controls.Add(btnObrisiVjezbu);
            pnlDesno.Controls.Add(btnSpremiPlan);
            pnlDesno.Controls.Add(lblStatus);

            this.Controls.Add(pnlDesno);
            this.Controls.Add(pnlLijevo);
            this.ResumeLayout(false);
        }

        private void KreirajLegendU(Panel p)
        {
            string[] tipovi = { "Snaga", "Kardio", "Mobilnost", "Izdrzljivost" };
            string[] ikone  = { "🏋️", "🏃", "🧘", "💪" };
            int x = 0;
            for (int i = 0; i < tipovi.Length; i++)
            {
                var lbl = new Label
                {
                    Text      = ikone[i] + " " + tipovi[i],
                    Location  = new Point(x, 5),
                    AutoSize  = true,
                    Font      = new Font("Segoe UI", 8f, FontStyle.Bold),
                    ForeColor = TipBojaTamna(tipovi[i]),
                    Padding   = new Padding(4, 2, 4, 2)
                };
                p.Controls.Add(lbl);
                x += 82;
            }
        }

        private void PrimijeniStil()
        {
            pnlLijevo.BackColor       = Color.FromArgb(28, 28, 38);
            pnlLijevoHeader.BackColor = Color.FromArgb(28, 28, 38);
            lblGymLogo.ForeColor  = Color.White;
            lblPlanovi.ForeColor  = Color.FromArgb(180, 180, 210);
            lblPlanovi.Font       = new Font("Segoe UI", 10f, FontStyle.Bold);
            lstbPlanovi.BackColor = Color.FromArgb(38, 38, 52);
            lstbPlanovi.ForeColor = Color.White;
            lstbPlanovi.Font      = new Font("Segoe UI", 10f);
            StilBtn(btnNoviPlan,     Color.FromArgb(88, 86, 214), Color.White);
            StilBtn(btnObrisiPlan,   Color.FromArgb(180, 40, 40), Color.White);
            StilBtn(btnDodajVjezbu,  Color.FromArgb(40, 160, 70), Color.White);
            StilBtn(btnObrisiVjezbu, Color.FromArgb(180, 40, 40), Color.White);
            StilBtn(btnSpremiPlan,   Color.FromArgb(88, 86, 214), Color.White);
            pnlDesno.BackColor    = Color.FromArgb(245, 247, 250);
            lblDesnoNaslov.Font   = new Font("Segoe UI", 16f, FontStyle.Bold);
            lblDesnoNaslov.ForeColor = Color.FromArgb(28, 28, 38);
            lblNaziv.Font         = new Font("Segoe UI", 10f, FontStyle.Bold);
            lblNaziv.ForeColor    = Color.FromArgb(88, 86, 214);
            txtNazivPlana.Font    = new Font("Segoe UI", 10f);
            txtNazivPlana.BorderStyle = BorderStyle.FixedSingle;
            lblStatus.ForeColor   = Color.FromArgb(100, 100, 120);
            lblStatus.Font        = new Font("Segoe UI", 9f, FontStyle.Italic);
            dgvVjezbeZaDan.BackgroundColor = Color.White;
            dgvVjezbeZaDan.BorderStyle     = BorderStyle.None;
            dgvVjezbeZaDan.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgvVjezbeZaDan.GridColor       = Color.FromArgb(220, 220, 228);
            dgvVjezbeZaDan.RowHeadersVisible = false;
            dgvVjezbeZaDan.EnableHeadersVisualStyles = false;
            dgvVjezbeZaDan.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(28, 28, 38);
            dgvVjezbeZaDan.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgvVjezbeZaDan.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold);
            dgvVjezbeZaDan.DefaultCellStyle.Font    = new Font("Segoe UI", 9.5f);
            dgvVjezbeZaDan.DefaultCellStyle.Padding = new Padding(6, 4, 6, 4);
            dgvVjezbeZaDan.DefaultCellStyle.SelectionBackColor = Color.FromArgb(88, 86, 214);
            dgvVjezbeZaDan.DefaultCellStyle.SelectionForeColor = Color.White;
            dgvVjezbeZaDan.RowTemplate.Height = 36;
        }

        private void StilBtn(Button b, Color back, Color fore)
        {
            b.FlatStyle = FlatStyle.Flat; b.FlatAppearance.BorderSize = 0;
            b.BackColor = back; b.ForeColor = fore;
            b.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold); b.Cursor = Cursors.Hand;
        }

        private void dgvVjezbeZaDan_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            if (e.RowIndex < 0 || e.RowIndex >= vjezbeZaDan.Count) return;
            dgvVjezbeZaDan.Rows[e.RowIndex].DefaultCellStyle.BackColor = TipBoja(vjezbeZaDan[e.RowIndex].Tip);
        }

        private void dgvVjezbeZaDan_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.RowIndex < 0 || e.RowIndex >= vjezbeZaDan.Count) return;
            string tip = vjezbeZaDan[e.RowIndex].Tip;
            if (dgvVjezbeZaDan.Columns[e.ColumnIndex].Name == "cTipIkona")
            {
                e.CellStyle.ForeColor = TipBojaTamna(tip);
                e.CellStyle.Font      = new Font("Segoe UI", 9.5f, FontStyle.Bold);
                e.CellStyle.BackColor = TipBoja(tip);
            }
        }

        private void lstbPlanovi_DrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0) return;
            bool sel = (e.State & DrawItemState.Selected) != 0;
            Color bg = sel ? Color.FromArgb(88, 86, 214)
                : (e.Index % 2 == 0 ? Color.FromArgb(38, 38, 52) : Color.FromArgb(44, 44, 60));
            e.Graphics.FillRectangle(new SolidBrush(bg), e.Bounds);
            e.Graphics.DrawString("📋  " + lstbPlanovi.Items[e.Index].ToString(),
                new Font("Segoe UI", 9.5f, sel ? FontStyle.Bold : FontStyle.Regular),
                new SolidBrush(Color.White),
                new PointF(e.Bounds.X + 8, e.Bounds.Y + 10));
        }

        private void UcitajPlanove()
        {
            lstbPlanovi.Items.Clear();
            try
            {
                using (SQLiteConnection conn = DbHelper.GetConnection())
                using (SQLiteCommand cmd = new SQLiteCommand(
                    "SELECT PlanID, Naziv FROM treningplan " +
                    "WHERE KorisnikID=@kid ORDER BY DatumKreiranja DESC", conn))
                {
                    cmd.Parameters.AddWithValue("@kid", KorisnikManager.TrenutniKorisnikID);
                    using (SQLiteDataReader r = cmd.ExecuteReader())
                        while (r.Read())
                            lstbPlanovi.Items.Add(new PlanItem { PlanID = r.GetInt32(0), Naziv = r.GetString(1) });
                }
            }
            catch (Exception ex) { MessageBox.Show("Greška učitavanja planova: " + ex.Message); }
        }

        private void lstbPlanovi_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstbPlanovi.SelectedItem == null) return;
            noviPlanMode = false;
            var plan = (PlanItem)lstbPlanovi.SelectedItem;
            odabraniPlanID       = plan.PlanID;
            txtNazivPlana.Text   = plan.Naziv;
            txtNazivPlana.ReadOnly = true;
            UcitajVjezbeZaPlan(plan.PlanID);
            lblStatus.Text      = "Plan učitan. Dodajte ili obrišite vježbe.";
            lblDesnoNaslov.Text = "📋  " + plan.Naziv;
        }

        private void UcitajVjezbeZaPlan(int planID)
        {
            vjezbeZaDan.Clear();
            try
            {
                using (SQLiteConnection conn = DbHelper.GetConnection())
                using (SQLiteCommand cmd = new SQLiteCommand(
                    "SELECT v.VjezbaID, v.Naziv, v.Opis, v.Tip, v.MisicnaGrupa, " +
                    "pv.BrojSetova, pv.BrojPonavljanja " +
                    "FROM planvjezba pv JOIN vjezba v ON v.VjezbaID=pv.VjezbaID " +
                    "WHERE pv.PlanID=@pid", conn))
                {
                    cmd.Parameters.AddWithValue("@pid", planID);
                    using (SQLiteDataReader r = cmd.ExecuteReader())
                        while (r.Read())
                            vjezbeZaDan.Add(new TreningVjezba
                            {
                                VjezbaID        = r.GetInt32(0),
                                Naziv           = r.GetString(1),
                                Opis            = r.IsDBNull(2) ? "" : r.GetString(2),
                                Tip             = r.GetString(3),
                                MisicnaGrupa    = r.GetString(4),
                                BrojSetova      = r.IsDBNull(5) ? 3  : r.GetInt32(5),
                                BrojPonavljanja = r.IsDBNull(6) ? 10 : r.GetInt32(6)
                            });
                }
            }
            catch (Exception ex) { MessageBox.Show("Greška: " + ex.Message); }
            OsvjeziGrid();
        }

        private void OsvjeziGrid()
        {
            dgvVjezbeZaDan.Rows.Clear();
            foreach (TreningVjezba v in vjezbeZaDan)
                dgvVjezbeZaDan.Rows.Add(TipIkona(v.Tip), v.Naziv, v.MisicnaGrupa, v.BrojSetova, v.BrojPonavljanja);
        }

        private void btnNoviPlan_Click(object sender, EventArgs e)
        {
            noviPlanMode = true; odabraniPlanID = -1;
            vjezbeZaDan.Clear(); OsvjeziGrid();
            txtNazivPlana.ReadOnly = false;
            txtNazivPlana.Text     = "Novi plan " + DateTime.Now.ToString("dd.MM.yyyy");
            txtNazivPlana.Focus();
            lstbPlanovi.ClearSelected();
            lblDesnoNaslov.Text = "✏️  Novi plan";
            lblStatus.Text = "Unesite naziv i dodajte vježbe, zatim kliknite Spremi.";
        }

        private void btnDodajVjezbu_Click(object sender, EventArgs e)
        {
            if (!noviPlanMode && odabraniPlanID == -1)
            { MessageBox.Show("Odaberite plan ili kliknite 'Novi plan'!"); return; }

            FrmVjezbe f = new FrmVjezbe();
            if (f.ShowDialog() == DialogResult.OK && f.OdabranaVjezba != null)
            {
                foreach (TreningVjezba tv in vjezbeZaDan)
                    if (tv.VjezbaID == f.OdabranaVjezba.VjezbaID)
                    { MessageBox.Show("Ta vježba je već u planu!"); return; }

                vjezbeZaDan.Add(new TreningVjezba
                {
                    VjezbaID        = f.OdabranaVjezba.VjezbaID,
                    Naziv           = f.OdabranaVjezba.Naziv,
                    Opis            = f.OdabranaVjezba.Opis,
                    Tip             = f.OdabranaVjezba.Tip,
                    MisicnaGrupa    = f.OdabranaVjezba.MisicnaGrupa,
                    BrojSetova      = 3,
                    BrojPonavljanja = 10
                });
                OsvjeziGrid();
                if (!noviPlanMode) AzurirajPlanUBazi();
            }
        }

        private void btnObrisiVjezbu_Click(object sender, EventArgs e)
        {
            if (dgvVjezbeZaDan.CurrentRow == null)
            { MessageBox.Show("Odaberite vježbu za brisanje!"); return; }
            int idx = dgvVjezbeZaDan.CurrentRow.Index;
            if (idx < 0 || idx >= vjezbeZaDan.Count) return;

            if (!noviPlanMode && odabraniPlanID != -1)
            {
                try
                {
                    using (SQLiteConnection conn = DbHelper.GetConnection())
                    using (SQLiteCommand cmd = new SQLiteCommand(
                        "DELETE FROM planvjezba WHERE PlanID=@pid AND VjezbaID=@vid", conn))
                    {
                        cmd.Parameters.AddWithValue("@pid", odabraniPlanID);
                        cmd.Parameters.AddWithValue("@vid", vjezbeZaDan[idx].VjezbaID);
                        cmd.ExecuteNonQuery();
                    }
                }
                catch (Exception ex) { MessageBox.Show("Greška: " + ex.Message); return; }
            }
            vjezbeZaDan.RemoveAt(idx);
            OsvjeziGrid();
            lblStatus.Text = "Vježba obrisana.";
        }

        private void btnObrisiPlan_Click(object sender, EventArgs e)
        {
            if (odabraniPlanID == -1) { MessageBox.Show("Odaberite plan!"); return; }
            var plan = lstbPlanovi.SelectedItem as PlanItem;
            if (plan == null) return;
            if (MessageBox.Show("Obrisati plan '" + plan.Naziv + "'?", "Potvrda",
                MessageBoxButtons.YesNo) != DialogResult.Yes) return;
            try
            {
                using (SQLiteConnection conn = DbHelper.GetConnection())
                {
                    using (SQLiteCommand cmd = new SQLiteCommand("DELETE FROM planvjezba WHERE PlanID=@pid", conn))
                    { cmd.Parameters.AddWithValue("@pid", odabraniPlanID); cmd.ExecuteNonQuery(); }
                    using (SQLiteCommand cmd = new SQLiteCommand("DELETE FROM treningplan WHERE PlanID=@pid", conn))
                    { cmd.Parameters.AddWithValue("@pid", odabraniPlanID); cmd.ExecuteNonQuery(); }
                }
                odabraniPlanID = -1;
                vjezbeZaDan.Clear(); OsvjeziGrid();
                txtNazivPlana.Text = ""; lblDesnoNaslov.Text = "Plan treninga";
                UcitajPlanove();
            }
            catch (Exception ex) { MessageBox.Show("Greška: " + ex.Message); }
        }

        private void btnSpremiPlan_Click(object sender, EventArgs e)
        {
            if (vjezbeZaDan.Count == 0) { MessageBox.Show("Dodaj barem jednu vježbu!"); return; }
            string naziv = txtNazivPlana.Text.Trim();
            if (naziv.Length == 0) { MessageBox.Show("Upisite naziv plana!"); return; }
            if (noviPlanMode) SpremiNoviPlan(naziv);
            else AzurirajPlanUBazi();
        }

        private void SpremiNoviPlan(string naziv)
        {
            try
            {
                int planID;
                using (SQLiteConnection conn = DbHelper.GetConnection())
                {
                    using (SQLiteCommand cmd = new SQLiteCommand(
                        "INSERT INTO treningplan (KorisnikID, Naziv, DatumKreiranja) " +
                        "VALUES (@kid, @n, @d)", conn))
                    {
                        cmd.Parameters.AddWithValue("@kid", KorisnikManager.TrenutniKorisnikID);
                        cmd.Parameters.AddWithValue("@n",   naziv);
                        cmd.Parameters.AddWithValue("@d",   DateTime.Now.ToString("yyyy-MM-dd"));
                        cmd.ExecuteNonQuery();
                        planID = (int)conn.LastInsertRowId; // SQLite: LastInsertRowId umjesto LAST_INSERT_ID()
                    }
                    foreach (TreningVjezba v in vjezbeZaDan)
                        using (SQLiteCommand cmd = new SQLiteCommand(
                            "INSERT INTO planvjezba (PlanID, VjezbaID, BrojSetova, BrojPonavljanja) " +
                            "VALUES (@pid, @vid, @bs, @bp)", conn))
                        {
                            cmd.Parameters.AddWithValue("@pid", planID);
                            cmd.Parameters.AddWithValue("@vid", v.VjezbaID);
                            cmd.Parameters.AddWithValue("@bs",  v.BrojSetova);
                            cmd.Parameters.AddWithValue("@bp",  v.BrojPonavljanja);
                            cmd.ExecuteNonQuery();
                        }
                    odabraniPlanID = planID;
                    noviPlanMode   = false;
                    txtNazivPlana.ReadOnly = true;
                }
                MessageBox.Show("Plan '" + naziv + "' sačuvan!");
                lblStatus.Text = "✅  Plan sačuvan!";
                UcitajPlanove();
                foreach (object item in lstbPlanovi.Items)
                    if (((PlanItem)item).PlanID == odabraniPlanID)
                    { lstbPlanovi.SelectedItem = item; break; }
            }
            catch (Exception ex) { MessageBox.Show("Greška: " + ex.Message); }
        }

        private void AzurirajPlanUBazi()
        {
            if (odabraniPlanID == -1) return;
            try
            {
                using (SQLiteConnection conn = DbHelper.GetConnection())
                {
                    using (SQLiteCommand cmd = new SQLiteCommand("DELETE FROM planvjezba WHERE PlanID=@pid", conn))
                    { cmd.Parameters.AddWithValue("@pid", odabraniPlanID); cmd.ExecuteNonQuery(); }

                    foreach (TreningVjezba v in vjezbeZaDan)
                        using (SQLiteCommand cmd = new SQLiteCommand(
                            "INSERT INTO planvjezba (PlanID, VjezbaID, BrojSetova, BrojPonavljanja) " +
                            "VALUES (@pid, @vid, @bs, @bp)", conn))
                        {
                            cmd.Parameters.AddWithValue("@pid", odabraniPlanID);
                            cmd.Parameters.AddWithValue("@vid", v.VjezbaID);
                            cmd.Parameters.AddWithValue("@bs",  v.BrojSetova);
                            cmd.Parameters.AddWithValue("@bp",  v.BrojPonavljanja);
                            cmd.ExecuteNonQuery();
                        }

                    using (SQLiteCommand cmd = new SQLiteCommand(
                        "UPDATE treningplan SET Naziv=@n WHERE PlanID=@pid", conn))
                    {
                        cmd.Parameters.AddWithValue("@n",   txtNazivPlana.Text.Trim());
                        cmd.Parameters.AddWithValue("@pid", odabraniPlanID);
                        cmd.ExecuteNonQuery();
                    }
                }
                lblStatus.Text = "✅  Promjene sačuvane!";
                UcitajPlanove();
            }
            catch (Exception ex) { MessageBox.Show("Greška: " + ex.Message); }
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            this.ClientSize = new System.Drawing.Size(980, 600);
            this.Name = "FrmTreningPlan";
            this.Load += new System.EventHandler(this.FrmTreningPlan_Load_1);
            this.ResumeLayout(false);
        }

        private void FrmTreningPlan_Load(object sender, EventArgs e) { }
        private void FrmTreningPlan_Load_1(object sender, EventArgs e) { }
    }
}
