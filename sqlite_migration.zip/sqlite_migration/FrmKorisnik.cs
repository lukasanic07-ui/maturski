using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using System.Data.SQLite;

namespace WindowsFormsApplication1
{
    public partial class FrmKorisnik : Form
    {
        public FrmKorisnik()
        {
            InitializeComponent();
            FrmKorisnik_Load(null, null);
        }

        private void FrmKorisnik_Load(object sender, EventArgs e)
        {
            textBox6.Text     = KorisnikManager.TrenutniUsername;
            textBox6.ReadOnly = true;
            UcitajPodatkeIzBaze();
        }

        private void UcitajPodatkeIzBaze()
        {
            try
            {
                using (SQLiteConnection conn = DbHelper.GetConnection())
                {
                    string sql = "SELECT Ime, Prezime, Godine, Tezina, Visina, ProfilnaSlika " +
                                 "FROM korisnik WHERE KorisnikID=@id";
                    using (SQLiteCommand cmd = new SQLiteCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", KorisnikManager.TrenutniKorisnikID);
                        using (SQLiteDataReader r = cmd.ExecuteReader())
                        {
                            if (r.Read())
                            {
                                string ime     = r.IsDBNull(0) ? "" : r.GetString(0);
                                string prezime = r.IsDBNull(1) ? "" : r.GetString(1);

                                textBox1.Text = ime;
                                textBox2.Text = prezime;
                                textBox3.Text = r.IsDBNull(2) ? "" : r.GetInt32(2).ToString();
                                textBox4.Text = r.IsDBNull(3) ? "" : r.GetDouble(3).ToString();
                                textBox5.Text = r.IsDBNull(4) ? "" : r.GetDouble(4).ToString();

                                string slikaPath = r.IsDBNull(5) ? "" : r.GetString(5);
                                UcitajSliku(slikaPath);
                                AzurirajLijeviPanel(ime, prezime);
                            }
                        }
                    }

                    string sqlCount = "SELECT COUNT(*) FROM trening WHERE KorisnikID=@id";
                    using (SQLiteCommand cmd2 = new SQLiteCommand(sqlCount, conn))
                    {
                        cmd2.Parameters.AddWithValue("@id", KorisnikManager.TrenutniKorisnikID);
                        int ukupno = Convert.ToInt32(cmd2.ExecuteScalar());
                        lblUkupnoTreninga.Text = ukupno.ToString();
                    }
                }

                lblUsername.Text = "@" + KorisnikManager.TrenutniUsername;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška pri učitavanju profila: " + ex.Message);
            }
        }

        private void UcitajSliku(string path)
        {
            try
            {
                if (!string.IsNullOrEmpty(path) && File.Exists(path))
                {
                    pictureBox1.Image    = Image.FromStream(new MemoryStream(File.ReadAllBytes(path)));
                    pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
                }
                else
                {
                    pictureBox1.Image = null;
                }
            }
            catch { pictureBox1.Image = null; }
        }

        private void AzurirajLijeviPanel(string ime, string prezime)
        {
            lblImePrezime.Text = (ime + " " + prezime).Trim();

            string inicijali = "";
            if (ime.Length > 0)     inicijali += ime[0];
            if (prezime.Length > 0) inicijali += prezime[0];
            if (inicijali == "")    inicijali = KorisnikManager.TrenutniUsername.Length > 0
                                                    ? KorisnikManager.TrenutniUsername[0].ToString().ToUpper()
                                                    : "?";
        }

        private void btnDodajSliku_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog dlg = new OpenFileDialog())
            {
                dlg.Title  = "Odaberi profilnu sliku";
                dlg.Filter = "Slike (*.jpg;*.jpeg;*.png;*.bmp)|*.jpg;*.jpeg;*.png;*.bmp";

                if (dlg.ShowDialog() != DialogResult.OK) return;

                string source  = dlg.FileName;
                string appDir  = AppDomain.CurrentDomain.BaseDirectory;
                string slikeDir = Path.Combine(appDir, "ProfilnesSlike");
                if (!Directory.Exists(slikeDir))
                    Directory.CreateDirectory(slikeDir);

                string ext  = Path.GetExtension(source);
                string dest = Path.Combine(slikeDir,
                    "korisnik_" + KorisnikManager.TrenutniKorisnikID + ext);

                File.Copy(source, dest, true);

                try
                {
                    using (SQLiteConnection conn = DbHelper.GetConnection())
                    using (SQLiteCommand cmd = new SQLiteCommand(
                        "UPDATE korisnik SET ProfilnaSlika=@p WHERE KorisnikID=@id", conn))
                    {
                        cmd.Parameters.AddWithValue("@p",  dest);
                        cmd.Parameters.AddWithValue("@id", KorisnikManager.TrenutniKorisnikID);
                        cmd.ExecuteNonQuery();
                    }

                    UcitajSliku(dest);
                    MessageBox.Show("Profilna slika uspješno ažurirana!", "Uspjeh",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Greška pri snimanju slike: " + ex.Message, "Greška",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnSpremi_Click(object sender, EventArgs e)
        {
            int? godine = null;
            if (textBox3.Text.Trim() != "")
            {
                int g;
                if (!int.TryParse(textBox3.Text.Trim(), out g) || g < 1 || g > 120)
                {
                    MessageBox.Show("Godine moraju biti broj između 1 i 120!");
                    textBox3.Focus(); return;
                }
                godine = g;
            }

            double? tezina = null;
            if (textBox4.Text.Trim() != "")
            {
                double t;
                if (!double.TryParse(textBox4.Text.Trim().Replace(",", "."),
                    System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture, out t)
                    || t < 1 || t > 500)
                {
                    MessageBox.Show("Težina mora biti broj (npr. 75.5 kg)!");
                    textBox4.Focus(); return;
                }
                tezina = t;
            }

            double? visina = null;
            if (textBox5.Text.Trim() != "")
            {
                double v;
                if (!double.TryParse(textBox5.Text.Trim().Replace(",", "."),
                    System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture, out v)
                    || v < 50 || v > 300)
                {
                    MessageBox.Show("Visina mora biti broj (npr. 180.0 cm)!");
                    textBox5.Focus(); return;
                }
                visina = v;
            }

            try
            {
                using (SQLiteConnection conn = DbHelper.GetConnection())
                using (SQLiteCommand cmd = new SQLiteCommand(
                    "UPDATE korisnik SET Ime=@ime, Prezime=@prez, " +
                    "Godine=@god, Tezina=@tez, Visina=@vis " +
                    "WHERE KorisnikID=@id", conn))
                {
                    cmd.Parameters.AddWithValue("@ime",  textBox1.Text.Trim());
                    cmd.Parameters.AddWithValue("@prez", textBox2.Text.Trim());
                    cmd.Parameters.AddWithValue("@god",  (object)godine ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@tez",  (object)tezina ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@vis",  (object)visina ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@id",   KorisnikManager.TrenutniKorisnikID);
                    cmd.ExecuteNonQuery();
                }

                AzurirajLijeviPanel(textBox1.Text.Trim(), textBox2.Text.Trim());
                MessageBox.Show("Profil uspješno sačuvan!", "Uspjeh",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška pri snimanju: " + ex.Message, "Greška",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnOdjava_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Sigurno želite odjavu?", "Odjava",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                KorisnikManager.Odjavi();
                this.Close();
            }
        }

        private void FrmKorisnik_Load_1(object sender, EventArgs e) { }
    }
}
