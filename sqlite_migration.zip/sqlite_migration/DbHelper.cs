using System;
using System.IO;
using System.Data.SQLite;

namespace WindowsFormsApplication1
{
    public static class DbHelper
    {
        private static readonly string DbPath =
            Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "fitapp.db");

        private static readonly string ConnStr =
            "Data Source=" + DbPath + ";Version=3;";

        public static SQLiteConnection GetConnection()
        {
            bool novaFajl = !File.Exists(DbPath);
            var conn = new SQLiteConnection(ConnStr);
            conn.Open();
            if (novaFajl) KreirajBazu(conn);
            return conn;
        }

        private static void KreirajBazu(SQLiteConnection conn)
        {
            using (var cmd = new SQLiteCommand(conn))
            {
                cmd.CommandText = @"
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS korisnik (
    KorisnikID    INTEGER PRIMARY KEY AUTOINCREMENT,
    Username      TEXT NOT NULL UNIQUE,
    PasswordHash  TEXT NOT NULL,
    Ime           TEXT,
    Prezime       TEXT,
    Godine        INTEGER,
    Tezina        REAL,
    Visina        REAL,
    ProfilnaSlika TEXT,
    ZapamtiMe     INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS vjezba (
    VjezbaID     INTEGER PRIMARY KEY AUTOINCREMENT,
    Naziv        TEXT NOT NULL,
    Opis         TEXT,
    Tip          TEXT NOT NULL,
    MisicnaGrupa TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS treningplan (
    PlanID         INTEGER PRIMARY KEY AUTOINCREMENT,
    KorisnikID     INTEGER NOT NULL,
    Naziv          TEXT NOT NULL,
    Opis           TEXT,
    DatumKreiranja TEXT,
    FOREIGN KEY (KorisnikID) REFERENCES korisnik(KorisnikID) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS planvjezba (
    PlanVjezbaID    INTEGER PRIMARY KEY AUTOINCREMENT,
    PlanID          INTEGER NOT NULL,
    VjezbaID        INTEGER NOT NULL,
    BrojSetova      INTEGER DEFAULT 3,
    BrojPonavljanja INTEGER DEFAULT 10,
    FOREIGN KEY (PlanID)   REFERENCES treningplan(PlanID) ON DELETE CASCADE,
    FOREIGN KEY (VjezbaID) REFERENCES vjezba(VjezbaID)    ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS trening (
    TreningID  INTEGER PRIMARY KEY AUTOINCREMENT,
    KorisnikID INTEGER NOT NULL,
    PlanID     INTEGER,
    Datum      TEXT NOT NULL,
    Napomena   TEXT,
    FOREIGN KEY (KorisnikID) REFERENCES korisnik(KorisnikID)  ON DELETE CASCADE,
    FOREIGN KEY (PlanID)     REFERENCES treningplan(PlanID)   ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS treningvjezba (
    ID                    INTEGER PRIMARY KEY AUTOINCREMENT,
    TreningID             INTEGER NOT NULL,
    VjezbaID              INTEGER NOT NULL,
    OdradjeniSetovi       INTEGER DEFAULT 0,
    OdradjenaPonavlajnja  INTEGER,
    MaxTezina             REAL    DEFAULT 0,
    Uradjeno              INTEGER DEFAULT 0,
    FOREIGN KEY (TreningID) REFERENCES trening(TreningID) ON DELETE CASCADE,
    FOREIGN KEY (VjezbaID)  REFERENCES vjezba(VjezbaID)   ON DELETE CASCADE
);

INSERT INTO vjezba (VjezbaID, Naziv, Opis, Tip, MisicnaGrupa) VALUES
(1,  'Bench',                  'compund vjezba za snagu',                           'Snaga',        'Prsa'),
(2,  'Zgibovi',                'Fokus na lat',                                      'Snaga',        'Ledja'),
(3,  'Bench Press',            'Osnovna compound vjezba za prsa sa sipkom',          'Snaga',        'Prsa'),
(4,  'Kosi Bench Press',       'Bench press na kosoj klupi, fokus na gornja prsa',  'Snaga',        'Prsa'),
(5,  'Dumbbell Fly',           'Izolacijska vjezba za prsa sa bucicama',             'Snaga',        'Prsa'),
(6,  'Push Up',                'Sklekovi sa sopstvenom tjelesnom tezinom',           'Snaga',        'Prsa'),
(7,  'Cable Crossover',        'Izolacija prsa na kablovskoj masini',                'Snaga',        'Prsa'),
(8,  'Zgibovi (tezinski)',     'Compound vjezba za ledja sa sopstvenom tezinom',     'Snaga',        'Ledja'),
(9,  'Deadlift',               'Osnovna compound vjezba za cijelo ledja',            'Snaga',        'Ledja'),
(10, 'Bent Over Row',          'Rowing sa sipkom u pretklonu, sirina ledja',         'Snaga',        'Ledja'),
(11, 'Lat Pulldown',           'Lat pulldown na masini, zamjena za zgibove',         'Snaga',        'Ledja'),
(12, 'Seated Cable Row',       'Vucenje kabla u sjedu, debljina ledja',              'Snaga',        'Ledja'),
(13, 'T-Bar Row',              'Rowing na T-bar masini, fokus na srednja ledja',     'Snaga',        'Ledja'),
(14, 'Squat',                  'Osnovna compound vjezba za noge sa sipkom',          'Snaga',        'Noge'),
(15, 'Leg Press',              'Potisak nogama na masini',                           'Snaga',        'Noge'),
(16, 'Romanian Deadlift',      'Mrtvo dizanje za zadnju loznu i zadnjicu',           'Snaga',        'Noge'),
(17, 'Leg Curl',               'Izolacija zadnje lozne na masini',                   'Snaga',        'Noge'),
(18, 'Leg Extension',          'Izolacija prednje lozne na masini',                  'Snaga',        'Noge'),
(19, 'Calf Raise',             'Dizanje na prste, izolacija listova',                'Snaga',        'Noge'),
(20, 'Lunges',                 'Iskoraci sa bucicama ili sipkom',                    'Snaga',        'Noge'),
(21, 'Overhead Press',         'Potisak iznad glave sa sipkom stojeci',              'Snaga',        'Ramena'),
(22, 'Dumbbell Shoulder Press','Potisak ramena sa bucicama',                         'Snaga',        'Ramena'),
(23, 'Lateral Raise',          'Podizanje ruku u strane, bocna glava deltoidea',     'Snaga',        'Ramena'),
(24, 'Front Raise',            'Podizanje ruku naprijed, prednja glava deltoidea',   'Snaga',        'Ramena'),
(25, 'Face Pull',              'Vucenje kabla prema licu, zadnja glava deltoidea',   'Snaga',        'Ramena'),
(26, 'Bicep Curl',             'Podizanje bucice za biceps',                         'Snaga',        'Ruke'),
(27, 'Hammer Curl',            'Curl sa neutralnim hvatom, brachialis i biceps',     'Snaga',        'Ruke'),
(28, 'Tricep Pushdown',        'Potiskivanje kabla prema dole, izolacija tricepsa',  'Snaga',        'Ruke'),
(29, 'Skull Crusher',          'Lezeci potisak za triceps sa sipkom ili bucicama',   'Snaga',        'Ruke'),
(30, 'Dips',                   'Compound vjezba za triceps i prsa',                  'Snaga',        'Ruke'),
(31, 'Trcanje na traci',       'Kardio na treadmillu, razlicite brzine i nagib',     'Kardio',       'Cijelo tijelo'),
(32, 'Voznja bicikla',         'Stacionarni bicikl, nizak uticaj na zglobove',       'Kardio',       'Cijelo tijelo'),
(33, 'Plank',                  'Izdrzljivost plocica',                               'Izdrzljivost', 'Cijelo tijelo');
";
                cmd.ExecuteNonQuery();
            }
        }
    }
}
