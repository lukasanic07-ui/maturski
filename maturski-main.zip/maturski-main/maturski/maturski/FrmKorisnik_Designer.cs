namespace WindowsFormsApplication1
{
    partial class FrmKorisnik
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.pnlLijevo        = new System.Windows.Forms.Panel();
            this.pictureBox1      = new System.Windows.Forms.PictureBox();
            this.lblAvatar        = new System.Windows.Forms.Label();
            this.lblImePrezime    = new System.Windows.Forms.Label();
            this.lblUsername      = new System.Windows.Forms.Label();
            this.pnlStatBox       = new System.Windows.Forms.Panel();
            this.lblUkupnoTreninga = new System.Windows.Forms.Label();
            this.lblStatLabel     = new System.Windows.Forms.Label();
            this.pnlDesno         = new System.Windows.Forms.Panel();
            this.label1           = new System.Windows.Forms.Label();
            this.pnlDivider       = new System.Windows.Forms.Panel();
            this.label2           = new System.Windows.Forms.Label();
            this.textBox1         = new System.Windows.Forms.TextBox();
            this.Prezime          = new System.Windows.Forms.Label();
            this.textBox2         = new System.Windows.Forms.TextBox();
            this.label4           = new System.Windows.Forms.Label();
            this.textBox3         = new System.Windows.Forms.TextBox();
            this.label5           = new System.Windows.Forms.Label();
            this.textBox4         = new System.Windows.Forms.TextBox();
            this.label6           = new System.Windows.Forms.Label();
            this.textBox5         = new System.Windows.Forms.TextBox();
            this.label7           = new System.Windows.Forms.Label();
            this.textBox6         = new System.Windows.Forms.TextBox();
            this.pnlButtons       = new System.Windows.Forms.Panel();
            this.btnSpremi        = new System.Windows.Forms.Button();
            this.btnOdjava        = new System.Windows.Forms.Button();
            this.pnlLijevo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnlStatBox.SuspendLayout();
            this.pnlDesno.SuspendLayout();
            this.pnlButtons.SuspendLayout();
            this.SuspendLayout();

            // ── pnlLijevo ────────────────────────────────────────────────
            this.pnlLijevo.BackColor = System.Drawing.Color.FromArgb(45, 55, 90);
            this.pnlLijevo.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlLijevo.Width = 200;
            this.pnlLijevo.Name = "pnlLijevo";
            this.pnlLijevo.TabIndex = 0;
            this.pnlLijevo.Controls.Add(this.pictureBox1);
            this.pnlLijevo.Controls.Add(this.lblAvatar);
            this.pnlLijevo.Controls.Add(this.lblImePrezime);
            this.pnlLijevo.Controls.Add(this.lblUsername);
            this.pnlLijevo.Controls.Add(this.pnlStatBox);

            // pictureBox1 (avatar circle placeholder)
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(70, 80, 120);
            this.pictureBox1.Location = new System.Drawing.Point(55, 30);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(90, 90);
            this.pictureBox1.TabStop = false;
            this.pictureBox1.TabIndex = 0;

            // lblAvatar (big initials over picturebox)
            this.lblAvatar.AutoSize = false;
            this.lblAvatar.Font = new System.Drawing.Font("Segoe UI", 26F, System.Drawing.FontStyle.Bold);
            this.lblAvatar.ForeColor = System.Drawing.Color.White;
            this.lblAvatar.Location = new System.Drawing.Point(55, 30);
            this.lblAvatar.Name = "lblAvatar";
            this.lblAvatar.Size = new System.Drawing.Size(90, 90);
            this.lblAvatar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblAvatar.Text = "?";
            this.lblAvatar.BackColor = System.Drawing.Color.Transparent;

            // lblImePrezime
            this.lblImePrezime.AutoSize = false;
            this.lblImePrezime.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblImePrezime.ForeColor = System.Drawing.Color.White;
            this.lblImePrezime.Location = new System.Drawing.Point(0, 130);
            this.lblImePrezime.Name = "lblImePrezime";
            this.lblImePrezime.Size = new System.Drawing.Size(200, 28);
            this.lblImePrezime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblImePrezime.Text = "";
            this.lblImePrezime.TabIndex = 1;

            // lblUsername
            this.lblUsername.AutoSize = false;
            this.lblUsername.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblUsername.ForeColor = System.Drawing.Color.FromArgb(160, 175, 210);
            this.lblUsername.Location = new System.Drawing.Point(0, 158);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(200, 22);
            this.lblUsername.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblUsername.Text = "";
            this.lblUsername.TabIndex = 2;

            // pnlStatBox
            this.pnlStatBox.BackColor = System.Drawing.Color.FromArgb(55, 65, 105);
            this.pnlStatBox.Location = new System.Drawing.Point(20, 200);
            this.pnlStatBox.Name = "pnlStatBox";
            this.pnlStatBox.Size = new System.Drawing.Size(160, 60);
            this.pnlStatBox.TabIndex = 3;
            this.pnlStatBox.Controls.Add(this.lblUkupnoTreninga);
            this.pnlStatBox.Controls.Add(this.lblStatLabel);

            // lblUkupnoTreninga (big number)
            this.lblUkupnoTreninga.AutoSize = false;
            this.lblUkupnoTreninga.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.lblUkupnoTreninga.ForeColor = System.Drawing.Color.White;
            this.lblUkupnoTreninga.Location = new System.Drawing.Point(0, 6);
            this.lblUkupnoTreninga.Name = "lblUkupnoTreninga";
            this.lblUkupnoTreninga.Size = new System.Drawing.Size(160, 30);
            this.lblUkupnoTreninga.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblUkupnoTreninga.Text = "0";
            this.lblUkupnoTreninga.TabIndex = 0;

            // lblStatLabel
            this.lblStatLabel.AutoSize = false;
            this.lblStatLabel.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.lblStatLabel.ForeColor = System.Drawing.Color.FromArgb(160, 175, 210);
            this.lblStatLabel.Location = new System.Drawing.Point(0, 38);
            this.lblStatLabel.Name = "lblStatLabel";
            this.lblStatLabel.Size = new System.Drawing.Size(160, 16);
            this.lblStatLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblStatLabel.Text = "ukupno treninga";
            this.lblStatLabel.TabIndex = 1;

            // ── pnlDesno ─────────────────────────────────────────────────
            this.pnlDesno.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlDesno.BackColor = System.Drawing.Color.White;
            this.pnlDesno.Padding = new System.Windows.Forms.Padding(30, 20, 30, 20);
            this.pnlDesno.Name = "pnlDesno";
            this.pnlDesno.TabIndex = 1;
            this.pnlDesno.Controls.Add(this.label1);
            this.pnlDesno.Controls.Add(this.pnlDivider);
            this.pnlDesno.Controls.Add(this.label2);
            this.pnlDesno.Controls.Add(this.textBox1);
            this.pnlDesno.Controls.Add(this.Prezime);
            this.pnlDesno.Controls.Add(this.textBox2);
            this.pnlDesno.Controls.Add(this.label4);
            this.pnlDesno.Controls.Add(this.textBox3);
            this.pnlDesno.Controls.Add(this.label5);
            this.pnlDesno.Controls.Add(this.textBox4);
            this.pnlDesno.Controls.Add(this.label6);
            this.pnlDesno.Controls.Add(this.textBox5);
            this.pnlDesno.Controls.Add(this.label7);
            this.pnlDesno.Controls.Add(this.textBox6);
            this.pnlDesno.Controls.Add(this.pnlButtons);

            int lx = 30, tx = 185, tw = 220;
            int row(int n) { return 20 + n * 52; }

            // label1 "Podaci profila" header
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(45, 55, 90);
            this.label1.Location = new System.Drawing.Point(lx, 20);
            this.label1.Name = "label1";
            this.label1.Text = "Podaci profila";
            this.label1.TabIndex = 0;

            // pnlDivider
            this.pnlDivider.BackColor = System.Drawing.Color.FromArgb(230, 232, 240);
            this.pnlDivider.Location = new System.Drawing.Point(lx, 50);
            this.pnlDivider.Name = "pnlDivider";
            this.pnlDivider.Size = new System.Drawing.Size(360, 1);

            // label2 "Ime"
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(100, 110, 140);
            this.label2.Location = new System.Drawing.Point(lx, row(1));
            this.label2.Name = "label2";
            this.label2.Text = "Ime";
            this.label2.TabIndex = 1;

            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.textBox1.Location = new System.Drawing.Point(tx, row(1) - 2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(tw, 26);
            this.textBox1.TabIndex = 2;

            // Prezime
            this.Prezime.AutoSize = true;
            this.Prezime.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.Prezime.ForeColor = System.Drawing.Color.FromArgb(100, 110, 140);
            this.Prezime.Location = new System.Drawing.Point(lx, row(2));
            this.Prezime.Name = "Prezime";
            this.Prezime.Text = "Prezime";
            this.Prezime.TabIndex = 3;

            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox2.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.textBox2.Location = new System.Drawing.Point(tx, row(2) - 2);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(tw, 26);
            this.textBox2.TabIndex = 4;

            // label4 "Godine"
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.FromArgb(100, 110, 140);
            this.label4.Location = new System.Drawing.Point(lx, row(3));
            this.label4.Name = "label4";
            this.label4.Text = "Godine";
            this.label4.TabIndex = 5;

            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox3.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.textBox3.Location = new System.Drawing.Point(tx, row(3) - 2);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(tw, 26);
            this.textBox3.TabIndex = 6;

            // label5 "Tezina (kg)"
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.FromArgb(100, 110, 140);
            this.label5.Location = new System.Drawing.Point(lx, row(4));
            this.label5.Name = "label5";
            this.label5.Text = "Tezina (kg)";
            this.label5.TabIndex = 7;

            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox4.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.textBox4.Location = new System.Drawing.Point(tx, row(4) - 2);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(tw, 26);
            this.textBox4.TabIndex = 8;

            // label6 "Visina (cm)"
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.FromArgb(100, 110, 140);
            this.label6.Location = new System.Drawing.Point(lx, row(5));
            this.label6.Name = "label6";
            this.label6.Text = "Visina (cm)";
            this.label6.TabIndex = 9;

            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox5.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.textBox5.Location = new System.Drawing.Point(tx, row(5) - 2);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(tw, 26);
            this.textBox5.TabIndex = 10;

            // label7 "Username"
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.FromArgb(100, 110, 140);
            this.label7.Location = new System.Drawing.Point(lx, row(6));
            this.label7.Name = "label7";
            this.label7.Text = "Username";
            this.label7.TabIndex = 11;

            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox6.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.textBox6.Location = new System.Drawing.Point(tx, row(6) - 2);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(tw, 26);
            this.textBox6.BackColor = System.Drawing.Color.FromArgb(245, 246, 250);
            this.textBox6.TabIndex = 12;

            // pnlButtons
            this.pnlButtons.BackColor = System.Drawing.Color.White;
            this.pnlButtons.Location = new System.Drawing.Point(lx, row(7) + 10);
            this.pnlButtons.Name = "pnlButtons";
            this.pnlButtons.Size = new System.Drawing.Size(375, 44);
            this.pnlButtons.TabIndex = 13;
            this.pnlButtons.Controls.Add(this.btnSpremi);
            this.pnlButtons.Controls.Add(this.btnOdjava);

            // btnSpremi
            this.btnSpremi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSpremi.FlatAppearance.BorderSize = 0;
            this.btnSpremi.BackColor = System.Drawing.Color.FromArgb(45, 55, 90);
            this.btnSpremi.ForeColor = System.Drawing.Color.White;
            this.btnSpremi.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSpremi.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnSpremi.Location = new System.Drawing.Point(0, 0);
            this.btnSpremi.Name = "btnSpremi";
            this.btnSpremi.Size = new System.Drawing.Size(200, 40);
            this.btnSpremi.TabIndex = 0;
            this.btnSpremi.Text = "Spremi promjene";
            this.btnSpremi.Click += new System.EventHandler(this.btnSpremi_Click);

            // btnOdjava
            this.btnOdjava.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOdjava.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(200, 53, 69);
            this.btnOdjava.FlatAppearance.BorderSize = 1;
            this.btnOdjava.BackColor = System.Drawing.Color.White;
            this.btnOdjava.ForeColor = System.Drawing.Color.FromArgb(200, 53, 69);
            this.btnOdjava.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnOdjava.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnOdjava.Location = new System.Drawing.Point(210, 0);
            this.btnOdjava.Name = "btnOdjava";
            this.btnOdjava.Size = new System.Drawing.Size(120, 40);
            this.btnOdjava.TabIndex = 1;
            this.btnOdjava.Text = "Odjava";
            this.btnOdjava.Click += new System.EventHandler(this.btnOdjava_Click);

            // ── FrmKorisnik ──────────────────────────────────────────────
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(640, 480);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "FrmKorisnik";
            this.Text = "Moj Profil";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;

            // Fill first, Left last (docked in reverse add order)
            this.Controls.Add(this.pnlDesno);
            this.Controls.Add(this.pnlLijevo);

            this.pnlLijevo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnlStatBox.ResumeLayout(false);
            this.pnlDesno.ResumeLayout(false);
            this.pnlDesno.PerformLayout();
            this.pnlButtons.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Panel       pnlLijevo;
        private System.Windows.Forms.PictureBox  pictureBox1;
        private System.Windows.Forms.Label       lblAvatar;
        private System.Windows.Forms.Label       lblImePrezime;
        private System.Windows.Forms.Label       lblUsername;
        private System.Windows.Forms.Panel       pnlStatBox;
        private System.Windows.Forms.Label       lblUkupnoTreninga;
        private System.Windows.Forms.Label       lblStatLabel;
        private System.Windows.Forms.Panel       pnlDesno;
        private System.Windows.Forms.Label       label1;
        private System.Windows.Forms.Panel       pnlDivider;
        private System.Windows.Forms.Label       label2;
        private System.Windows.Forms.TextBox     textBox1;
        private System.Windows.Forms.Label       Prezime;
        private System.Windows.Forms.TextBox     textBox2;
        private System.Windows.Forms.Label       label4;
        private System.Windows.Forms.TextBox     textBox3;
        private System.Windows.Forms.Label       label5;
        private System.Windows.Forms.TextBox     textBox4;
        private System.Windows.Forms.Label       label6;
        private System.Windows.Forms.TextBox     textBox5;
        private System.Windows.Forms.Label       label7;
        private System.Windows.Forms.TextBox     textBox6;
        private System.Windows.Forms.Panel       pnlButtons;
        private System.Windows.Forms.Button      btnSpremi;
        private System.Windows.Forms.Button      btnOdjava;
    }
}
