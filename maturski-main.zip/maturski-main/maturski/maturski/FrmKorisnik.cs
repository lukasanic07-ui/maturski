using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApplication1
{
    public partial class FrmKorisnik : Form
    {
        public FrmKorisnik()
        {
            InitializeComponent();
            FrmKorisnik_Load(null, null);
        }

        private void FrmKorisnik_Load(object sender, EventArgs e)
        {
            // textBox6 = Username (readonly)
            textBox6.Text     = KorisnikManager.TrenutniUsername;
            textBox6.ReadOnly = true;

            UcitajPodatkeIzBaze();
        }

        private void UcitajPodatkeIzBaze()
        {
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                {
                    string sql = "SELECT Ime, Prezime, Godine, Tezina, Visina " +
                                 "FROM korisnik WHERE KorisnikID=@id";
                    using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", KorisnikManager.TrenutniKorisnikID);
                        using (MySqlDataReader r = cmd.ExecuteReader())
                        {
                            if (r.Read())
                            {
                                textBox1.Text = r.IsDBNull(0) ? "" : r.GetString(0);   // Ime
                                textBox2.Text = r.IsDBNull(1) ? "" : r.GetString(1);   // Prezime
                                textBox3.Text = r.IsDBNull(2) ? "" : r.GetInt32(2).ToString();    // Godine
                                textBox4.Text = r.IsDBNull(3) ? "" : r.GetDouble(3).ToString();   // Tezina
                                textBox5.Text = r.IsDBNull(4) ? "" : r.GetDouble(4).ToString();   // Visina

                                string ime     = r.IsDBNull(0) ? "" : r.GetString(0);
                                string prezime = r.IsDBNull(1) ? "" : r.GetString(1);
                                lblImePrezime.Text = ime + " " + prezime;
                            }
                        }
                    }

                    // Broj treninga
                    string sqlCount = "SELECT COUNT(*) FROM trening WHERE KorisnikID=@id";
                    using (MySqlCommand cmd2 = new MySqlCommand(sqlCount, conn))
                    {
                        cmd2.Parameters.AddWithValue("@id", KorisnikManager.TrenutniKorisnikID);
                        int ukupno = Convert.ToInt32(cmd2.ExecuteScalar());
                        lblUkupnoTreninga.Text = "Treninga: " + ukupno.ToString();
                    }
                }

                lblUsername.Text = "@" + KorisnikManager.TrenutniUsername;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greska pri ucitavanju profila: " + ex.Message);
            }
        }

        private void btnSpremi_Click(object sender, EventArgs e)
        {
            // Validiraj Godine
            int godine = 0;
            if (textBox3.Text.Trim() != "")
            {
                if (!int.TryParse(textBox3.Text.Trim(), out godine))
                {
                    MessageBox.Show("Godine moraju biti broj!");
                    return;
                }
            }

            // Validiraj Tezina
            double tezina = 0;
            if (textBox4.Text.Trim() != "")
            {
                string tezinaTxt = textBox4.Text.Trim().Replace(",", ".");
                if (!double.TryParse(tezinaTxt,
                    System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture,
                    out tezina))
                {
                    MessageBox.Show("Tezina mora biti broj (npr. 75.5)!");
                    return;
                }
            }

            // Validiraj Visina
            double visina = 0;
            if (textBox5.Text.Trim() != "")
            {
                string visinaTxt = textBox5.Text.Trim().Replace(",", ".");
                if (!double.TryParse(visinaTxt,
                    System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture,
                    out visina))
                {
                    MessageBox.Show("Visina mora biti broj (npr. 180.0)!");
                    return;
                }
            }

            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                {
                    string sql = "UPDATE korisnik SET Ime=@ime, Prezime=@prez, " +
                                 "Godine=@god, Tezina=@tez, Visina=@vis " +
                                 "WHERE KorisnikID=@id";
                    using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@ime",  textBox1.Text.Trim());
                        cmd.Parameters.AddWithValue("@prez", textBox2.Text.Trim());
                        cmd.Parameters.AddWithValue("@god",  godine);
                        cmd.Parameters.AddWithValue("@tez",  tezina);
                        cmd.Parameters.AddWithValue("@vis",  visina);
                        cmd.Parameters.AddWithValue("@id",   KorisnikManager.TrenutniKorisnikID);
                        cmd.ExecuteNonQuery();
                    }
                }
                MessageBox.Show("Profil uspjesno sacuvan!");
                lblImePrezime.Text = textBox1.Text.Trim() + " " + textBox2.Text.Trim();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greska pri snimanju: " + ex.Message);
            }
        }

        private void btnOdjava_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Sigurno zelite odjavu?", "Odjava",
                MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                KorisnikManager.Odjavi();
                this.Close();
            }
        }
    }
}
