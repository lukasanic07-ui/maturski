using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApplication1
{
    public partial class FrmKorisnik : Form
    {
        public FrmKorisnik()
        {
            InitializeComponent();
            FrmKorisnik_Load(null, null);
        }

        private void FrmKorisnik_Load(object sender, EventArgs e)
        {
            textBox6.Text     = KorisnikManager.TrenutniUsername;
            textBox6.ReadOnly = true;
            UcitajPodatkeIzBaze();
        }

        private void UcitajPodatkeIzBaze()
        {
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                {
                    string sql = "SELECT Ime, Prezime, Godine, Tezina, Visina " +
                                 "FROM korisnik WHERE KorisnikID=@id";
                    using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", KorisnikManager.TrenutniKorisnikID);
                        using (MySqlDataReader r = cmd.ExecuteReader())
                        {
                            if (r.Read())
                            {
                                string ime     = r.IsDBNull(0) ? "" : r.GetString(0);
                                string prezime = r.IsDBNull(1) ? "" : r.GetString(1);

                                textBox1.Text = ime;
                                textBox2.Text = prezime;
                                textBox3.Text = r.IsDBNull(2) ? "" : r.GetInt32(2).ToString();
                                textBox4.Text = r.IsDBNull(3) ? "" : r.GetDouble(3).ToString();
                                textBox5.Text = r.IsDBNull(4) ? "" : r.GetDouble(4).ToString();

                                AzurirajLijeviPanel(ime, prezime);
                            }
                        }
                    }

                    string sqlCount = "SELECT COUNT(*) FROM trening WHERE KorisnikID=@id";
                    using (MySqlCommand cmd2 = new MySqlCommand(sqlCount, conn))
                    {
                        cmd2.Parameters.AddWithValue("@id", KorisnikManager.TrenutniKorisnikID);
                        int ukupno = Convert.ToInt32(cmd2.ExecuteScalar());
                        lblUkupnoTreninga.Text = ukupno.ToString();
                    }
                }

                lblUsername.Text = "@" + KorisnikManager.TrenutniUsername;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greska pri ucitavanju profila: " + ex.Message);
            }
        }

        // Azurira ime, inicijale i username u lijevom panelu
        private void AzurirajLijeviPanel(string ime, string prezime)
        {
            lblImePrezime.Text = (ime + " " + prezime).Trim();

            string inicijali = "";
            if (ime.Length > 0)     inicijali += ime[0];
            if (prezime.Length > 0) inicijali += prezime[0];
            if (inicijali == "")    inicijali = KorisnikManager.TrenutniUsername.Length > 0
                                                    ? KorisnikManager.TrenutniUsername[0].ToString().ToUpper()
                                                    : "?";
            //lblAvatar.Text = inicijali.ToUpper();
        }

        private void btnSpremi_Click(object sender, EventArgs e)
        {
            // Validacija - Godine
            int godine = 0;
            if (textBox3.Text.Trim() != "")
            {
                if (!int.TryParse(textBox3.Text.Trim(), out godine) || godine < 1 || godine > 120)
                {
                    MessageBox.Show("Godine moraju biti broj između 1 i 120!");
                    textBox3.Focus();
                    return;
                }
            }

            // Validacija - Tezina
            double tezina = 0;
            if (textBox4.Text.Trim() != "")
            {
                string tezinaTxt = textBox4.Text.Trim().Replace(",", ".");
                if (!double.TryParse(tezinaTxt,
                    System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture,
                    out tezina) || tezina < 1 || tezina > 500)
                {
                    MessageBox.Show("Tezina mora biti broj (npr. 75.5 kg)!");
                    textBox4.Focus();
                    return;
                }
            }

            // Validacija - Visina
            double visina = 0;
            if (textBox5.Text.Trim() != "")
            {
                string visinaTxt = textBox5.Text.Trim().Replace(",", ".");
                if (!double.TryParse(visinaTxt,
                    System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture,
                    out visina) || visina < 50 || visina > 300)
                {
                    MessageBox.Show("Visina mora biti broj (npr. 180.0 cm)!");
                    textBox5.Focus();
                    return;
                }
            }

            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                {
                    string sql = "UPDATE korisnik SET Ime=@ime, Prezime=@prez, " +
                                 "Godine=@god, Tezina=@tez, Visina=@vis " +
                                 "WHERE KorisnikID=@id";
                    using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@ime",  textBox1.Text.Trim());
                        cmd.Parameters.AddWithValue("@prez", textBox2.Text.Trim());
                        cmd.Parameters.AddWithValue("@god",  godine == 0 ? (object)DBNull.Value : godine);
                        cmd.Parameters.AddWithValue("@tez",  tezina == 0 ? (object)DBNull.Value : tezina);
                        cmd.Parameters.AddWithValue("@vis",  visina == 0 ? (object)DBNull.Value : visina);
                        cmd.Parameters.AddWithValue("@id",   KorisnikManager.TrenutniKorisnikID);
                        cmd.ExecuteNonQuery();
                    }
                }

                AzurirajLijeviPanel(textBox1.Text.Trim(), textBox2.Text.Trim());
                MessageBox.Show("Profil uspjesno sacuvan!", "Uspjeh",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greska pri snimanju: " + ex.Message, "Greska",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnOdjava_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Sigurno zelite odjavu?", "Odjava",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                KorisnikManager.Odjavi();
                this.Close();
            }
        }
    }
}
