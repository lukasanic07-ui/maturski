﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApplication1
{
    public partial class FrmEvidencija : Form
    {
        // ── Kontrole ─────────────────────────────────────────────────────
        private Panel pnlLijevo;
        private Label lblNaslov;
        private Label lblFilterLbl;
        private ComboBox cmbVjezbe;
        private Label lblTreninziLbl;
        private ListBox lstTreninzi;
        private Label lblUkupno;
        private Panel pnlDesno;
        private Panel pnlChart;
        private Label lblChartNaslov;
        private Label lblDetaljiNaslov;
        private DataGridView dgvDetalji;

        // ── Podaci ───────────────────────────────────────────────────────
        private List<ProgressTacka> chartTacke = new List<ProgressTacka>();
        private int odabraniTreningID = -1;

        private class ProgressTacka
        {
            public DateTime Datum;
            public double MaxKg;
            public int Setovi;
        }

        private class TreningItem
        {
            public int TreningID;
            public DateTime Datum;
            public string PlanNaziv;
            public override string ToString()
            {
                return Datum.ToString("dd.MM.yyyy") + "  —  " + PlanNaziv;
            }
        }

        private class VjezbaItem
        {
            public int VjezbaID;
            public string Naziv;
            public override string ToString() { return Naziv; }
        }

        // ── Konstruktor ──────────────────────────────────────────────────
        public FrmEvidencija()
        {
            InitializeComponent(); // ← MORA biti prvi poziv
            GradiForme();
            PrimijeniStil();
            UcitajVjezbe();
            UcitajTreningHistoriju();
        }

        // ── Gradnja ──────────────────────────────────────────────────────
        private void GradiForme()
        {
            this.SuspendLayout();
            this.Text = "Evidencija i Napredak";
            this.ClientSize = new Size(1100, 680);
            this.MinimumSize = new Size(1100, 680);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Font = new Font("Segoe UI", 9f);

            // ── Lijevi panel ─────────────────────────────────────────────
            pnlLijevo = new Panel
            {
                Dock = DockStyle.Left,
                Size = new Size(250, 680)
            };

            lblNaslov = new Label
            {
                Text = "  Evidencija",
                Dock = DockStyle.Top,
                Height = 50,
                TextAlign = ContentAlignment.MiddleLeft
            };

            lblFilterLbl = new Label
            {
                Text = "Napredak po vjezbi:",
                Location = new Point(12, 60),
                AutoSize = true
            };

            cmbVjezbe = new ComboBox
            {
                Location = new Point(12, 82),
                Size = new Size(224, 24),
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            cmbVjezbe.SelectedIndexChanged += cmbVjezbe_SelectedIndexChanged;

            lblTreninziLbl = new Label
            {
                Text = "Historija treninga:",
                Location = new Point(12, 118),
                AutoSize = true
            };

            lstTreninzi = new ListBox
            {
                Location = new Point(12, 140),
                Size = new Size(224, 460),
                BorderStyle = BorderStyle.None
            };
            lstTreninzi.SelectedIndexChanged += lstTreninzi_SelectedIndexChanged;

            lblUkupno = new Label
            {
                Text = "",
                Location = new Point(12, 608),
                AutoSize = true
            };

            pnlLijevo.Controls.AddRange(new Control[]
                { lblNaslov, lblFilterLbl, cmbVjezbe,
                  lblTreninziLbl, lstTreninzi, lblUkupno });

            // ── Desni panel ──────────────────────────────────────────────
            pnlDesno = new Panel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(12)
            };

            // Chart panel (gore)
            pnlChart = new Panel
            {
                Location = new Point(12, 12),
                Size = new Size(820, 230),
                BorderStyle = BorderStyle.None
            };

            // FIX: lblChartNaslov se dodaje SAMO u pnlChart, ne i u pnlDesno
            lblChartNaslov = new Label
            {
                Text = "Odaberi vjezbu da vidis napredak kilaze",
                Location = new Point(0, 0),
                AutoSize = true
            };
            pnlChart.Controls.Add(lblChartNaslov);
            pnlChart.Paint += pnlChart_Paint;

            lblDetaljiNaslov = new Label
            {
                Text = "Klikni na trening sa lijeve strane za detalje:",
                Location = new Point(12, 254),
                AutoSize = true
            };

            dgvDetalji = new DataGridView
            {
                Location = new Point(12, 276),
                Size = new Size(820, 380),
                ReadOnly = true,
                AllowUserToAddRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoGenerateColumns = false,
                ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
            };
            dgvDetalji.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Vjezba", Name = "dNaziv", Width = 180 });
            dgvDetalji.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Uradjeni setovi", Name = "dSetovi", Width = 110 });
            dgvDetalji.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Max kilaza (kg)", Name = "dKg", Width = 120 });
            dgvDetalji.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Uradjeno", Name = "dGot", Width = 80 });
            dgvDetalji.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Prethodni rekord", Name = "dPR", Width = 140 });
            dgvDetalji.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Razlika", Name = "dDelta", Width = 90 });

            // FIX: lblChartNaslov NIJE ovdje — već je dodan u pnlChart gore
            pnlDesno.Controls.AddRange(new Control[] { pnlChart, lblDetaljiNaslov, dgvDetalji });

            this.Controls.Add(pnlDesno);
            this.Controls.Add(pnlLijevo);
            this.ResumeLayout(false);
        }

        // ── Stil ─────────────────────────────────────────────────────────
        private void PrimijeniStil()
        {
            this.BackColor = Color.FromArgb(245, 247, 250);

            pnlLijevo.BackColor = Color.FromArgb(88, 86, 214);
            lblNaslov.ForeColor = Color.White;
            lblNaslov.Font = new Font("Segoe UI", 14f, FontStyle.Bold);
            lblFilterLbl.ForeColor = Color.FromArgb(210, 210, 255);
            lblFilterLbl.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
            lblTreninziLbl.ForeColor = Color.FromArgb(210, 210, 255);
            lblTreninziLbl.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
            cmbVjezbe.Font = new Font("Segoe UI", 9f);
            lstTreninzi.BackColor = Color.FromArgb(70, 68, 190);
            lstTreninzi.ForeColor = Color.White;
            lstTreninzi.Font = new Font("Segoe UI", 9f);
            lblUkupno.ForeColor = Color.FromArgb(200, 200, 255);
            lblUkupno.Font = new Font("Segoe UI", 9f);

            pnlDesno.BackColor = Color.FromArgb(245, 247, 250);
            pnlChart.BackColor = Color.White;
            lblChartNaslov.Font = new Font("Segoe UI", 10f, FontStyle.Bold);
            lblChartNaslov.ForeColor = Color.FromArgb(88, 86, 214);
            lblDetaljiNaslov.Font = new Font("Segoe UI", 10f, FontStyle.Bold);
            lblDetaljiNaslov.ForeColor = Color.FromArgb(50, 50, 70);

            StilGrid(dgvDetalji);
        }

        private void StilGrid(DataGridView g)
        {
            g.BackgroundColor = Color.White;
            g.BorderStyle = BorderStyle.None;
            g.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            g.GridColor = Color.FromArgb(230, 230, 230);
            g.RowHeadersVisible = false;
            g.EnableHeadersVisualStyles = false;
            g.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(88, 86, 214);
            g.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            g.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
            g.ColumnHeadersHeight = 36;
            g.DefaultCellStyle.Font = new Font("Segoe UI", 9f);
            g.DefaultCellStyle.SelectionBackColor = Color.FromArgb(88, 86, 214);
            g.DefaultCellStyle.SelectionForeColor = Color.White;
            g.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 249, 252);
            g.RowTemplate.Height = 30;
        }

        // ── Ucitaj vjezbe za filter ───────────────────────────────────────
        private void UcitajVjezbe()
        {
            cmbVjezbe.Items.Clear();
            cmbVjezbe.Items.Add(new VjezbaItem { VjezbaID = -1, Naziv = "-- Odaberi vjezbu --" });
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                using (MySqlCommand cmd = new MySqlCommand(
                    "SELECT DISTINCT v.VjezbaID, v.Naziv " +
                    "FROM treningvjezba tv " +
                    "JOIN vjezba v ON v.VjezbaID=tv.VjezbaID " +
                    "JOIN trening t ON t.TreningID=tv.TreningID " +
                    "WHERE t.KorisnikID=@kid ORDER BY v.Naziv", conn))
                {
                    cmd.Parameters.AddWithValue("@kid", KorisnikManager.TrenutniKorisnikID);
                    using (MySqlDataReader r = cmd.ExecuteReader())
                        while (r.Read())
                            cmbVjezbe.Items.Add(new VjezbaItem { VjezbaID = r.GetInt32(0), Naziv = r.GetString(1) });
                }
            }
            catch { }
            cmbVjezbe.SelectedIndex = 0;
        }

        // ── Ucitaj historiju treninga u listu ─────────────────────────────
        private void UcitajTreningHistoriju()
        {
            lstTreninzi.Items.Clear();
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                using (MySqlCommand cmd = new MySqlCommand(
                    "SELECT t.TreningID, t.Datum, COALESCE(tp.Naziv,'Bez plana') " +
                    "FROM trening t " +
                    "LEFT JOIN treningplan tp ON tp.PlanID=t.PlanID " +
                    "WHERE t.KorisnikID=@kid ORDER BY t.Datum DESC", conn))
                {
                    cmd.Parameters.AddWithValue("@kid", KorisnikManager.TrenutniKorisnikID);
                    using (MySqlDataReader r = cmd.ExecuteReader())
                        while (r.Read())
                            lstTreninzi.Items.Add(new TreningItem
                            {
                                TreningID = r.GetInt32(0),
                                Datum = r.GetDateTime(1),
                                PlanNaziv = r.GetString(2)
                            });
                }
            }
            catch (Exception ex) { MessageBox.Show("Greska: " + ex.Message); }

            lblUkupno.Text = "Ukupno treninga: " + lstTreninzi.Items.Count;
        }

        // ── Klik na trening - prikazi detalje ─────────────────────────────
        private void lstTreninzi_SelectedIndexChanged(object sender, EventArgs e)
        {
            var item = lstTreninzi.SelectedItem as TreningItem;
            if (item == null) return;
            odabraniTreningID = item.TreningID;
            UcitajDetalje(item.TreningID, item.Datum);
        }

        private void UcitajDetalje(int treningID, DateTime datum)
        {
            dgvDetalji.Rows.Clear();
            lblDetaljiNaslov.Text = "Trening od " + datum.ToString("dd.MM.yyyy") + ":";

            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                {
                    using (MySqlCommand cmd = new MySqlCommand(
                        "SELECT tv.VjezbaID, v.Naziv, tv.OdradjeniSetovi, tv.MaxTezina, tv.Uradjeno " +
                        "FROM treningvjezba tv JOIN vjezba v ON v.VjezbaID=tv.VjezbaID " +
                        "WHERE tv.TreningID=@tid ORDER BY v.Naziv", conn))
                    {
                        cmd.Parameters.AddWithValue("@tid", treningID);
                        using (MySqlDataReader r = cmd.ExecuteReader())
                        {
                            while (r.Read())
                            {
                                int vid = r.GetInt32(0);
                                string naziv = r.GetString(1);
                                int setovi = r.IsDBNull(2) ? 0 : r.GetInt32(2);
                                double maxKg = r.IsDBNull(3) ? 0 : r.GetDouble(3);
                                bool gotovo = !r.IsDBNull(4) && r.GetInt32(4) == 1;

                                double prethodniRekord = 0;
                                using (MySqlCommand cmd2 = new MySqlCommand(
                                    "SELECT MAX(tv2.MaxTezina) FROM treningvjezba tv2 " +
                                    "JOIN trening t2 ON t2.TreningID=tv2.TreningID " +
                                    "WHERE tv2.VjezbaID=@vid AND t2.KorisnikID=@kid " +
                                    "AND t2.Datum < @datum AND t2.TreningID != @tid", conn))
                                {
                                    cmd2.Parameters.AddWithValue("@vid", vid);
                                    cmd2.Parameters.AddWithValue("@kid", KorisnikManager.TrenutniKorisnikID);
                                    cmd2.Parameters.AddWithValue("@datum", datum.ToString("yyyy-MM-dd"));
                                    cmd2.Parameters.AddWithValue("@tid", treningID);
                                    object res = cmd2.ExecuteScalar();
                                    if (res != null && res != DBNull.Value)
                                        prethodniRekord = Convert.ToDouble(res);
                                }

                                double razlika = maxKg - prethodniRekord;
                                string razlikaStr = prethodniRekord > 0
                                    ? (razlika >= 0 ? "+" : "") + razlika.ToString("0.##") + " kg"
                                    : "Prvi put";
                                string prStr = prethodniRekord > 0
                                    ? prethodniRekord.ToString("0.##") + " kg"
                                    : "-";

                                int rowIdx = dgvDetalji.Rows.Add(
                                    naziv,
                                    setovi + " set(a)",
                                    maxKg > 0 ? maxKg.ToString("0.##") + " kg" : "-",
                                    gotovo ? "✔" : "✘",
                                    prStr,
                                    razlikaStr
                                );

                                if (prethodniRekord > 0)
                                {
                                    Color c = razlika > 0
                                        ? Color.FromArgb(220, 255, 220)
                                        : razlika < 0
                                            ? Color.FromArgb(255, 220, 220)
                                            : Color.White;
                                    dgvDetalji.Rows[rowIdx].DefaultCellStyle.BackColor = c;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show("Greska detalji: " + ex.Message); }
        }

        // ── Odabir vjezbe - ucitaj progress i crtaj chart ─────────────────
        private void cmbVjezbe_SelectedIndexChanged(object sender, EventArgs e)
        {
            var sel = cmbVjezbe.SelectedItem as VjezbaItem;
            if (sel == null || sel.VjezbaID == -1)
            {
                chartTacke.Clear();
                lblChartNaslov.Text = "Odaberi vjezbu da vidis napredak kilaze";
                pnlChart.Invalidate();
                return;
            }
            UcitajProgressZaVjezbu(sel.VjezbaID, sel.Naziv);
        }

        private void UcitajProgressZaVjezbu(int vjezbaID, string naziv)
        {
            chartTacke.Clear();
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                using (MySqlCommand cmd = new MySqlCommand(
                    "SELECT t.Datum, tv.MaxTezina, tv.OdradjeniSetovi " +
                    "FROM treningvjezba tv " +
                    "JOIN trening t ON t.TreningID=tv.TreningID " +
                    "WHERE tv.VjezbaID=@vid AND t.KorisnikID=@kid " +
                    "ORDER BY t.Datum ASC", conn))
                {
                    cmd.Parameters.AddWithValue("@vid", vjezbaID);
                    cmd.Parameters.AddWithValue("@kid", KorisnikManager.TrenutniKorisnikID);
                    using (MySqlDataReader r = cmd.ExecuteReader())
                        while (r.Read())
                            chartTacke.Add(new ProgressTacka
                            {
                                Datum = r.GetDateTime(0),
                                MaxKg = r.IsDBNull(1) ? 0 : r.GetDouble(1),
                                Setovi = r.IsDBNull(2) ? 0 : r.GetInt32(2)
                            });
                }
            }
            catch (Exception ex) { MessageBox.Show("Greska chart: " + ex.Message); }

            if (chartTacke.Count > 0)
            {
                double maxKg = 0;
                foreach (var t in chartTacke)
                    if (t.MaxKg > maxKg) maxKg = t.MaxKg;
                lblChartNaslov.Text = naziv + "   —   Rekord: " + maxKg.ToString("0.##") + " kg" +
                                      "   |   Ukupno treninga: " + chartTacke.Count;
            }
            else
            {
                lblChartNaslov.Text = naziv + "  —  Nema podataka jos.";
            }

            pnlChart.Invalidate();
        }

        // ── Crtanje line charta ───────────────────────────────────────────
        private void pnlChart_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

            Rectangle rc = pnlChart.ClientRectangle;
            g.Clear(Color.White);

            if (chartTacke.Count < 1)
            {
                using (var br = new SolidBrush(Color.FromArgb(180, 180, 200)))
                using (var font = new Font("Segoe UI", 11f))
                {
                    string msg = "Nema podataka za prikaz";
                    SizeF sz = g.MeasureString(msg, font);
                    g.DrawString(msg, font, br,
                        rc.Width / 2f - sz.Width / 2f,
                        rc.Height / 2f - sz.Height / 2f + 20);
                }
                return;
            }

            int padL = 58, padR = 20, padT = 30, padB = 40;
            int cw = rc.Width - padL - padR;
            int ch = rc.Height - padT - padB;

            double minKg = double.MaxValue, maxKg = 0;
            foreach (var t in chartTacke)
            {
                if (t.MaxKg < minKg) minKg = t.MaxKg;
                if (t.MaxKg > maxKg) maxKg = t.MaxKg;
            }
            if (maxKg == minKg) { minKg = maxKg == 0 ? 0 : maxKg - 5; maxKg += 5; }
            double rangeKg = maxKg - minKg;

            using (var pen = new Pen(Color.FromArgb(235, 235, 240)))
            {
                int hLines = 5;
                for (int i = 0; i <= hLines; i++)
                {
                    int y = padT + ch - (int)(i * ch / (double)hLines);
                    g.DrawLine(pen, padL, y, padL + cw, y);
                    double kg = minKg + i * rangeKg / hLines;
                    using (var font = new Font("Segoe UI", 7.5f))
                    using (var br = new SolidBrush(Color.FromArgb(140, 140, 160)))
                        g.DrawString(kg.ToString("0.#"), font, br, 2, y - 7);
                }
            }

            using (var pen = new Pen(Color.FromArgb(200, 200, 210)))
            {
                g.DrawLine(pen, padL, padT, padL, padT + ch);
                g.DrawLine(pen, padL, padT + ch, padL + cw, padT + ch);
            }

            var pts = new PointF[chartTacke.Count];
            for (int i = 0; i < chartTacke.Count; i++)
            {
                float x = padL + (chartTacke.Count == 1
                    ? cw / 2f
                    : i * cw / (float)(chartTacke.Count - 1));
                float y = padT + ch - (float)((chartTacke[i].MaxKg - minKg) / rangeKg * ch);
                pts[i] = new PointF(x, y);
            }

            if (pts.Length > 1)
            {
                var fillPts = new PointF[pts.Length + 2];
                fillPts[0] = new PointF(pts[0].X, padT + ch);
                for (int i = 0; i < pts.Length; i++) fillPts[i + 1] = pts[i];
                fillPts[fillPts.Length - 1] = new PointF(pts[pts.Length - 1].X, padT + ch);

                using (var path = new GraphicsPath())
                {
                    path.AddPolygon(fillPts);
                    using (var br = new LinearGradientBrush(
                        new Point(0, padT), new Point(0, padT + ch),
                        Color.FromArgb(60, 88, 86, 214),
                        Color.FromArgb(8, 88, 86, 214)))
                        g.FillPath(br, path);
                }
            }

            if (pts.Length > 1)
                using (var pen = new Pen(Color.FromArgb(88, 86, 214), 2.5f))
                    g.DrawLines(pen, pts);

            for (int i = 0; i < pts.Length; i++)
            {
                float r = 5f;
                using (var br = new SolidBrush(Color.FromArgb(88, 86, 214)))
                    g.FillEllipse(br, pts[i].X - r, pts[i].Y - r, r * 2, r * 2);
                using (var pen = new Pen(Color.White, 2f))
                    g.DrawEllipse(pen, pts[i].X - r, pts[i].Y - r, r * 2, r * 2);

                using (var font = new Font("Segoe UI", 7.5f, FontStyle.Bold))
                using (var br = new SolidBrush(Color.FromArgb(88, 86, 214)))
                {
                    string lbl = chartTacke[i].MaxKg.ToString("0.#");
                    SizeF sz = g.MeasureString(lbl, font);
                    g.DrawString(lbl, font, br, pts[i].X - sz.Width / 2, pts[i].Y - 18);
                }

                bool prikaziDatum = chartTacke.Count <= 10 || i % 2 == 0;
                if (prikaziDatum)
                {
                    using (var font = new Font("Segoe UI", 7f))
                    using (var br = new SolidBrush(Color.FromArgb(130, 130, 150)))
                    {
                        string d = chartTacke[i].Datum.ToString("dd.MM");
                        SizeF sz = g.MeasureString(d, font);
                        g.DrawString(d, font, br, pts[i].X - sz.Width / 2, padT + ch + 6);
                    }
                }
            }

            using (var font = new Font("Segoe UI", 8f, FontStyle.Bold))
            using (var br = new SolidBrush(Color.FromArgb(88, 86, 214)))
                g.DrawString("kg", font, br, 2, padT - 16);
        }

        private void FrmEvidencija_Load(object sender, EventArgs e)
        {
            // Prazno — inicijalizacija se radi u konstruktoru
        }
    }
}