using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApplication1
{
    public class FrmTreningPlan : Form
    {
        // ── Kontrole ─────────────────────────────────────────────────────
        private Panel    pnlLijevo;
        private Label    lblPlanovi;
        private ListBox  lstbPlanovi;
        private Button   btnNoviPlan;
        private Button   btnObrisiPlan;
        private Panel    pnlDesno;
        private Label    lblNaziv;
        private TextBox  txtNazivPlana;
        private DataGridView dgvVjezbeZaDan;
        private Button   btnDodajVjezbu;
        private Button   btnObrisiVjezbu;
        private Button   btnSpremiPlan;
        private Label    lblStatus;

        // ── Podaci ───────────────────────────────────────────────────────
        private List<TreningVjezba> vjezbeZaDan = new List<TreningVjezba>();
        private int  odabraniPlanID = -1;
        private bool noviPlanMode   = false;

        private class TreningVjezba
        {
            public int    VjezbaID;
            public string Naziv;
            public string Opis;
            public string Tip;
            public string MisicnaGrupa;
            public int    BrojSetova      = 3;
            public int    BrojPonavljanja = 10;
        }

        public class PlanItem
        {
            public int    PlanID;
            public string Naziv;
            public override string ToString() { return Naziv; }
        }

        // ── Konstruktor ──────────────────────────────────────────────────
        public FrmTreningPlan()
        {
            GradiForme();
            PrimijeniStil();
            UcitajPlanove();
        }

        // ── Gradnja forme u kodu ─────────────────────────────────────────
        private void GradiForme()
        {
            this.SuspendLayout();
            this.Text            = "Trening Planovi";
            this.ClientSize      = new Size(900, 550);
            this.StartPosition   = FormStartPosition.CenterScreen;
            this.Font            = new Font("Segoe UI", 9f);
            this.BackColor       = Color.FromArgb(245, 247, 250);

            // ── Lijevi panel ─────────────────────────────────────────────
            pnlLijevo = new Panel
            {
                Dock     = DockStyle.Left,
                Size     = new Size(205, 550),
                Padding  = new Padding(0)
            };

            lblPlanovi = new Label
            {
                Text      = "  Moji planovi",
                Dock      = DockStyle.Top,
                Height    = 44,
                TextAlign = ContentAlignment.MiddleLeft
            };

            lstbPlanovi = new ListBox
            {
                Location    = new Point(0, 44),
                Size        = new Size(205, 400),
                BorderStyle = BorderStyle.None
            };
            lstbPlanovi.SelectedIndexChanged += lstbPlanovi_SelectedIndexChanged;

            btnNoviPlan = new Button
            {
                Text     = "+ Novi plan",
                Location = new Point(4, 455),
                Size     = new Size(92, 34)
            };
            btnNoviPlan.Click += btnNoviPlan_Click;

            btnObrisiPlan = new Button
            {
                Text     = "Obrisi plan",
                Location = new Point(104, 455),
                Size     = new Size(92, 34)
            };
            btnObrisiPlan.Click += btnObrisiPlan_Click;

            pnlLijevo.Controls.Add(lblPlanovi);
            pnlLijevo.Controls.Add(lstbPlanovi);
            pnlLijevo.Controls.Add(btnNoviPlan);
            pnlLijevo.Controls.Add(btnObrisiPlan);

            // ── Desni panel ──────────────────────────────────────────────
            pnlDesno = new Panel
            {
                Dock    = DockStyle.Fill,
                Padding = new Padding(12)
            };

            lblNaziv = new Label
            {
                Text     = "Naziv plana:",
                Location = new Point(12, 18),
                AutoSize = true
            };

            txtNazivPlana = new TextBox
            {
                Location  = new Point(112, 15),
                Size      = new Size(280, 22),
                ReadOnly  = true
            };

            // DataGridView
            dgvVjezbeZaDan = new DataGridView
            {
                Location              = new Point(12, 52),
                Size                  = new Size(655, 395),
                ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize,
                ReadOnly              = true,
                AllowUserToAddRows    = false,
                SelectionMode         = DataGridViewSelectionMode.FullRowSelect,
                AutoGenerateColumns   = false
            };
            dgvVjezbeZaDan.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Naziv vjezbe",    Name = "cNaziv", Width = 180 });
            dgvVjezbeZaDan.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Tip",             Name = "cTip",   Width = 90  });
            dgvVjezbeZaDan.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Misicna grupa",   Name = "cGrupa", Width = 110 });
            dgvVjezbeZaDan.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Setovi",          Name = "cSetovi",Width = 70  });
            dgvVjezbeZaDan.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Ponavljanja",     Name = "cPon",   Width = 90  });

            btnDodajVjezbu = new Button
            {
                Text     = "+ Dodaj vjezbu",
                Location = new Point(12, 458),
                Size     = new Size(130, 34)
            };
            btnDodajVjezbu.Click += btnDodajVjezbu_Click;

            btnObrisiVjezbu = new Button
            {
                Text     = "Obrisi vjezbu",
                Location = new Point(152, 458),
                Size     = new Size(130, 34)
            };
            btnObrisiVjezbu.Click += btnObrisiVjezbu_Click;

            btnSpremiPlan = new Button
            {
                Text     = "Spremi plan",
                Location = new Point(537, 458),
                Size     = new Size(130, 34)
            };
            btnSpremiPlan.Click += btnSpremiPlan_Click;

            lblStatus = new Label
            {
                Text     = "Odaberite plan sa lijeve strane ili kreirajte novi.",
                Location = new Point(12, 500),
                Size     = new Size(600, 18),
                AutoSize = false
            };

            pnlDesno.Controls.Add(lblNaziv);
            pnlDesno.Controls.Add(txtNazivPlana);
            pnlDesno.Controls.Add(dgvVjezbeZaDan);
            pnlDesno.Controls.Add(btnDodajVjezbu);
            pnlDesno.Controls.Add(btnObrisiVjezbu);
            pnlDesno.Controls.Add(btnSpremiPlan);
            pnlDesno.Controls.Add(lblStatus);

            this.Controls.Add(pnlDesno);
            this.Controls.Add(pnlLijevo);
            this.ResumeLayout(false);
        }

        // ── Stil ─────────────────────────────────────────────────────────
        private void PrimijeniStil()
        {
            pnlLijevo.BackColor   = Color.FromArgb(88, 86, 214);
            lblPlanovi.ForeColor  = Color.White;
            lblPlanovi.Font       = new Font("Segoe UI", 12f, FontStyle.Bold);
            lstbPlanovi.BackColor = Color.FromArgb(255, 255, 255);
            lstbPlanovi.Font      = new Font("Segoe UI", 10f);

            StilBtn(btnNoviPlan,    Color.White,               Color.FromArgb(88, 86, 214));
            StilBtn(btnObrisiPlan,  Color.FromArgb(220,53,69), Color.White);
            StilBtn(btnDodajVjezbu, Color.FromArgb(40,167,69), Color.White);
            StilBtn(btnObrisiVjezbu,Color.FromArgb(220,53,69), Color.White);
            StilBtn(btnSpremiPlan,  Color.FromArgb(88,86,214), Color.White);

            pnlDesno.BackColor  = Color.FromArgb(245, 247, 250);
            lblNaziv.Font       = new Font("Segoe UI", 10f, FontStyle.Bold);
            lblNaziv.ForeColor  = Color.FromArgb(88, 86, 214);
            lblStatus.ForeColor = Color.FromArgb(100, 100, 100);
            txtNazivPlana.Font  = new Font("Segoe UI", 10f);

            // Grid stil
            dgvVjezbeZaDan.BackgroundColor                           = Color.White;
            dgvVjezbeZaDan.BorderStyle                               = BorderStyle.None;
            dgvVjezbeZaDan.CellBorderStyle                           = DataGridViewCellBorderStyle.SingleHorizontal;
            dgvVjezbeZaDan.GridColor                                 = Color.FromArgb(230, 230, 230);
            dgvVjezbeZaDan.RowHeadersVisible                         = false;
            dgvVjezbeZaDan.EnableHeadersVisualStyles                 = false;
            dgvVjezbeZaDan.ColumnHeadersDefaultCellStyle.BackColor   = Color.FromArgb(88, 86, 214);
            dgvVjezbeZaDan.ColumnHeadersDefaultCellStyle.ForeColor   = Color.White;
            dgvVjezbeZaDan.ColumnHeadersDefaultCellStyle.Font        = new Font("Segoe UI", 9f, FontStyle.Bold);
            dgvVjezbeZaDan.ColumnHeadersHeight                       = 36;
            dgvVjezbeZaDan.DefaultCellStyle.Font                     = new Font("Segoe UI", 9f);
            dgvVjezbeZaDan.DefaultCellStyle.SelectionBackColor       = Color.FromArgb(88, 86, 214);
            dgvVjezbeZaDan.DefaultCellStyle.SelectionForeColor       = Color.White;
            dgvVjezbeZaDan.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 249, 252);
            dgvVjezbeZaDan.RowTemplate.Height                        = 32;
        }

        private void StilBtn(Button b, Color back, Color fore)
        {
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderSize = 0;
            b.BackColor = back;
            b.ForeColor = fore;
            b.Font      = new Font("Segoe UI", 9f, FontStyle.Bold);
            b.Cursor    = Cursors.Hand;
        }

        // ── Logika ───────────────────────────────────────────────────────
        private void UcitajPlanove()
        {
            lstbPlanovi.Items.Clear();
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                {
                    string sql = "SELECT PlanID, Naziv FROM treningplan " +
                                 "WHERE KorisnikID=@kid ORDER BY DatumKreiranja DESC";
                    using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@kid", KorisnikManager.TrenutniKorisnikID);
                        using (MySqlDataReader r = cmd.ExecuteReader())
                            while (r.Read())
                                lstbPlanovi.Items.Add(new PlanItem { PlanID = r.GetInt32(0), Naziv = r.GetString(1) });
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show("Greska ucitavanja planova: " + ex.Message); }
        }

        private void lstbPlanovi_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstbPlanovi.SelectedItem == null) return;
            noviPlanMode = false;
            var plan = (PlanItem)lstbPlanovi.SelectedItem;
            odabraniPlanID       = plan.PlanID;
            txtNazivPlana.Text   = plan.Naziv;
            txtNazivPlana.ReadOnly = true;
            UcitajVjezbeZaPlan(plan.PlanID);
            lblStatus.Text = "Plan ucitan. Dodajte ili obrisite vjezbe.";
        }

        private void UcitajVjezbeZaPlan(int planID)
        {
            vjezbeZaDan.Clear();
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                {
                    string sql = "SELECT v.VjezbaID, v.Naziv, v.Opis, v.Tip, v.MisicnaGrupa," +
                                 "pv.BrojSetova, pv.BrojPonavljanja " +
                                 "FROM planvjezba pv JOIN vjezba v ON v.VjezbaID=pv.VjezbaID " +
                                 "WHERE pv.PlanID=@pid";
                    using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@pid", planID);
                        using (MySqlDataReader r = cmd.ExecuteReader())
                            while (r.Read())
                                vjezbeZaDan.Add(new TreningVjezba
                                {
                                    VjezbaID       = r.GetInt32(0),
                                    Naziv          = r.GetString(1),
                                    Opis           = r.IsDBNull(2) ? "" : r.GetString(2),
                                    Tip            = r.GetString(3),
                                    MisicnaGrupa   = r.GetString(4),
                                    BrojSetova     = r.IsDBNull(5) ? 3  : r.GetInt32(5),
                                    BrojPonavljanja= r.IsDBNull(6) ? 10 : r.GetInt32(6)
                                });
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show("Greska: " + ex.Message); }
            OsvjeziGrid();
        }

        private void OsvjeziGrid()
        {
            dgvVjezbeZaDan.Rows.Clear();
            foreach (TreningVjezba v in vjezbeZaDan)
                dgvVjezbeZaDan.Rows.Add(v.Naziv, v.Tip, v.MisicnaGrupa, v.BrojSetova, v.BrojPonavljanja);
        }

        private void btnNoviPlan_Click(object sender, EventArgs e)
        {
            noviPlanMode = true;
            odabraniPlanID = -1;
            vjezbeZaDan.Clear();
            OsvjeziGrid();
            txtNazivPlana.ReadOnly = false;
            txtNazivPlana.Text     = "Novi plan " + DateTime.Now.ToString("dd.MM.yyyy");
            txtNazivPlana.Focus();
            lstbPlanovi.ClearSelected();
            lblStatus.Text = "Unesite naziv i dodajte vjezbe, zatim kliknite Spremi.";
        }

        private void btnDodajVjezbu_Click(object sender, EventArgs e)
        {
            if (!noviPlanMode && odabraniPlanID == -1)
            { MessageBox.Show("Odaberite plan ili kliknite 'Novi plan'!"); return; }

            FrmVjezbe f = new FrmVjezbe();
            if (f.ShowDialog() == DialogResult.OK && f.OdabranaVjezba != null)
            {
                foreach (TreningVjezba tv in vjezbeZaDan)
                    if (tv.VjezbaID == f.OdabranaVjezba.VjezbaID)
                    { MessageBox.Show("Ta vjezba je vec u planu!"); return; }

                vjezbeZaDan.Add(new TreningVjezba
                {
                    VjezbaID        = f.OdabranaVjezba.VjezbaID,
                    Naziv           = f.OdabranaVjezba.Naziv,
                    Opis            = f.OdabranaVjezba.Opis,
                    Tip             = f.OdabranaVjezba.Tip,
                    MisicnaGrupa    = f.OdabranaVjezba.MisicnaGrupa,
                    BrojSetova      = 3,
                    BrojPonavljanja = 10
                });
                OsvjeziGrid();
                if (!noviPlanMode) AzurirajPlanUBazi();
            }
        }

        private void btnObrisiVjezbu_Click(object sender, EventArgs e)
        {
            if (dgvVjezbeZaDan.CurrentRow == null)
            { MessageBox.Show("Odaberite vjezbu za brisanje!"); return; }
            int idx = dgvVjezbeZaDan.CurrentRow.Index;
            if (idx < 0 || idx >= vjezbeZaDan.Count) return;

            if (!noviPlanMode && odabraniPlanID != -1)
            {
                try
                {
                    using (MySqlConnection conn = DbHelper.GetConnection())
                    using (MySqlCommand cmd = new MySqlCommand(
                        "DELETE FROM planvjezba WHERE PlanID=@pid AND VjezbaID=@vid", conn))
                    {
                        cmd.Parameters.AddWithValue("@pid", odabraniPlanID);
                        cmd.Parameters.AddWithValue("@vid", vjezbeZaDan[idx].VjezbaID);
                        cmd.ExecuteNonQuery();
                    }
                }
                catch (Exception ex) { MessageBox.Show("Greska: " + ex.Message); return; }
            }
            vjezbeZaDan.RemoveAt(idx);
            OsvjeziGrid();
            lblStatus.Text = "Vjezba obrisana.";
        }

        private void btnObrisiPlan_Click(object sender, EventArgs e)
        {
            if (odabraniPlanID == -1) { MessageBox.Show("Odaberite plan!"); return; }
            var plan = lstbPlanovi.SelectedItem as PlanItem;
            if (plan == null) return;
            if (MessageBox.Show("Obrisati plan '" + plan.Naziv + "'?", "Potvrda",
                MessageBoxButtons.YesNo) != DialogResult.Yes) return;
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                {
                    using (MySqlCommand cmd = new MySqlCommand("DELETE FROM planvjezba WHERE PlanID=@pid", conn))
                    { cmd.Parameters.AddWithValue("@pid", odabraniPlanID); cmd.ExecuteNonQuery(); }
                    using (MySqlCommand cmd = new MySqlCommand("DELETE FROM treningplan WHERE PlanID=@pid", conn))
                    { cmd.Parameters.AddWithValue("@pid", odabraniPlanID); cmd.ExecuteNonQuery(); }
                }
                odabraniPlanID = -1;
                vjezbeZaDan.Clear();
                OsvjeziGrid();
                txtNazivPlana.Text = "";
                UcitajPlanove();
            }
            catch (Exception ex) { MessageBox.Show("Greska: " + ex.Message); }
        }

        private void btnSpremiPlan_Click(object sender, EventArgs e)
        {
            if (vjezbeZaDan.Count == 0) { MessageBox.Show("Dodaj barem jednu vjezbu!"); return; }
            string naziv = txtNazivPlana.Text.Trim();
            if (naziv.Length == 0) { MessageBox.Show("Upisite naziv plana!"); return; }
            if (noviPlanMode) SpremiNoviPlan(naziv);
            else AzurirajPlanUBazi();
        }

        private void SpremiNoviPlan(string naziv)
        {
            try
            {
                int planID;
                using (MySqlConnection conn = DbHelper.GetConnection())
                {
                    using (MySqlCommand cmd = new MySqlCommand(
                        "INSERT INTO treningplan (KorisnikID,Naziv,DatumKreiranja) " +
                        "VALUES (@kid,@n,@d); SELECT LAST_INSERT_ID();", conn))
                    {
                        cmd.Parameters.AddWithValue("@kid", KorisnikManager.TrenutniKorisnikID);
                        cmd.Parameters.AddWithValue("@n",   naziv);
                        cmd.Parameters.AddWithValue("@d",   DateTime.Now.ToString("yyyy-MM-dd"));
                        planID = Convert.ToInt32(cmd.ExecuteScalar());
                    }
                    foreach (TreningVjezba v in vjezbeZaDan)
                        using (MySqlCommand cmd = new MySqlCommand(
                            "INSERT INTO planvjezba (PlanID,VjezbaID,BrojSetova,BrojPonavljanja) " +
                            "VALUES (@pid,@vid,@bs,@bp)", conn))
                        {
                            cmd.Parameters.AddWithValue("@pid", planID);
                            cmd.Parameters.AddWithValue("@vid", v.VjezbaID);
                            cmd.Parameters.AddWithValue("@bs",  v.BrojSetova);
                            cmd.Parameters.AddWithValue("@bp",  v.BrojPonavljanja);
                            cmd.ExecuteNonQuery();
                        }
                    odabraniPlanID = planID;
                    noviPlanMode   = false;
                    txtNazivPlana.ReadOnly = true;
                }
                MessageBox.Show("Plan '" + naziv + "' sačuvan!");
                lblStatus.Text = "Plan sacuvan!";
                UcitajPlanove();
                foreach (object item in lstbPlanovi.Items)
                    if (((PlanItem)item).PlanID == odabraniPlanID)
                    { lstbPlanovi.SelectedItem = item; break; }
            }
            catch (Exception ex) { MessageBox.Show("Greska: " + ex.Message); }
        }

        private void AzurirajPlanUBazi()
        {
            if (odabraniPlanID == -1) return;
            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                {
                    using (MySqlCommand cmd = new MySqlCommand(
                        "DELETE FROM planvjezba WHERE PlanID=@pid", conn))
                    { cmd.Parameters.AddWithValue("@pid", odabraniPlanID); cmd.ExecuteNonQuery(); }

                    foreach (TreningVjezba v in vjezbeZaDan)
                        using (MySqlCommand cmd = new MySqlCommand(
                            "INSERT INTO planvjezba (PlanID,VjezbaID,BrojSetova,BrojPonavljanja) " +
                            "VALUES (@pid,@vid,@bs,@bp)", conn))
                        {
                            cmd.Parameters.AddWithValue("@pid", odabraniPlanID);
                            cmd.Parameters.AddWithValue("@vid", v.VjezbaID);
                            cmd.Parameters.AddWithValue("@bs",  v.BrojSetova);
                            cmd.Parameters.AddWithValue("@bp",  v.BrojPonavljanja);
                            cmd.ExecuteNonQuery();
                        }

                    using (MySqlCommand cmd = new MySqlCommand(
                        "UPDATE treningplan SET Naziv=@n WHERE PlanID=@pid", conn))
                    {
                        cmd.Parameters.AddWithValue("@n",   txtNazivPlana.Text.Trim());
                        cmd.Parameters.AddWithValue("@pid", odabraniPlanID);
                        cmd.ExecuteNonQuery();
                    }
                }
                lblStatus.Text = "Promjene sacuvane!";
                UcitajPlanove();
            }
            catch (Exception ex) { MessageBox.Show("Greska: " + ex.Message); }
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // FrmTreningPlan
            // 
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Name = "FrmTreningPlan";
            this.Load += new System.EventHandler(this.FrmTreningPlan_Load);
            this.ResumeLayout(false);

        }

        private void FrmTreningPlan_Load(object sender, EventArgs e)
        {

        }
    }
}
