using System;
using System.Collections.Generic;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApplication1
{
    public partial class FrmTreningPlan : Form
    {
        private List<TreningVjezba> vjezbeZaDan = new List<TreningVjezba>();

        private class TreningVjezba
        {
            public int VjezbaID;
            public string Naziv;
            public string Opis;
            public string Tip;
            public string MisicnaGrupa;
            public bool Uradjeno;
            public int UradjeniSetovi;
        }

        public FrmTreningPlan()
        {
            InitializeComponent();
            FrmTreningPlan_Load(null, null);
        }

        private void FrmTreningPlan_Load(object sender, EventArgs e)
        {
            dgvVjezbeZaDan.ColumnCount = 5;
            dgvVjezbeZaDan.Columns[0].HeaderText = "Naziv";
            dgvVjezbeZaDan.Columns[1].HeaderText = "Opis";
            dgvVjezbeZaDan.Columns[1].Width = 200;
            dgvVjezbeZaDan.Columns[2].HeaderText = "Tip";
            dgvVjezbeZaDan.Columns[3].HeaderText = "Uradjeno";
            dgvVjezbeZaDan.Columns[3].Width = 80;
            dgvVjezbeZaDan.Columns[4].HeaderText = "Setovi";
            dgvVjezbeZaDan.Columns[4].Width = 60;

            lstbDani.Items.Clear();
            lstbDani.Items.Add("Ponedjeljak");
            lstbDani.Items.Add("Utorak");
            lstbDani.Items.Add("Srijeda");
            lstbDani.Items.Add("Cetvrtak");
            lstbDani.Items.Add("Petak");
            lstbDani.Items.Add("Subota");
            lstbDani.Items.Add("Nedjelja");
        }

        private void lstbDani_SelectedIndexChanged(object sender, EventArgs e) { OsvjeziGrid(); }

        private void OsvjeziGrid()
        {
            dgvVjezbeZaDan.Rows.Clear();
            foreach (TreningVjezba v in vjezbeZaDan)
                dgvVjezbeZaDan.Rows.Add(v.Naziv, v.Opis, v.Tip, v.Uradjeno, v.UradjeniSetovi);
        }

        private void btnDodajVjezbu_Click(object sender, EventArgs e)
        {
            FrmVjezbe f = new FrmVjezbe();
            if (f.ShowDialog() == DialogResult.OK && f.OdabranaVjezba != null)
            {
                vjezbeZaDan.Add(new TreningVjezba
                {
                    VjezbaID = f.OdabranaVjezba.VjezbaID,
                    Naziv = f.OdabranaVjezba.Naziv,
                    Opis = f.OdabranaVjezba.Opis,
                    Tip = f.OdabranaVjezba.Tip,
                    MisicnaGrupa = f.OdabranaVjezba.MisicnaGrupa,
                    Uradjeno = false,
                    UradjeniSetovi = 0
                });
                OsvjeziGrid();
            }
        }

        private void btnObrisi_Click(object sender, EventArgs e)
        {
            if (dgvVjezbeZaDan.CurrentRow != null)
            {
                vjezbeZaDan.RemoveAt(dgvVjezbeZaDan.CurrentRow.Index);
                OsvjeziGrid();
                MessageBox.Show("Vjezba obrisana!");
            }
            else MessageBox.Show("Odaberi vjezbu za brisanje!");
        }

        private void dgvVjezbeZaDan_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 3 && e.RowIndex >= 0)
            {
                vjezbeZaDan[e.RowIndex].Uradjeno = !vjezbeZaDan[e.RowIndex].Uradjeno;
                OsvjeziGrid();
            }
        }

        private void dgvVjezbeZaDan_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 3 && e.RowIndex >= 0)
            {
                vjezbeZaDan[e.RowIndex].Uradjeno = !vjezbeZaDan[e.RowIndex].Uradjeno;
                OsvjeziGrid();
            }
        }

        private void btnSpremiPlan_Click(object sender, EventArgs e)
        {
            SpremiPlanUBazu();
        }

        private void SpremiPlanUBazu()
        {
            if (vjezbeZaDan.Count == 0)
            {
                MessageBox.Show("Dodaj barem jednu vjezbu u plan!");
                return;
            }

            // C# 3 kompatibilan unos naziva - koristimo Form sa TextBox-om
            string naziv = "";
            Form frmUnos = new Form();
            frmUnos.Text = "Naziv plana";
            frmUnos.Size = new System.Drawing.Size(360, 140);
            frmUnos.StartPosition = FormStartPosition.CenterParent;
            frmUnos.FormBorderStyle = FormBorderStyle.FixedDialog;
            frmUnos.MaximizeBox = false;
            frmUnos.MinimizeBox = false;

            Label lbl = new Label();
            lbl.Text = "Upisite naziv plana:";
            lbl.Location = new System.Drawing.Point(12, 12);
            lbl.Size = new System.Drawing.Size(200, 20);

            TextBox txt = new TextBox();
            txt.Location = new System.Drawing.Point(12, 36);
            txt.Size = new System.Drawing.Size(316, 22);
            txt.Text = "Plan " + DateTime.Now.ToString("dd.MM.yyyy");

            Button btnOk = new Button();
            btnOk.Text = "OK";
            btnOk.Location = new System.Drawing.Point(172, 68);
            btnOk.Size = new System.Drawing.Size(75, 26);
            btnOk.DialogResult = DialogResult.OK;

            Button btnCancel = new Button();
            btnCancel.Text = "Otkazi";
            btnCancel.Location = new System.Drawing.Point(253, 68);
            btnCancel.Size = new System.Drawing.Size(75, 26);
            btnCancel.DialogResult = DialogResult.Cancel;

            frmUnos.Controls.Add(lbl);
            frmUnos.Controls.Add(txt);
            frmUnos.Controls.Add(btnOk);
            frmUnos.Controls.Add(btnCancel);
            frmUnos.AcceptButton = btnOk;
            frmUnos.CancelButton = btnCancel;

            if (frmUnos.ShowDialog() != DialogResult.OK) return;

            naziv = txt.Text.Trim();

            // C# 3 kompatibilno: IsNullOrEmpty + Trim()
            if (naziv == null || naziv.Length == 0) return;

            try
            {
                using (MySqlConnection conn = DbHelper.GetConnection())
                {
                    string sqlPlan = "INSERT INTO treningplan (KorisnikID, Naziv, DatumKreiranja) " +
                                     "VALUES (@kid, @n, @d); SELECT LAST_INSERT_ID();";
                    int planID;
                    using (MySqlCommand cmd = new MySqlCommand(sqlPlan, conn))
                    {
                        cmd.Parameters.AddWithValue("@kid", KorisnikManager.TrenutniKorisnikID);
                        cmd.Parameters.AddWithValue("@n", naziv);
                        cmd.Parameters.AddWithValue("@d", DateTime.Now.ToString("yyyy-MM-dd"));
                        planID = Convert.ToInt32(cmd.ExecuteScalar());
                    }

                    foreach (TreningVjezba v in vjezbeZaDan)
                    {
                        string sqlVj = "INSERT INTO planvjezba (PlanID, VjezbaID, BrojSetova, BrojPonavljanja) " +
                                       "VALUES (@pid, @vid, 3, 10)";
                        using (MySqlCommand cmd = new MySqlCommand(sqlVj, conn))
                        {
                            cmd.Parameters.AddWithValue("@pid", planID);
                            cmd.Parameters.AddWithValue("@vid", v.VjezbaID);
                            cmd.ExecuteNonQuery();
                        }
                    }
                }
                MessageBox.Show("Plan '" + naziv + "' uspjesno spremljen!");
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greska pri spremanju plana: " + ex.Message);
            }
        }
    }
}
