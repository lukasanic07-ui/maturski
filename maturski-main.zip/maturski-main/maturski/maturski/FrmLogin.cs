using System;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtUsername.Text.Trim() == "" || txtLozinka.Text == "")
            {
                MessageBox.Show("Upisi username i lozinku!");
                return;
            }

            if (KorisnikManager.Prijavi(txtUsername.Text.Trim(), txtLozinka.Text))
            {
                this.Hide();
                FrmNaslovna frm = new FrmNaslovna();
                frm.ShowDialog();
                this.Close();
            }
            else
            {
                MessageBox.Show("Pogresan username ili lozinka!");
                txtLozinka.Clear();
            }
        }
    }
}
