﻿using System;
using System.Collections.Generic;

namespace WindowsFormsApplication1
{
    public class Korisnik
    {
        public int KorisnikID { get; set; }
        public string Username { get; set; }
        public string Lozinka { get; set; }
        public string Ime { get; set; }
        public string Prezime { get; set; }
        public int Godine { get; set; }
        public double Tezina { get; set; }
        public double Visina { get; set; }
    }

    public static class KorisnikManager
    {
        public static List<Korisnik> Lista = new List<Korisnik>();
        public static Korisnik TrenutniKorisnik = null;

        static KorisnikManager()
        {
            // Test korisnik da mozes odmah testirati
            Lista.Add(new Korisnik
            {
                KorisnikID = 1,
                Username = "test",
                Lozinka = "123",
                Ime = "Marko",
                Prezime = "Petrovic",
                Godine = 22,
                Tezina = 80,
                Visina = 180
            });
        }

        public static bool Prijavi(string username, string lozinka)
        {
            Korisnik k = null;
            foreach (Korisnik x in Lista)
            {
                if (x.Username == username && x.Lozinka == lozinka)
                {
                    k = x;
                    break;
                }
            }
            if (k != null)
            {
                TrenutniKorisnik = k;
                return true;
            }
            return false;
        }

        public static bool Registruj(Korisnik novi)
        {
            foreach (Korisnik x in Lista)
            {
                if (x.Username == novi.Username)
                    return false; // username zauzet
            }
            novi.KorisnikID = Lista.Count + 1;
            Lista.Add(novi);
            return true;
        }
    }
}